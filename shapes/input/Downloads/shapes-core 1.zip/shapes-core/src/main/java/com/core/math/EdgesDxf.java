package com.core.math;

public class  EdgesDxf {
    public Point2D st;
    public Point2D en;
    public double y;
    public boolean isCurved = false;
    public boolean isCutoutEdge = false;
    public double r;
    public double stAngle;
    public double swAngle;
    public boolean isLarge = false;

    public  EdgesDxf(Point2D st, Point2D en, boolean isCurved, double r, double stAngle, double swAngle,boolean isLarge) {
        this.st = st;
        this.en = en;
        this.isCurved = isCurved;
        this.r = r;
        this.stAngle = stAngle;
        this.swAngle = swAngle;
        this.isLarge = isLarge;
    }


    @Override
    public String toString() {
        return "EdgesDxf[" + st.x + ", " + st.y + "," + en.x + ", " + en.y + ", " + isCurved + ", " + r + ", " + stAngle + ", " + swAngle + "]";
    }

}