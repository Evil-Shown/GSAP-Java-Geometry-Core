package com.core.exception;

public class ParamNotFoundException extends RuntimeException {
    public ParamNotFoundException(String paramName) {
        super("Parameter '" + paramName + "' not found");
    }
}
