package com.core.svg;

import java.util.ArrayList;
import java.util.List;

public class SVGBuilder {

    private final StringBuilder sb = new StringBuilder();
    private final List<String> elements = new ArrayList<>();
    private String text = null;

    public static class SvgPathBuilder {

        private final StringBuffer sb = new StringBuffer();
        private final SVGBuilder svgBuilder;
        private String fill = null;
        private String stroke = null;
        private String vectorEffect = null;
        private String strokeWidth = null;
        private String lineCap = null;
        private String translate = null;
        private String text = null;
        private int textX = 0;
        private int textY = 0;

        public SvgPathBuilder(SVGBuilder svgBuilder) {
            this.svgBuilder = svgBuilder;
        }

        public SVGBuilder circle(double x, double y, double r) {
            sb.append("<circle cx=\"").append(x).append("\" ").append("cy=\"")
                .append(y).append("\" ").append("r=\"").append(r).append("\" ");
            if (fill != null && !fill.isEmpty()) {
                sb.append("fill=\"").append(fill).append("\" ");
            }
            if (stroke != null && !stroke.isEmpty()) {
                sb.append("stroke=\"").append(stroke).append("\" ");
            }
            if (strokeWidth != null && !strokeWidth.isEmpty()) {
                sb.append("stroke-width=\"").append(strokeWidth).append("\" ");
            }
            if (lineCap != null && !lineCap.isEmpty()) {
                sb.append("stroke-linecap=\"").append(lineCap).append("\" ");
            }
            if (vectorEffect != null && !vectorEffect.isEmpty()) {
                sb.append("vector-effect=\"").append(vectorEffect).append("\" ");
            }
            if (translate != null && !translate.isEmpty()) {
                sb.append("transform=\"").append(translate).append("\" ");
            }
            sb.append("/>");

            svgBuilder.elements.add(sb.toString());
            return svgBuilder;
        }

        public SvgPathBuilder startPath(double x, double y) {
            sb.append("<path d=\"").append("M ").append(x).append(" ").append(y).append(" ");
            return this;
        }

        public SvgPathBuilder startPath(double x, double y, String id) {
            sb.append("<path class=\"control-edge\" id=\"").append(id).append("\" d=\"").append("M ").append(x).append(" ").append(y).append(" ");
            return this;
        }

        public SvgPathBuilder lineTo(double x, double y) {
            sb.append("L ").append(x).append(" ").append(y).append(" ");
            return this;
        }

        public SvgPathBuilder arcTo(double rx, double ry, double endX, double endY, boolean largeArc, boolean sweep) {
            sb.append("A ").append(rx).append(" ").append(ry).append(" 0 ")
                .append(largeArc ? "1 " : "0 ")
                .append(sweep ? "1 " : "0 ")
                .append(endX).append(" ").append(endY).append(" ");
            return this;
        }

        public SvgPathBuilder cubicCurveTo() {
            // TODO
            return this;
        }

        public SvgPathBuilder fill(String fill) {
            this.fill = fill;
            return this;
        }

        public SvgPathBuilder stroke(String stroke) {
            this.stroke = stroke;
            return this;
        }

        public SvgPathBuilder vectorEffect(String vectorEffect) {
            this.vectorEffect = vectorEffect;
            return this;
        }

        public SvgPathBuilder strokeWidth(String strokeWidth) {
            this.strokeWidth = strokeWidth;
            return this;
        }

        public SvgPathBuilder lineCap(String lineCap) {
            this.lineCap = lineCap;
            return this;
        }

        public SvgPathBuilder translate(int x, int y) {
            this.translate = "translate(" + x + "," + y + ")";
            return this;
        }

        public SvgPathBuilder setText(String text, int x, int y) {
            this.text = text;
            this.textX = x;
            this.textY = y;
            return this;
        }

        private void addTextNode() {
            sb.append("<circle cx=\"");
            sb.append(textX);
            sb.append("\" cy=\"");
            sb.append(textY);
            sb.append("\" r=\"25\" fill=\"black\" stroke=\"none\" />\n");
            sb.append("<text x=\"0\" y=\"0\" transform=\"translate(");
            sb.append(textX);
            sb.append(",");
            sb.append(textY);
            sb.append("\" fill=\"white\" text-anchor=\"middle\" dominant-baseline=\"middle\" font-weight=\"bold\" font-size=\"1.5em\">");
            sb.append(text);
            sb.append("</text>\n");
        }

        public SVGBuilder endPath(boolean close) {
            if (close) {
                sb.append("Z");
            }
            sb.append("\" ");

            if (fill != null && !fill.isEmpty()) {
                sb.append("fill=\"").append(fill).append("\" ");
            }
            if (stroke != null && !stroke.isEmpty()) {
                sb.append("stroke=\"").append(stroke).append("\" ");
            }
            if (strokeWidth != null && !strokeWidth.isEmpty()) {
                sb.append("stroke-width=\"").append(strokeWidth).append("\" ");
            }
            if (lineCap != null && !lineCap.isEmpty()) {
                sb.append("stroke-linecap=\"").append(lineCap).append("\" ");
            }
            if (vectorEffect != null && !vectorEffect.isEmpty()) {
                sb.append("vector-effect=\"").append(vectorEffect).append("\" ");
            }
            if (translate != null && !translate.isEmpty()) {
                sb.append("transform=\"").append(translate).append("\" ");
            }
            sb.append(" />");
            if (text != null) {
                addTextNode();
            }
            svgBuilder.elements.add(sb.toString());

            return svgBuilder;
        }

    }

    public SvgPathBuilder pathBuilder() {
        SvgPathBuilder pathBuilder = new SvgPathBuilder(this);
        return pathBuilder.fill("none")
            .stroke("black")
            .vectorEffect("non-scaling-stroke")
            .strokeWidth("2")
            .translate(20, 20)
            .lineCap("round");
    }

    public SVGBuilder setText(String text) {
        this.text = text;
        return this;
    }

    public String build(double width, double height) {
        sb.append("<svg width=\"");
        sb.append(width + 20);
        sb.append("\" height=\"");
        sb.append(height + 20);
        sb.append("\" xmlns=\"http://www.w3.org/2000/svg\">\n");
        for (String path : elements) {
            sb.append("\t").append(path).append("\n");
        }
        if (text != null) {
            addTextNode();
        }
        sb.append("</svg>");
        return sb.toString();
    }

    public String build() {
        sb.append("<svg width=\"240\" height=\"240\" xmlns=\"http://www.w3.org/2000/svg\">\n");
        for (String path : elements) {
            sb.append("\t").append(path).append("\n");
        }
        if (text != null) {
            addTextNode();
        }
        sb.append("</svg>");
        return sb.toString();
    }

    private void addTextNode() {
        sb.append("<circle cx=\"120\" cy=\"120\" r=\"25\" fill=\"black\" stroke=\"none\" />\n");
        sb.append("<text x=\"0\" y=\"0\" transform=\"translate(120,120)\" fill=\"white\" text-anchor=\"middle\" dominant-baseline=\"middle\" font-weight=\"bold\" font-size=\"1.5em\">");
        sb.append(text);
        sb.append("</text>\n");
    }
}
