package com.core.edge;

import com.core.math.Point2D;
import com.core.utility.GeometryHelper;

import java.util.ArrayList;
import java.util.List;

public class ArcEdge implements Edge {
    private Point2D startPoint;
    private Point2D endPoint;
    private String edgeId;
    private String originalEdgeId;
    private double radius;
    private boolean largeArc;
    private boolean sweep;
    private final List<Edge> children = new ArrayList<>();

    public ArcEdge() {
        this.startPoint = null;
        this.endPoint = null;
        this.edgeId = "";
        this.originalEdgeId = "";
    }

    public ArcEdge(double radius, boolean largeArc, boolean sweep, Point2D startPoint, Point2D endPoint) {
        this.radius = radius;
        this.largeArc = largeArc;
        this.sweep = sweep;
        this.startPoint = startPoint;
        this.endPoint = endPoint;
        this.edgeId = "";
        this.originalEdgeId = "";
    }

    @Override
    public Point2D getStartPoint() {
        return startPoint;
    }

    public void setStartPoint(Point2D startPoint) {
        this.startPoint = startPoint;
    }

    @Override
    public Point2D getEndPoint() {
        return endPoint;
    }

    public void setEndPoint(Point2D endPoint) {
        this.endPoint = endPoint;
    }

    @Override
    public boolean getIsLargeArc() {
        return largeArc;
    }

    public void setIsLargeArc(boolean l) {
        this.largeArc = l;
    }

    @Override
    public boolean getIsSweep() {
        return sweep;
    }

    public void setIsSweep(boolean l) {
        this.sweep = l;
    }

    @Override
    public Edge copy() {
        ArcEdge edge = new ArcEdge();
        edge.setEdgeId(this.edgeId);
        edge.setOriginalEdgeId(this.originalEdgeId);
        edge.setStartPoint(this.startPoint.copy());
        edge.setEndPoint(this.endPoint.copy());
        edge.setLargeArc(this.largeArc);
        edge.setRadius(this.radius);
        edge.setLargeArc(this.largeArc);
        edge.setSweep(this.sweep);
        return edge;
    }

    @Override
    public void reverse() {
        Point2D temp = this.startPoint;
        this.startPoint = this.endPoint;
        this.endPoint = temp;
        //this.sweep = !this.sweep;
    }

    @Override
    public void debug() {
        System.out.print(this.edgeId + " [(" + this.startPoint.x + ", " + this.startPoint.y +
            ") => (" + this.endPoint.x + ", " + this.endPoint.y + ")]");
    }

    @Override
    public void rotate(double angle) {
        Point2D sp = Point2D.rotatePoint(Math.toRadians(angle), startPoint);
        Point2D ep = Point2D.rotatePoint(Math.toRadians(angle), endPoint);
        this.setStartPoint(sp);
        this.setEndPoint(ep);

        for (Edge child : children) {
            child.rotate(angle);
        }
    }

    @Override
    public Type getEdgeType() {
        return Type.Arc;
    }

    @Override
    public String getEdgeId() {
        return edgeId;
    }

    @Override
    public String getOriginalEdgeId() {
        return originalEdgeId;
    }

    public void setEdgeId(String edgeId) {
        this.edgeId = edgeId;
    }

    public void setOriginalEdgeId(String originalEdgeId) {
        this.originalEdgeId = originalEdgeId;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    public boolean isLargeArc() {
        return largeArc;
    }

    public void setLargeArc(boolean largeArc) {
        this.largeArc = largeArc;
    }

    public boolean isSweep() {
        return sweep;
    }

    public void setSweep(boolean sweep) {
        this.sweep = sweep;
    }

    public List<Edge> getChildren() {
        return children;
    }

    @Override
    public double getLength() {
        return GeometryHelper.findArcLength(startPoint, endPoint, radius, isLargeArc());
    }
}
