package com.core.math;

public class Line {
    private String id;
    private Point2D from;
    private Point2D to;

    public Line(String id, Point2D from, Point2D to) {
        this.id = id;
        this.from = from;
        this.to = to;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Point2D getFrom() {
        return from;
    }

    public void setFrom(Point2D from) {
        this.from = from;
    }

    public Point2D getTo() {
        return to;
    }

    public void setTo(Point2D to) {
        this.to = to;
    }
}
