package com.core.edge;

import com.core.math.Point2D;

import java.util.List;

public interface Edge {

    public enum Type {
        Straight,
        Arc,
        CubicCurve
    }
    String getEdgeId();

    String getOriginalEdgeId();

    Point2D getStartPoint();

    Point2D getEndPoint();

    Edge copy();

    void reverse();

    void debug();

    void rotate(double angle);

    Type getEdgeType();

    List<Edge> getChildren();

    double getRadius();

    double getLength();

    boolean getIsLargeArc();

    boolean getIsSweep();
}
