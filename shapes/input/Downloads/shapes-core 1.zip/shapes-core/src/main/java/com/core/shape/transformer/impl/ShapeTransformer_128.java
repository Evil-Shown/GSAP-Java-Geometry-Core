package com.core.shape.transformer.impl;

import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.edge.builder.EdgeBuilder;
import com.core.math.Point2D;
import com.core.shape.Param;
import com.core.shape.ParamList;
import com.core.shape.ShapeConstants;
import com.core.shape.transformer.ShapeTransformer;
import com.core.utility.EdgeDimCutTuple;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ShapeTransformer_128 extends ShapeTransformer {
    @Override
    public List<Edge> resize(List<Param> params, Map<String, Double> services) {
        ParamList p = new ParamList(params);
        double R = p.getParam("R").getValue();

        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E1")) {
            trimLeft += services.get("E1");
        }

        Point2D p0 = new Point2D(trimLeft, trimBottom + R);
        Point2D p1 = new Point2D(trimLeft + R * 2, trimBottom + R);

        calculateArea(params);
        List<Edge> edges = new EdgeBuilder()
                .startPoint(p0)
                .arcEdge(R, true, false, p1)
                .arcEdge(R, true, false, p0)
                .build();

        calculateCircumference(edges);
        return edges;

    }

    @Override
    public EdgeDimCutTuple resize2(List<Param> params, Map<String, Double> services, Map<String, Double> coatingRemovals) {
        ParamList p = new ParamList(params);
        double R = p.getParam("R").getValue();

        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E1")) {
            trimLeft += services.get("E1");
        }

        Point2D p0 = new Point2D(trimLeft, trimBottom + R);
        Point2D p1 = new Point2D(trimLeft + R * 2, trimBottom + R);

        List<Edge> edges = new EdgeBuilder()
                .startPoint(p0)
                .arcEdge(R, true, false, p1)
                .arcEdge(R, true, false, p0)
                .build();

        List<Edge> dimLines = new ArrayList<>();

        dimLines.add(new StraightEdge(new Point2D(p0.x + R - 75, p0.y), new Point2D(p0.x + R - 75, p0.y + R),
                ShapeConstants.R));

        calculateArea(params);
        calculateCircumference(edges);
        double sR = services.getOrDefault("E1", 0.0);
        double sB = services.getOrDefault("E1", 0.0);
        double sL = services.getOrDefault("E1", 0.0);

        Point2D cP0 = new Point2D(trimLeft-sL, trimBottom-sB);
        Point2D cP1 = new Point2D(cP0.x , cP0.y + R +sB);
        Point2D cP2 = new Point2D(cP0.x + 2*R + sL + sR,cP1.y);

        List<Edge> cEdges = new EdgeBuilder()
                .startPoint(cP1)
                .arcEdge(R + sR, true, false, cP2)
                .arcEdge(R + sR, true, false, cP1)
                .build();


        double sRc = coatingRemovals.getOrDefault("E2", 0.0);
        double sBc = coatingRemovals.getOrDefault("E1", 0.0);

        Point2D crP0 = new Point2D(trimLeft+sRc, trimBottom+sBc);
        Point2D crP1 = new Point2D(crP0.x, crP0.y+R-sBc);
        Point2D crP2 = new Point2D(crP1.x + 2*R -sBc - sRc,crP1.y );

        List<Edge> crEdges = new EdgeBuilder()
                .startPoint(crP1)
                .arcEdge(R - sRc, true, false, crP2)
                .arcEdge(R - sRc, true, false, crP1)
                .build();

        return new EdgeDimCutTuple(edges, dimLines, cEdges, crEdges);
    }

    private void calculateArea(List<Param> params) {
        ParamList p = new ParamList(params);
        double R = p.getParam(ShapeConstants.R).getValue();
        this.area = Math.PI * R * R;
    }
}
