package com.core.shape.transformer.impl;

import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.edge.builder.EdgeBuilder;
import com.core.math.Point2D;
import com.core.shape.Param;
import com.core.shape.ParamList;
import com.core.shape.ShapeConstants;
import com.core.shape.transformer.ShapeTransformer;
import com.core.utility.EdgeDimCutTuple;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ShapeTransformer_129 extends ShapeTransformer {
    @Override
    public List<Edge> resize(List<Param> params, Map<String, Double> services) {
        ParamList p = new ParamList(params);
        double H = p.getParam("H").getValue();
        double L= p.getParam("L").getValue();
        double R = p.getParam("R").getValue();

        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E6")) {
            trimLeft += services.get("E6");
        }

        Point2D p0 = new Point2D(trimLeft, trimBottom);
        Point2D p1 = new Point2D(p0.x + L , p0.y);
        Point2D p2 = new Point2D(p1.x ,p1.y + H - R);
        Point2D p3 = new Point2D(p2.x-R, p2.y + R);
        Point2D p4 = new Point2D(p0.x+R, p2.y + R);
        Point2D p5 = new Point2D(p0.x, p4.y - R);

        calculateArea(params);
        List<Edge> edges = new EdgeBuilder()
                .startPoint(p0)
                .straightEdge(p1)
                .straightEdge(p2)
                .arcEdge(R, false, false, p3)
                .straightEdge(p4)
                .arcEdge(R, false, false, p5)
                .straightEdge(p0)
                .build();

        calculateCircumference(edges);
        return edges;
    }

    @Override
    public EdgeDimCutTuple resize2(List<Param> params, Map<String, Double> services, Map<String, Double> coatingRemovals) {
        ParamList p = new ParamList(params);
        double H = p.getParam("H").getValue();
        double L= p.getParam("L").getValue();
        double R = p.getParam("R").getValue();

        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E6")) {
            trimLeft += services.get("E6");
        }

        Point2D p0 = new Point2D(trimLeft, trimBottom);
        Point2D p1 = new Point2D(p0.x + L , p0.y);
        Point2D p2 = new Point2D(p1.x ,p1.y + H - R);
        Point2D p3 = new Point2D(p2.x-R, p2.y + R);
        Point2D p4 = new Point2D(p0.x+R, p2.y + R);
        Point2D p5 = new Point2D(p0.x, p4.y - R);

        List<Edge> edges = new EdgeBuilder()
                .startPoint(p0)
                .straightEdge(p1)
                .straightEdge(p2)
                .arcEdge(R, false, false, p3)
                .straightEdge(p4)
                .arcEdge(R, false, false, p5)
                .straightEdge(p0)
                .build();

        List<Edge> dimLines = new ArrayList<>();
        dimLines.add(new StraightEdge(p0, p1, ShapeConstants.L));
        dimLines.add(new StraightEdge(p1, new Point2D(p1.x, p2.y + R), ShapeConstants.H));
        dimLines.add(new StraightEdge(new Point2D(p2.x  , p3.y),p3,  ShapeConstants.R));

        calculateCircumference(edges);
        calculateArea(params);

        double sT = services.getOrDefault("E4", 0.0);
        double sR = services.getOrDefault("E2", 0.0);
        double sB = services.getOrDefault("E1", 0.0);
        double sL = services.getOrDefault("E6", 0.0);
        double Rn1 = R + sL;
        double Rn2 = R + sR;
        Point2D cP0 = new Point2D(trimLeft-sL, trimBottom-sB);
        Point2D cP1 = new Point2D(cP0.x  + L + sL + sR, cP0.y);
        Point2D cP2 = new Point2D(cP1.x,cP1.y + H - R + sB + sT);
        Point2D cP3 = new Point2D(cP2.x - Rn2, cP0.y + H + sB + sT);
        Point2D cP4 = new Point2D(cP0.x + Rn1, cP3.y );
        Point2D cP5 = new Point2D(cP0.x , cP2.y);

        List<Edge> cEdges = new EdgeBuilder()
                .startPoint(cP0)
                .straightEdge(cP1)
                .straightEdge(cP2)
                .arcEdge(Rn2, false, false, cP3)
                .straightEdge(cP4)
                .arcEdge(Rn1, false, false, cP5)
                .straightEdge(cP0)
                .build();

        double t = coatingRemovals.getOrDefault("E4", 0.0);
        double r = coatingRemovals.getOrDefault("E2", 0.0);
        double b = coatingRemovals.getOrDefault("E1", 0.0);
        double l = coatingRemovals.getOrDefault("E6", 0.0);
        double t1 = coatingRemovals.getOrDefault("E3", 0.0);
        double t2 = coatingRemovals.getOrDefault("E5", 0.0);

        Point2D crP00 = new Point2D(trimLeft, trimBottom);
        Point2D crP0 = new Point2D(trimLeft+l, trimBottom+b);
        Point2D crP1 = new Point2D(crP00.x + L-r, crP0.y);
        Point2D crP2 = new Point2D(crP1.x,crP00.y + H -R);
        Point2D crP3 = new Point2D(crP00.x + L - t1,crP2.y);
        Point2D crP4 = new Point2D(crP00.x + L - R,crP00.y+H-t1);
        Point2D crP5 = new Point2D(crP4.x,crP00.y+H-t);
        Point2D crP6 = new Point2D(crP00.x+R,crP5.y);
        Point2D crP7 = new Point2D(crP6.x,crP00.y+H-t2);
        Point2D crP8 = new Point2D(crP00.x+t2,crP2.y);
        Point2D crP9 = new Point2D(crP0.x,crP2.y);
        List<Edge> crEdges = new EdgeBuilder()
                .startPoint(crP0)
                .straightEdge(crP1)
                .straightEdge(crP2)
                .straightEdge(crP3)
                .arcEdge(R-t1, false, false, crP4)
                .straightEdge(crP5)
                .straightEdge(crP6)
                .straightEdge(crP7)
                .arcEdge(R-t2, false, false, crP8)
                .straightEdge(crP9)
                .straightEdge(crP0)
                .build();

        return new EdgeDimCutTuple(edges, dimLines, cEdges, crEdges);
    }

    private void calculateArea(List<Param> params) {
        ParamList p = new ParamList(params);
        double R = p.getParam(ShapeConstants.R).getValue();
        double L = p.getParam(ShapeConstants.L).getValue();
        double H = p.getParam(ShapeConstants.H).getValue();

        this.area =L*H - 2 * (R * R- Math.PI* R *R * 0.25);

    }
}
