package com.core.math;

public class Vector2D {
    public double x;
    public double y;

    public Vector2D() {
        this.x = 0;
        this.y = 0;
    }

    public Vector2D(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public Vector2D(Point2D point) {
        this.x = point.x;
        this.y = point.y;
    }

    public static Vector2D create(Point2D a, Point2D b) {
        return new Vector2D(b.x - a.x, b.y - a.y);
    }

    public static Vector2D create(Vector2D a, Vector2D b) {
        return new Vector2D(b.x - a.x, b.y - a.y);
    }

    public static double distance(Vector2D a, Vector2D b) {
        Vector2D v = new Vector2D(a.x - b.x, a.y - b.y);
        return v.length();
    }

    public double length() {
        return Math.sqrt(x * x + y * y);
    }

    public double lengthSq() {
        return (x * x + y * y);
    }

    public void normalize() {
        double magnitude = length();
        if (magnitude == 0.0) {
            throw new RuntimeException("Invalid math operation");
        }
        x /= magnitude;
        y /= magnitude;
    }

    public Vector2D normalized() {
        double magnitude = length();
        if (magnitude == 0.0) {
            throw new RuntimeException("Invalid math operation");
        }
        return new Vector2D(x / magnitude, y / magnitude);
    }

    public double angle() {
        return Math.atan2(y, x);
    }

    public void add(Vector2D v) {
        this.x += v.x;
        this.y += v.y;
    }

    public void add(double x, double y) {
        this.x += x;
        this.y += y;
    }

    public Vector2D added(Vector2D v) {
        return new Vector2D(this.x + v.x, this.y + v.y);
    }

    public void subtract(Vector2D v) {
        this.x -= v.x;
        this.y -= v.y;
    }

    public void subtract(double x, double y) {
        this.x -= x;
        this.y -= y;
    }

    public Vector2D subtracted(Vector2D v) {
        return new Vector2D(this.x - v.x, this.y - v.y);
    }

    public void multiply(double scalar) {
        x *= scalar;
        y *= scalar;
    }

    public Vector2D multiplied(double scalar) {
        return new Vector2D(x * scalar, y * scalar);
    }

    public void divide(double scalar) {
        if (scalar == 0.0) {
            throw new RuntimeException("Invalid math operation");
        }
        x /= scalar;
        y /= scalar;
    }

    public Vector2D divided(double scalar) {
        if (scalar == 0.0) {
            throw new RuntimeException("Invalid math operation");
        }
        return new Vector2D(x / scalar, y / scalar);
    }

    public void rotate(double angle) {
        double cos = Math.cos(angle);
        double sin = Math.sin(angle);
        double rx = x * cos - y * sin;
        y = x * sin + y * cos;
        x = rx;
    }

    public Vector2D rotated(double angle) {
        double cos = Math.cos(angle);
        double sin = Math.sin(angle);
        return new Vector2D(x * cos - y * sin, x * sin + y * cos);
    }

    public double dot(Vector2D v) {
        return (this.x * v.x + this.y * v.y);
    }

    public double dot(double x, double y) {
        return (this.x * x + this.y * y);
    }

    public double cross(Vector2D v) {
        return (this.x * v.y - this.y * v.x);
    }

    public double cross(double x, double y) {
        return (this.x * y - this.y * x);
    }

    public Vector2D copy() {
        return new Vector2D(x, y);
    }

    @Override
    public String toString() {
        return "Vector2D[" + x + ", " + y + "]";
    }

    public Point2D toPoint() {
        return new Point2D(x, y);
    }

}