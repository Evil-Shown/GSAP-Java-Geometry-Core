package com.core.utility;

import com.core.edge.Edge;

import java.util.List;

public record EdgeDimCutTuple(List<Edge> edges, List<Edge> dimLines, List<Edge> cutEdges, List<Edge> coatingEdges) {
}
