package com.core;

import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.math.Point2D;
import com.core.math.EdgesDxf;
import com.core.shape.Shape;
import com.core.shape.transformer.impl.ShapeTransformer_100;

import java.util.Arrays;
import java.util.List;

public class MainTest {
    public static void main(String[] args) {
        //ShapeLibrary shapeLibrary = ShapeLibrary.initialize("");

        //Shape shape = shapeLibrary.createShape("11");

        //System.out.println(shape.getThumbnailSVG());

        ShapeTransformer_100 t = new ShapeTransformer_100();

        StraightEdge e1 = new StraightEdge(
                new Point2D(0, 0),
                new Point2D(100, 0));
        StraightEdge e2 = new StraightEdge(
                new Point2D(100, 0),
                new Point2D(100, 50));
        StraightEdge e3 = new StraightEdge(
                new Point2D(100, 50),
                new Point2D(0, 100));
        StraightEdge e4 = new StraightEdge(
                new Point2D(0, 100),
                new Point2D(0, 0));

        List<Edge> edges = Arrays.asList(e1, e2, e3, e4);

        System.out.println("Original: ");
        for (Edge e : edges) { e.debug(); }
        Point2D p = new Point2D(0, 0);
        EdgesDxf a =   new EdgesDxf(p, p, false,0,0,0, false);
        System.out.println("Original: " + a.y);
        List<Edge> flipped = t.flipHorizontal(edges);

        System.out.println("\nFlipped: ");
        for (Edge e : flipped) { e.debug(); }



    }
}
