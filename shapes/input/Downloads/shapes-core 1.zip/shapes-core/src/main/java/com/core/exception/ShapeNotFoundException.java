package com.core.exception;

public class ShapeNotFoundException extends RuntimeException {

    public ShapeNotFoundException(String shapeNo) {
        super("Shape not found for : " + shapeNo);
    }
}
