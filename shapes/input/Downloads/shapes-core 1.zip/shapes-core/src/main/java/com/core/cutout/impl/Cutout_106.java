package com.core.cutout.impl;

import com.core.cutout.CornerCutout;
import com.core.cutout.CutoutViewCreator;
import com.core.cutout.EdgeCutout;
import com.core.cutout.attachment.Attachment;
import com.core.cutout.attachment.CornerAttachment;
import com.core.cutout.attachment.EdgeAttachment;
import com.core.edge.ArcEdge;
import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.math.Point2D;
import com.core.math.Vector2D;
import com.core.shape.ParamList;
import com.core.svg.SVGBuilder;
import com.core.svg.SVGBuilder2;
import com.core.utility.GeometryHelper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.core.math.Line;

public class Cutout_106 extends CornerCutout {

    public Cutout_106(String cutoutNo, Attachment attachment) {
        super(106, cutoutNo, (CornerAttachment) attachment);
    }

    //@Override
    public Point2D attach(int idx, List<Edge> edges, List<Edge> baseEdges, Point2D previousPoint) {
        return null;
    }

    @Override
public CutoutAttachInfo attach(int idx, Edge currEdge, Edge nextEdge, List<Edge> edges,List<Edge> DxFedges, List<Line> DimLines, CutoutAttachInfo previousInfo, boolean dxf) {
        ParamList p = new ParamList(params);
        double W = p.getParam("W").getValue();
        double H = p.getParam("H").getValue();
        double R = p.getParam("R").getValue();

        Vector2D currVec = Vector2D.create(currEdge.getEndPoint(), currEdge.getStartPoint());
        currVec.normalize();
        currVec.multiply(W);

        Vector2D vw = new Vector2D(currEdge.getEndPoint());
        vw.add(currVec);

        Vector2D nextVec = Vector2D.create(nextEdge.getStartPoint(), nextEdge.getEndPoint());
        nextVec.normalize();
        nextVec.multiply(H);

        Vector2D vh = new Vector2D(nextEdge.getStartPoint());
        vh.add(nextVec);

        Vector2D vt = vw.added(nextVec);
        Vector2D r1 = Vector2D.create(vt, vw);
        r1.normalize();
        r1.multiply(R);
        Vector2D va = vt.copy();
        va.add(r1);

        Vector2D r2 = Vector2D.create(vt, vh);
        r2.normalize();
        r2.multiply(R);
        Vector2D vb = vt.copy();
        vb.add(r2);

        StraightEdge e1 = new StraightEdge(currEdge.getStartPoint(), new Point2D(vw));
        e1.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-1");
        e1.setOriginalEdgeId(currEdge.getOriginalEdgeId());
        edges.add(e1);
        DxFedges.add(e1);

        StraightEdge e2 = new StraightEdge(e1.getEndPoint(), new Point2D(va));
        e2.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-2");
        edges.add(e2);
        DxFedges.add(e2);

        ArcEdge e3 = new ArcEdge(R, true, true, e2.getEndPoint(), new Point2D(vb));
        e3.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-3");
        //edge.getChildren().add(e3);
        if(dxf)
            edges.add(e3);

        ArcEdge eDxf3 = new ArcEdge(R, true, true, new Point2D(vb), e2.getEndPoint());
        eDxf3.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-3");
        //edge.getChildren().add(e3);
        DxFedges.add(eDxf3);

        StraightEdge e4 = new StraightEdge(e3.getEndPoint(), new Point2D(vh));
        e4.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-4");
        edges.add(e4);
        DxFedges.add(e4);

        StraightEdge e5 = new StraightEdge(e4.getEndPoint(), nextEdge.getEndPoint());
        e5.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-5");
        e5.setOriginalEdgeId(currEdge.getOriginalEdgeId());
        edges.add(e5);
        DxFedges.add(e5);

        CutoutAttachInfo info = new CutoutAttachInfo();
        info.isOnNextEdge = true;
        info.lastPoint = e5.getStartPoint();

        calculateWaste();

        return info;
    }

    public static CutoutViewCreator createCutoutViewCreator() {
        return new CutoutViewCreator() {

            @Override
            public SVGBuilder2 getThumbnailBuilder() {
                return new SVGBuilder2(180, 180)
                    .pathBuilder()
                    .strokeOpacity("0.25")
                    .startPath(0, 30)
                    .lineTo(0, 50)
                    .endPath(false)
                    .pathBuilder()
                    //.startPath(0, 30)
                    .startPath(0, 50)
                    .lineTo(120, 50)
                    .arcTo(20, 20, 140, 70, true, true)
                    .lineTo(140, 130)
                    //.lineTo(160, 130)
                    .endPath(false)
                    .pathBuilder()
                    .strokeOpacity("0.25")
                    .startPath(140, 130)
                    .lineTo(160, 130)
                    .endPath(false);
            }

            @Override
            public SVGBuilder2 getPreviewBuilder() {
                return new SVGBuilder2(200, 200)
                        .pathBuilder()
                        .strokeOpacity("0.25")
                        .startPath(10, 30)
                        .lineTo(10, 50)
                        .endPath(false)
                        .pathBuilder()
                        //.startPath(0, 30)
                        .startPath(10, 50)
                        .lineTo(130, 50)
                        .arcTo(20, 20, 150, 70, true, true)
                        .lineTo(150, 130)
                        //.lineTo(160, 130)
                        .endPath(false)
                        .pathBuilder()
                        .strokeOpacity("0.25")
                        .startPath(150, 130)
                        .lineTo(170, 130)
                        .endPath(false)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(0, 130)
                        .lineToWithText(0, 50, "H")
                        .endPath(false)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(10, 0)
                        .lineToWithText(150, 0, "W")
                        .endPath(false)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(150, 50)
                        .lineToWithText(150, 70, "R")
                        .endPath(false);
            }

            @Override
            public Type getCutoutType() {
                return Type.Corner;
            }

            @Override
            public List<String> getParamNames() {
                return Arrays.asList("W", "H", "R");
            }

            @Override
            public List<String> getCutoutMappingParamNames() {
                return Arrays.asList("W", "H");
            }

        };
    }

    private void calculateWaste() {
        ParamList p = new ParamList(params);
        double R = p.getParam("R").getValue();
        waste = R * R - ((Math.PI * R * R) / 4.0);
    }
}
