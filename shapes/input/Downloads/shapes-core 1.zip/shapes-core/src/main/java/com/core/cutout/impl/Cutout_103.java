package com.core.cutout.impl;

import com.core.cutout.CutoutViewCreator;
import com.core.cutout.EdgeCutout;
import com.core.cutout.attachment.Attachment;
import com.core.cutout.attachment.EdgeAttachment;
import com.core.edge.ArcEdge;
import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.exception.InvalidAttachmentException;
import com.core.math.Point2D;
import com.core.math.Vector2D;
import com.core.shape.ParamList;
import com.core.svg.SVGBuilder;
import com.core.svg.SVGBuilder2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.core.math.Line;

public class Cutout_103 extends EdgeCutout {

    public Cutout_103(String cutoutNo, Attachment attachment) {
        super(103, cutoutNo, (EdgeAttachment) attachment);
    }

    //@Override
    public Point2D attach(int idx, List<Edge> edges, List<Edge> baseEdges, Point2D previousPoint) {
        return null;
    }

    @Override
public CutoutAttachInfo attach(int idx, Edge currEdge, Edge nextEdge, List<Edge> edges,List<Edge> DxFedges, List<Line> DimLines, CutoutAttachInfo previousInfo, boolean dxf) {
        ParamList p = new ParamList(params);
        double W = p.getParam("W").getValue();
        double H = p.getParam("H").getValue();
        double R = W / 2.0;
        double offset = attachment.getOffset();

        Vector2D edgeVec = Vector2D.create(currEdge.getStartPoint(), currEdge.getEndPoint());

        if (!attachment.isStartOffset()) {
            offset = edgeVec.length() - offset;
        }

        Vector2D v1 = edgeVec.normalized();
        if(attachment.isStartOffset())
            v1.multiply(offset);
        else
            v1.multiply(offset - W );

        Vector2D p1 = new Vector2D(currEdge.getStartPoint());
        p1.add(v1);

        Point2D startPoint = currEdge.getStartPoint();
        if (previousInfo != null) {
            edges.remove(edges.size() - 1);
            startPoint = previousInfo.lastPoint;
        }

        StraightEdge e1 = new StraightEdge(startPoint, new Point2D(p1));
        e1.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-1");
        e1.setOriginalEdgeId(currEdge.getOriginalEdgeId());
        edges.add(e1);
        DxFedges.add(e1);

        Vector2D v2 = edgeVec.normalized();
        v2.multiply(H);
        v2.rotate(Math.toRadians(90.0));

        Vector2D p2 = new Vector2D(e1.getEndPoint());
        p2.add(v2);

        StraightEdge e2 = new StraightEdge(e1.getEndPoint(), new Point2D(p2));
        e2.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-2");
        edges.add(e2);
        DxFedges.add(e2);

        Vector2D v3 = edgeVec.normalized();
        v3.multiply(W);

        Vector2D p3 = new Vector2D(e2.getEndPoint());
        p3.add(v3);

        ArcEdge e3 = new ArcEdge(R, true, true, e2.getEndPoint(), new Point2D(p3));
        e3.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-3");
        //edge.getChildren().add(e3);
        if(dxf) {
            edges.add(e3);
        }
        ArcEdge eDxF3 = new ArcEdge(R, true, true, new Point2D(p3), e2.getEndPoint());
        eDxF3.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-3");
        //edge.getChildren().add(e3);
        DxFedges.add(eDxF3);

        Vector2D v4 = edgeVec.normalized();
        v4.multiply(H);
        v4.rotate(Math.toRadians(-90.0));

        Vector2D p4 = new Vector2D(e3.getEndPoint());
        p4.add(v4);

        StraightEdge e4 = new StraightEdge(e3.getEndPoint(), new Point2D(p4));
        e4.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-4");
        edges.add(e4);
        DxFedges.add(e4);

        StraightEdge e5 = new StraightEdge(e4.getEndPoint(), currEdge.getEndPoint());
        e5.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-5");
        e5.setOriginalEdgeId(currEdge.getOriginalEdgeId());
        edges.add(e5);
        DxFedges.add(e5);

        CutoutAttachInfo info = new CutoutAttachInfo();
        info.isOnNextEdge = false;
        info.lastPoint = e5.getStartPoint();

        calculateWaste();
        calculateCircumference(List.of(e2, e3, e4));

        Point2D connerPoint = calculateConnerPoint(currEdge,attachment.isStartOffset());
        Point2D cutoutCenterPoint = calculateCutoutCenter(currEdge,attachment.isStartOffset());
        DimLines.add(new Line("E",cutoutCenterPoint, connerPoint ));

        return info;
    }

    public static CutoutViewCreator createCutoutViewCreator() {
        return new CutoutViewCreator() {

            @Override
            public SVGBuilder2 getThumbnailBuilder() {
                return new SVGBuilder2(180, 180)
                    .pathBuilder()
                    .strokeOpacity("0.25")
                    .startPath(0, 160)
                    .lineTo(30, 160)
                    .endPath(false)
                    .pathBuilder()
                    //.startPath(0, 160)
                    .startPath(30, 160)
                    .lineTo(30, 50)
                    .arcTo(25, 25, 130, 50, true, true)
                    .lineTo(130, 160)
                    //.lineTo(160, 160)
                    .endPath(false)
                    .pathBuilder()
                    .strokeOpacity("0.25")
                    .startPath(130, 160)
                    .lineTo(160, 160)
                    .endPath(false);
            }

            @Override
            public SVGBuilder2 getPreviewBuilder() {
                return new SVGBuilder2(200, 200)
                        .pathBuilder()
                        .strokeOpacity("0.25")
                        .startPath(10, 160)
                        .lineTo(40, 160)
                        .endPath(false)
                        .pathBuilder()
                        //.startPath(0, 160)
                        .startPath(40, 160)
                        .lineTo(40, 50)
                        .arcTo(25, 25, 140, 50, true, true)
                        .lineTo(140, 160)
                        //.lineTo(160, 160)
                        .endPath(false)
                        .pathBuilder()
                        .strokeOpacity("0.25")
                        .startPath(140, 160)
                        .lineTo(170, 160)
                        .endPath(false)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(40, 170)
                        .lineToWithText(140, 170, "W")
                        .endPath(false)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(0, 160)
                        .lineToWithText(0, 50, "H")
                        .endPath(false);
            }

            @Override
            public Type getCutoutType() {
                return Type.Edge;
            }

            @Override
            public List<String> getParamNames() {
                return Arrays.asList("W", "H");
            }

            @Override
            public List<String> getCutoutMappingParamNames() {
                return Arrays.asList("W", "H");
            }
        };
    }

    private StraightEdge getStraightEdge(List<Edge> edges) {
        for (Edge edge : edges) {
            if (edge.getEdgeId().equalsIgnoreCase(attachment.getEdgeId())) {
                if (edge.getEdgeType() == Edge.Type.Straight) {
                    return (StraightEdge) edge;
                }
                throw new InvalidAttachmentException("Edge [" + attachment.getEdgeId() + "] is not a straight edge");
            }
        }
        throw new InvalidAttachmentException("Edge [" + attachment.getEdgeId() + "] is not found");
    }

    private void calculateWaste() {
        ParamList p = new ParamList(params);
        double W = p.getParam("W").getValue();
        double H = p.getParam("H").getValue();
        double R = W / 2.0;
        waste = W * H + (Math.PI * R * R) / 2.0;
    }
}
