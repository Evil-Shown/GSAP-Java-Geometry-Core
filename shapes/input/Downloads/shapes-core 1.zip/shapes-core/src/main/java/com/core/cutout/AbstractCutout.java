package com.core.cutout;

import com.core.edge.Edge;
import com.core.math.Line;
import com.core.math.Point2D;
import com.core.shape.Param;

import java.util.ArrayList;
import java.util.List;

public abstract class AbstractCutout implements Cutout {

    public static class CutoutAttachInfo {
        public Point2D lastPoint;
        public boolean isOnNextEdge;
    }

    private long cutoutId;
    private final int internalCutoutId;
    private final String cutoutNo;

    protected double circumference;
    protected double waste;
    protected final List<Param> params = new ArrayList<>();

    public AbstractCutout(int internalCutoutId, String cutoutNo) {
        this.internalCutoutId = internalCutoutId;
        this.cutoutNo = cutoutNo;
        this.circumference = 0.0;
        this.waste = 0.0;
    }

    @Override
    public double getCircumference() {
        return this.circumference;
    }

    @Override
    public double getWaste() {
        return this.waste;
    }

    public int getInternalCutoutId() {
        return internalCutoutId;
    }

    @Override
    public long getCutoutId() {
        return cutoutId;
    }

    @Override
    public void setCutoutId(long cutoutId) {
        this.cutoutId = cutoutId;
    }

    public String getCutoutNo() {
        return cutoutNo;
    }

    public Cutout setParam(String name, double value) {
        for (Param param : getParams()) {
            if (param.getName().equalsIgnoreCase(name)) {
                param.setValue(value);
                return this;
            }
        }
        getParams().add(new Param(name, value));
        return this;
    }

    public List<Param> getParams() {
        return this.params;
    }

    /*public abstract Point2D attach(int idx,
                                   List<Edge> edges,
                                   List<Edge> baseEdges,
                                   Point2D previousPoint);*/

    public abstract CutoutAttachInfo attach(int idx,
                                            Edge currEdge,
                                            Edge nextEdge,
                                            List<Edge> edges,
                                            List<Edge> DxFedges,
                                            List<Line> DimLines,
                                            CutoutAttachInfo previousInfo, boolean dxf);

    protected void calculateCircumference(List<Edge> edges) {
        this.circumference = 0.0;
        for (Edge edge : edges) {
            this.circumference += edge.getLength();
        }
    }
}
