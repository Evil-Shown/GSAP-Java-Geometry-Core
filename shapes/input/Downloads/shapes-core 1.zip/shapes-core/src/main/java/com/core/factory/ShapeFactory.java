package com.core.factory;

import com.core.cutout.CutoutView;
import com.core.cutout.CutoutViewCreator;
import com.core.cutout.Cutouts;
import com.core.shape.Shape;
import com.core.shape.ShapeView;
import com.core.utility.CustomShapeLoader;
import com.core.utility.ShapeBuilder;
import com.core.utility.ShapeLibraryHelper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.logging.Logger;

public class ShapeFactory {
    private final static Logger LOGGER = Logger.getLogger(ShapeFactory.class.getName());

    private final Map<Integer, Function<String, ShapeBuilder>> shapeBuilderMap = new HashMap<>();
    private final Map<Integer, CutoutViewCreator> cutoutViewCreatorMap = new HashMap<>();

    public ShapeFactory(String filePath) {
        LOGGER.info("Shape library loading started");

        loadStandardShapes();

        CustomShapeLoader customShapeLoader = new CustomShapeLoader(filePath);
        if (!customShapeLoader.load()) {
            LOGGER.info("Custom shape loading failed");
        }

        Cutouts.initialize(cutoutViewCreatorMap);
        LOGGER.info("Shape library initializing completed");
    }

    private void loadStandardShapes() {
        shapeBuilderMap.put(100, ShapeLibraryHelper.create_100());
        shapeBuilderMap.put(101, ShapeLibraryHelper.create_101());
        shapeBuilderMap.put(102, ShapeLibraryHelper.create_102());
        shapeBuilderMap.put(103, ShapeLibraryHelper.create_103());
        shapeBuilderMap.put(104, ShapeLibraryHelper.create_104());
        shapeBuilderMap.put(105, ShapeLibraryHelper.create_105());
        shapeBuilderMap.put(106, ShapeLibraryHelper.create_106());
        shapeBuilderMap.put(107, ShapeLibraryHelper.create_107());
        shapeBuilderMap.put(108, ShapeLibraryHelper.create_108());
        shapeBuilderMap.put(109, ShapeLibraryHelper.create_109());
        shapeBuilderMap.put(110, ShapeLibraryHelper.create_110());
        shapeBuilderMap.put(111, ShapeLibraryHelper.create_111());
        shapeBuilderMap.put(112, ShapeLibraryHelper.create_112());
        shapeBuilderMap.put(113, ShapeLibraryHelper.create_113());
        shapeBuilderMap.put(114, ShapeLibraryHelper.create_114());
        shapeBuilderMap.put(115, ShapeLibraryHelper.create_115());
        shapeBuilderMap.put(116, ShapeLibraryHelper.create_116());
        shapeBuilderMap.put(117, ShapeLibraryHelper.create_117());
        shapeBuilderMap.put(118, ShapeLibraryHelper.create_118());
        shapeBuilderMap.put(119, ShapeLibraryHelper.create_119());
        shapeBuilderMap.put(120, ShapeLibraryHelper.create_120());
        shapeBuilderMap.put(121, ShapeLibraryHelper.create_121());
        shapeBuilderMap.put(122, ShapeLibraryHelper.create_122());
        shapeBuilderMap.put(123, ShapeLibraryHelper.create_123());
        shapeBuilderMap.put(124, ShapeLibraryHelper.create_124());
        shapeBuilderMap.put(125, ShapeLibraryHelper.create_125());
        shapeBuilderMap.put(126, ShapeLibraryHelper.create_126());
        shapeBuilderMap.put(127, ShapeLibraryHelper.create_127());
        shapeBuilderMap.put(128, ShapeLibraryHelper.create_128());
        shapeBuilderMap.put(129, ShapeLibraryHelper.create_129());
        shapeBuilderMap.put(130, ShapeLibraryHelper.create_130());
        shapeBuilderMap.put(131, ShapeLibraryHelper.create_131());
//        shapeBuilderMap.put(132, ShapeLibraryHelper.create_132());
//        shapeBuilderMap.put(133, ShapeLibraryHelper.create_133());
//        shapeBuilderMap.put(134, ShapeLibraryHelper.create_134());
        shapeBuilderMap.put(135, ShapeLibraryHelper.create_135());
        shapeBuilderMap.put(136, ShapeLibraryHelper.create_136());
        shapeBuilderMap.put(137, ShapeLibraryHelper.create_137());
        shapeBuilderMap.put(138, ShapeLibraryHelper.create_138());

    }

    public Shape createShape(int internalShapeId, String shapeNoText) {
        return shapeBuilderMap.get(internalShapeId).apply(shapeNoText).build();
    }

    public ShapeView createShapeView(int internalShapeId, String shapeNoText) {
        return shapeBuilderMap.get(internalShapeId).apply(shapeNoText).buildThumbnailShape();
    }

    public CutoutView createCutoutView(int internalCutoutId, String cutoutNoText) {
        CutoutViewCreator creator = cutoutViewCreatorMap.get(internalCutoutId);

        String thumbnail = creator.getThumbnailBuilder().build();
        String preview = creator.getPreviewBuilder().build();
        String cutoutType = creator.getCutoutType().name();

        return new CutoutView(internalCutoutId, cutoutNoText, thumbnail, preview, cutoutType);
    }

    public List<Integer> getAllInternalShapeIds() {
        return shapeBuilderMap.keySet().stream().sorted().toList();
    }

    public List<Integer> getAllInternalCutoutIds() {
        return cutoutViewCreatorMap.keySet().stream().sorted().toList();
    }

    public List<String> getCutoutParams(int internalCutoutId) {
        CutoutViewCreator creator = cutoutViewCreatorMap.get(internalCutoutId);
        return creator.getParamNames();
    }

    public List<String> getCutoutMappingParamNames(int internalCutoutId) {
        CutoutViewCreator creator = cutoutViewCreatorMap.get(internalCutoutId);
        return creator.getCutoutMappingParamNames();
    }
}
