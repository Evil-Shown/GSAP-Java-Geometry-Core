package com.core.shape.transformer.impl;

import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.edge.builder.EdgeBuilder;
import com.core.math.Point2D;
import com.core.shape.Param;
import com.core.shape.ParamList;
import com.core.shape.ShapeConstants;
import com.core.shape.transformer.ShapeTransformer;
import com.core.utility.EdgeDimCutTuple;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ShapeTransformer_137 extends ShapeTransformer {

    @Override
    public List<Edge> resize(List<Param> params, Map<String, Double> services) {
        ParamList p = new ParamList(params);
        double L = p.getParam(ShapeConstants.L).getValue();
        double L1 = p.getParam(ShapeConstants.L1).getValue();
        double L2 = p.getParam(ShapeConstants.L2).getValue();
        double H = p.getParam(ShapeConstants.H).getValue();

        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E4")) {
            trimLeft += services.get("E4");
        }

        Point2D p0 = new Point2D(trimLeft, trimBottom);
        Point2D p1 = new Point2D(p0.x + L - L2, p0.y);
        Point2D p2 = new Point2D(p1.x + L2, p1.y + H);
        Point2D p3 = new Point2D(p0.x + L1, p2.y);

        List<Edge> edges = new EdgeBuilder()
                .startPoint(p0)
                .straightEdge(p1)
                .straightEdge(p2)
                .straightEdge(p3)
                .straightEdge(p0)
                .build();

        calculateCircumference(edges);
        calculateArea(params);
        return edges;
    }

    @Override
    public EdgeDimCutTuple resize2(List<Param> params, Map<String, Double> services,
            Map<String, Double> coatingRemovals) {
        ParamList p = new ParamList(params);
        double L = p.getParam(ShapeConstants.L).getValue();
        double L1 = p.getParam(ShapeConstants.L1).getValue();
        double L2 = p.getParam(ShapeConstants.L2).getValue();
        double H = p.getParam(ShapeConstants.H).getValue();

        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E4")) {
            trimLeft += services.get("E4");
        }

        Point2D p0 = new Point2D(trimLeft, trimBottom);
        Point2D p1 = new Point2D(p0.x + L - L2, p0.y);
        Point2D p2 = new Point2D(p1.x + L2, p1.y + H);
        Point2D p3 = new Point2D(p0.x + L1, p2.y);
        Point2D p4 = new Point2D(p0.x + L, p0.y);
        Point2D p5 = new Point2D(p0.x , p3.y);

        List<Edge> edges = new EdgeBuilder()
                .startPoint(p0)
                .straightEdge(p1)
                .straightEdge(p2)
                .straightEdge(p3)
                .straightEdge(p0)
                .build();

        calculateCircumference(edges);
        calculateArea(params);

        List<Edge> dimLines = new ArrayList<>();
        dimLines.add(new StraightEdge(p0, p4, ShapeConstants.L));
        dimLines.add(new StraightEdge(p1, p4, ShapeConstants.L1));
        dimLines.add(new StraightEdge(p3, p5, ShapeConstants.L2));
        dimLines.add(new StraightEdge(p4, p2, ShapeConstants.H));

        double sT = services.getOrDefault("E3", 0.0);
        double sR = services.getOrDefault("E2", 0.0);
        double sB = services.getOrDefault("E1", 0.0);
        double sL = services.getOrDefault("E4", 0.0);
        double m = H / L2;
        double c = m * (L2 - L) - sR / Math.cos(Math.atan(m));

        double m1 = H / L1;
        double c1 = sL / Math.cos(Math.atan(m1));

        Point2D cP00 = new Point2D(trimLeft, trimBottom);
        Point2D cP0 = new Point2D(trimLeft - sL, trimBottom - sB);
        Point2D cP1 = new Point2D(cP00.x + (-sB - c) / m, cP0.y);
        Point2D cP2 = new Point2D(cP00.x + (H + sT - c) / m, cP1.y + H + sT + sB);
        Point2D cP3 = new Point2D(cP00.x + (H + sT - c1) / m1, cP2.y);

        List<Edge> cEdges = new EdgeBuilder()
                .startPoint(cP0)
                .straightEdge(cP1)
                .straightEdge(cP2)
                .straightEdge(cP3)
                .straightEdge(cP0)
                .build();

        double sTc = coatingRemovals.getOrDefault("E3", 0.0);
        double sRc = coatingRemovals.getOrDefault("E2", 0.0);
        double sBc = coatingRemovals.getOrDefault("E1", 0.0);
        double sLc = coatingRemovals.getOrDefault("E4", 0.0);
        double c2 = m * (L1 - L) + sRc / Math.cos(Math.atan(m));
        double c3 = sLc / Math.cos(Math.atan(m1));
        Point2D crP00 = new Point2D(trimLeft, trimBottom);
        Point2D crP0 = new Point2D(trimLeft + sLc, trimBottom + sBc);
        Point2D crP1 = new Point2D(crP00.x + (-sBc - c2) / m, crP0.y);
        Point2D crP2 = new Point2D(crP00.x + (H + sT - c2) / m, crP1.y + H - sTc - sBc);
        Point2D crP3 = new Point2D(crP00.x + (H + sT + c3) / m1, cP2.y);
        List<Edge> crEdges = new EdgeBuilder()
                .startPoint(crP0)
                .straightEdge(crP1)
                .straightEdge(crP2)
                .straightEdge(crP3)
                .straightEdge(crP0)
                .build();
        System.out.println("Generated coating removal edges for shape 137.....................");
        return new EdgeDimCutTuple(edges, dimLines, cEdges, crEdges);
    }

    // L*H
    private void calculateArea(List<Param> params) {
        ParamList p = new ParamList(params);
        double W = p.getParam(ShapeConstants.L).getValue();
        double H = p.getParam(ShapeConstants.H).getValue();
        double L1 = p.getParam(ShapeConstants.L1).getValue();
        double L2 = p.getParamValueOrDefault(ShapeConstants.L2, 0.0001);
        this.area = (W * H) - 0.5 * H * (L1 + L2);
    }

}
