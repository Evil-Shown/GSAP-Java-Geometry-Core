package com.core.utility;

import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.logging.Logger;

public class CustomShapeLoader {

    private final static Logger LOGGER = Logger.getLogger(CustomShapeLoader.class.getName());
    String filePath;

    public CustomShapeLoader(String filePath) {
        this.filePath = filePath;
    }

    public boolean load() {
        LOGGER.info("Custom shape loading started");

        InputStream inputStream = getClass().getResourceAsStream(filePath);

        if (inputStream == null) {
            LOGGER.info("Library initialization file not found");
            return false;
        }

        try (InputStreamReader streamReader = new InputStreamReader(inputStream, StandardCharsets.UTF_8);
             BufferedReader reader = new BufferedReader(streamReader)) {

            JSONParser parser = new JSONParser();
            Object object = parser.parse(reader);

            // TODO

        } catch (IOException ex) {
            LOGGER.info("An error occurred while reading library initialization file");
            return false;
        } catch (ParseException ex) {
            LOGGER.info("An error occurred while parsing library initialization file");
            return false;
        }

        LOGGER.info("Custom shape loading completed");
        return true;
    }

}
