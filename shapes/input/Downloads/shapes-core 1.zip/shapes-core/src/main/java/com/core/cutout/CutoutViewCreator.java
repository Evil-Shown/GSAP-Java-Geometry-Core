package com.core.cutout;

import com.core.svg.SVGBuilder;
import com.core.svg.SVGBuilder2;

import java.util.List;

public interface CutoutViewCreator {

    SVGBuilder2 getThumbnailBuilder();
    SVGBuilder2 getPreviewBuilder();
    Cutout.Type getCutoutType();
    List<String> getParamNames();
    List<String> getCutoutMappingParamNames();

}
