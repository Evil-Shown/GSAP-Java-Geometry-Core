package com.core.shape;

import java.util.List;

public class ShapeView {
    private int internalShapeId;
    private String shapeNo;
    private String thumbnailSVG;
    private String previewSVG;
    private List<Param> params;
    private TrimInfo trims;

    public ShapeView() {
    }

    public ShapeView(int internalShapeId, String shapeNo, String thumbnailSVG,
                     String previewSVG, List<Param> params, TrimInfo trims) {
        this.internalShapeId = internalShapeId;
        this.shapeNo = shapeNo;
        this.thumbnailSVG = thumbnailSVG;
        this.previewSVG = previewSVG;
        this.params = params;
        this.trims = trims;
    }

    public int getInternalShapeId() {
        return internalShapeId;
    }

    public void setInternalShapeId(int internalShapeId) {
        this.internalShapeId = internalShapeId;
    }

    public String getShapeNo() {
        return shapeNo;
    }

    public void setShapeNo(String shapeNo) {
        this.shapeNo = shapeNo;
    }

    public String getThumbnailSVG() {
        return thumbnailSVG;
    }

    public void setThumbnailSVG(String thumbnailSVG) {
        this.thumbnailSVG = thumbnailSVG;
    }

    public String getPreviewSVG() {
        return previewSVG;
    }

    public void setPreviewSVG(String previewSVG) {
        this.previewSVG = previewSVG;
    }

    public List<Param> getParams() {
        return params;
    }

    public void setParams(List<Param> params) {
        this.params = params;
    }

    public TrimInfo getTrims() {
        return trims;
    }

    public void setTrims(TrimInfo trims) {
        this.trims = trims;
    }
}
