package com.core.svg;

import com.core.edge.ArcEdge;
import com.core.edge.CubicCurveEdge;
import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.math.Line;
import com.core.shape.TrimLine;
import com.core.utility.MathHelper;

import java.util.Collections;
import java.util.List;
import java.util.Map;

public class SVGShapeBuilder {
    private final SVGShape svgShape;
    private final int translateOffset;

    private SVGShapeBuilder(int translateOffset) {
        this.svgShape = new SVGShape();
        this.translateOffset = translateOffset;
    }

    public static SVGShapeBuilder newBuilder() {
        return new SVGShapeBuilder(10);
    }

    public static SVGShapeBuilder newBuilder(int translateOffset) {
        return new SVGShapeBuilder(translateOffset);
    }

    public SVGShapeBuilder addShapePaths(List<Edge> edges, Map<String, String> edgeColorMap) {
        this.svgShape.getShapePaths().clear();
        for (Edge edge : edges) {
            String d = createD(Collections.singletonList(edge));
            String color = edgeColorMap.getOrDefault(edge.getOriginalEdgeId(), "black");
            this.svgShape.getShapePaths().add(
                new SVGPath(edge.getEdgeId(), d, color, "2", translateOffset, translateOffset,
                    0, 0, 0, 0, 0, 0, edge.getLength()));
        }

        //String d = createD(edges);
        //this.svgShape.setShapePath(new SVGPath("", d, "black", "2",
        //  translateOffset, translateOffset, 0, 0, 0, 0, 0, 0, 0));
        return this;
    }

    public SVGShapeBuilder addControlPath(Edge edge) {
        String d = createD(Collections.singletonList(edge));
        double cx = (edge.getStartPoint().x + edge.getEndPoint().x) / 2.0;
        double cy = (edge.getStartPoint().y + edge.getEndPoint().y) / 2.0;
        this.svgShape.getControlPaths().add(new SVGPath(edge.getEdgeId(), d, "red", "10",
          translateOffset, translateOffset, cx, cy, edge.getStartPoint().x, edge.getStartPoint().y,
          edge.getEndPoint().x, edge.getEndPoint().y,
          MathHelper.round2(calculateEdgeLength(edge))));
        return this;
    }

    public SVGShapeBuilder addTrimLine(TrimLine trimLine) {
        this.svgShape.getTrimLines().add(new SVGPath(trimLine.getId(), "", "", "",
          translateOffset, translateOffset,
          0, 0,
          trimLine.getStartPoint().x, trimLine.getStartPoint().y,
          trimLine.getEndPoint().x, trimLine.getEndPoint().y,
          MathHelper.round2(trimLine.getEndPoint().distanceTo(trimLine.getStartPoint()))));
        return this;
    }

    public SVGShapeBuilder addDimLine(Line dimLine) {
        this.svgShape.getDimLines().add(new SVGPath(dimLine.getId(), "", "", "",
            translateOffset, translateOffset,
            0, 0,
            dimLine.getFrom().x, dimLine.getFrom().y,
            dimLine.getTo().x, dimLine.getTo().y,
            MathHelper.round2(dimLine.getFrom().distanceTo(dimLine.getTo()))));
        return this;
    }

    public SVGShapeBuilder addCutoutDimLine(Line dimLine) {
        this.svgShape.getCutoutDimLines().add(new SVGPath(dimLine.getId(), "", "", "",
                translateOffset, translateOffset,
                0, 0,
                dimLine.getFrom().x, dimLine.getFrom().y,
                dimLine.getTo().x, dimLine.getTo().y,
                MathHelper.round2(dimLine.getFrom().distanceTo(dimLine.getTo()))));
        return this;
    }

    public SVGShapeBuilder addInteriorCutoutPath(Long id, List<Edge> edges) {
        String d = createD(edges);
        this.svgShape.getInteriorCutoutPaths().put(id,
            new SVGPath("IE-" + id, d, "black", "2", translateOffset, translateOffset,
                0, 0, 0, 0, 0, 0, 0));
        return this;
    }

    public SVGShape build(double width, double height) {
        this.svgShape.setWidth(width + translateOffset * 4);
        this.svgShape.setHeight(height + translateOffset * 4);

        return this.svgShape;
    }

    private String createD(List<Edge> edges) {
        if (edges.isEmpty()) {
            throw new RuntimeException("Empty edges not supported");
        }
        StringBuilder sb = new StringBuilder();
        sb.append("M ");
        sb.append(edges.get(0).getStartPoint().x);
        sb.append(" ");
        sb.append(edges.get(0).getStartPoint().y);
        sb.append(" ");

        for (Edge edge : edges) {
            if (edge.getEdgeType() == Edge.Type.Straight) {
                StraightEdge e = (StraightEdge) edge;
                sb.append("L ");
                sb.append(e.getEndPoint().x);
                sb.append(" ");
                sb.append(e.getEndPoint().y);
                sb.append(" ");
            } else if (edge.getEdgeType() == Edge.Type.Arc) {
                ArcEdge e = (ArcEdge) edge;
                sb.append("A ");
                sb.append(e.getRadius());
                sb.append(" ");
                sb.append(e.getRadius());
                sb.append(" ");
                sb.append("0"); // No rotation
                sb.append(" ");
                sb.append(e.isLargeArc() ? "1" : "0");
                sb.append(" ");
                sb.append(e.isSweep() ? "1" : "0");
                sb.append(" ");
                sb.append(e.getEndPoint().x);
                sb.append(" ");
                sb.append(e.getEndPoint().y);
                sb.append(" ");
            } else if (edge.getEdgeType() == Edge.Type.CubicCurve) {
                CubicCurveEdge e = (CubicCurveEdge) edge;
                sb.append("C ");
                sb.append(e.getControlSP().x);
                sb.append(" ");
                sb.append(e.getControlSP().y);
                sb.append(", ");
                sb.append(e.getControlEP().x);
                sb.append(" ");
                sb.append(e.getControlEP().y);
                sb.append(", ");
                sb.append(e.getEndPoint().x);
                sb.append(" ");
                sb.append(e.getEndPoint().y);
                sb.append(" ");
            } else {
                throw new RuntimeException("Edge type not supported");
            }
        }
        return sb.toString();
    }

    private double calculateEdgeLength(Edge edge) {
        // TODO: handle curved edges
        return edge.getEndPoint().distanceTo(edge.getStartPoint());
    }

}
