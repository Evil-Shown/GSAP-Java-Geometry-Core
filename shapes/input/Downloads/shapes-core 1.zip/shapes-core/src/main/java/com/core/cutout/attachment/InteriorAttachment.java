package com.core.cutout.attachment;

import com.core.cutout.Cutout;
import com.core.edge.Edge;

public class InteriorAttachment implements Attachment {

    private String edgeId;
    private double offsetX;
    private double offsetY;

    public String getEdgeId() {
        return edgeId;
    }

    public void setEdgeId(String edgeId) {
        this.edgeId = edgeId;
    }

    public double getOffsetX() {
        return offsetX;
    }

    public void setOffsetX(double offsetX) {
        this.offsetX = offsetX;
    }

    public double getOffsetY() {
        return offsetY;
    }

    public void setOffsetY(double offsetY) {
        this.offsetY = offsetY;
    }

    @Override
    public Cutout.Type getAttachmentType() {
        return Cutout.Type.Interior;
    }

    public static class Builder {
        private InteriorAttachment attachment = new InteriorAttachment();

        private Builder() {}

        public InteriorAttachment.Builder setEdgeId(String edgeId) {
            this.attachment.setEdgeId(edgeId);
            return this;
        }

        public InteriorAttachment.Builder setOffsetX(double offsetX) {
            this.attachment.setOffsetX(offsetX);
            return this;
        }

        public InteriorAttachment.Builder setOffsetY(double offsetY) {
            this.attachment.setOffsetY(offsetY);
            return this;
        }

        public InteriorAttachment build() {
            return attachment;
        }
    }

    public static InteriorAttachment.Builder newBuilder() {
        return new InteriorAttachment.Builder();
    }
}
