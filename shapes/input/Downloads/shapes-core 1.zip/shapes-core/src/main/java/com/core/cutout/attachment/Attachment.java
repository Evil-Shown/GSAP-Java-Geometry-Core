package com.core.cutout.attachment;

import com.core.cutout.Cutout;

public interface Attachment {
    Cutout.Type getAttachmentType();

}
