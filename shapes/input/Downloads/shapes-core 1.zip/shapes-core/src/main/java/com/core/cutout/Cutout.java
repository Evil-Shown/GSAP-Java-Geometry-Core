package com.core.cutout;

import com.core.edge.Edge;
import com.core.shape.Param;

import java.util.List;

public interface Cutout {

    public enum Type {
        Edge,
        Corner,
        Interior
    }

    void setCutoutId(long cutoutId);

    long getCutoutId();

    String getCutoutNo();

    Type getCutoutType();

    double getCircumference();

    double getWaste();

    Cutout setParam(String name, double value);

}
