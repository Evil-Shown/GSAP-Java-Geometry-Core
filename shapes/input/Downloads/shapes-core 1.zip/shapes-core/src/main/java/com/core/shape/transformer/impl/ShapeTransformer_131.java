package com.core.shape.transformer.impl;

import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.edge.builder.EdgeBuilder;
import com.core.math.Point2D;
import com.core.shape.Param;
import com.core.shape.ParamList;
import com.core.shape.ShapeConstants;
import com.core.shape.transformer.ShapeTransformer;
import com.core.utility.EdgeDimCutTuple;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ShapeTransformer_131 extends ShapeTransformer {
    @Override
    public List<Edge> resize(List<Param> params, Map<String, Double> services) {
        ParamList p = new ParamList(params);
        double L = p.getParam("L").getValue();
        double R = L/2;

        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E2")) {
            trimLeft += services.get("E2");
        }

        Point2D p0 = new Point2D(trimLeft, trimBottom);
        Point2D p1 = new Point2D(p0.x + L, p0.y);

        calculateArea(params);
        List<Edge> edges = new EdgeBuilder()
                .startPoint(p0)
                .straightEdge(p1)
                .arcEdge(R, true, false, p0)
                .build();

        calculateCircumference(edges);
        calculateArea(params);

        return edges;
    }

    @Override
    public EdgeDimCutTuple resize2(List<Param> params, Map<String, Double> services, Map<String, Double> coatingRemovals) {
        ParamList p = new ParamList(params);
        double L = p.getParam("L").getValue();
        double R = L/2;

        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();
        double ory=trimBottom;
        double orx=trimLeft;

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E2")) {
            trimLeft += services.get("E2");
        }

        Point2D p0 = new Point2D(trimLeft, trimBottom);
        Point2D p1 = new Point2D(p0.x + L, p0.y);

        List<Edge> edges = new EdgeBuilder()
                .startPoint(p0)
                .straightEdge(p1)
                .arcEdge(R, true, false, p0)
                .build();

        List<Edge> dimLines = new ArrayList<>();
        dimLines.add(new StraightEdge(p0, p1, ShapeConstants.L));

        calculateCircumference(edges);
        calculateArea(params);
        double sT = services.getOrDefault("E2", 0.0);
        double sR = services.getOrDefault("E2", 0.0);
        double sB = services.getOrDefault("E1", 0.0);
        double sL = services.getOrDefault("E2", 0.0);

        double x = Math.sqrt((R+sT)*(R+sT)-sB*sB);
        Point2D cP0 = new Point2D(trimLeft-sL, trimBottom-sB);
        Point2D cP1 = new Point2D(cP0.x+R+sT-x, cP0.y);
        Point2D cP2 = new Point2D(cP1.x + x * 2, cP0.y);

        List<Edge> cEdges = new EdgeBuilder()
                .startPoint(cP1)
                .straightEdge(cP2)
                .arcEdge(R + sT , true, false, cP1)
                .build();


        double b = coatingRemovals.getOrDefault("E1", 0.0);
        double t = coatingRemovals.getOrDefault("E2", 0.0);
        double Rnew = R-t;

        double x1 = R - Math.sqrt(Rnew*Rnew-b*b);
        double x2 = R + Math.sqrt(Rnew*Rnew-b*b);

        Point2D crP0 = new Point2D(trimLeft+x1, trimBottom+b);
        Point2D crP1 = new Point2D(trimLeft+x2, crP0.y);

        List<Edge> crEdges = new EdgeBuilder()
                .startPoint(crP0)
                .straightEdge(crP1)
                .arcEdge(Rnew, false, false, crP0)
                .build();

         return new EdgeDimCutTuple(edges, dimLines, cEdges, crEdges);
    }

    private void calculateArea(List<Param> params) {
        ParamList p = new ParamList(params);
        double L = p.getParam(ShapeConstants.L).getValue();
        double R = L/2;

        this.area =0.5 * Math.PI * R *R;

    }
}
