package com.core.cutout.impl;

import com.core.cutout.CutoutViewCreator;
import com.core.cutout.EdgeCutout;
import com.core.cutout.InteriorCutout;
import com.core.cutout.attachment.Attachment;
import com.core.cutout.attachment.EdgeAttachment;
import com.core.cutout.attachment.InteriorAttachment;
import com.core.edge.ArcEdge;
import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.math.Point2D;
import com.core.math.Vector2D;
import com.core.shape.ParamList;
import com.core.svg.SVGBuilder;
import com.core.svg.SVGBuilder2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.core.math.Line;

public class Cutout_107 extends InteriorCutout {

    public Cutout_107(String cutoutNo, Attachment attachment) {
        super(107, cutoutNo, (InteriorAttachment) attachment);
    }

    //@Override
    public Point2D attach(int idx, List<Edge> edges, List<Edge> baseEdges, Point2D previousPoint) {
        return null;
    }

    @Override
public CutoutAttachInfo attach(int idx, Edge currEdge, Edge nextEdge, List<Edge> edges,List<Edge> DxFedges, List<Line> DimLines, CutoutAttachInfo previousInfo, boolean dxf) {
        ParamList p = new ParamList(params);
        double W = p.getParam("W").getValue();
        double H = p.getParam("H").getValue();
        double R = p.getParam("R").getValue();

        Point2D cutoutBottomLeftConner = calculateCutoutCenter(currEdge, nextEdge, W,H,true);
        Point2D dimCenter = calculateCutoutCenter(currEdge, nextEdge, 0,0,true);
        Point2D a = new Point2D(cutoutBottomLeftConner.x, cutoutBottomLeftConner.y + R);
        Point2D b = new Point2D(cutoutBottomLeftConner.x, cutoutBottomLeftConner.y + H - R);
        Point2D c = new Point2D(cutoutBottomLeftConner.x + R, cutoutBottomLeftConner.y + H);
        Point2D d = new Point2D(cutoutBottomLeftConner.x + W - R, cutoutBottomLeftConner.y + H);
        Point2D e = new Point2D(cutoutBottomLeftConner.x + W, cutoutBottomLeftConner.y + H - R);
        Point2D f = new Point2D(cutoutBottomLeftConner.x + W, cutoutBottomLeftConner.y + R);
        Point2D g = new Point2D(cutoutBottomLeftConner.x + W - R, cutoutBottomLeftConner.y );
        Point2D h = new Point2D(cutoutBottomLeftConner.x + R, cutoutBottomLeftConner.y);

        StraightEdge e1 = new StraightEdge(a, b);
        ArcEdge e2 = new ArcEdge(R, false, true, b, c);
        StraightEdge e3 = new StraightEdge(c, d);
        ArcEdge e4 = new ArcEdge(R, false, true, d, e);
        StraightEdge e5 = new StraightEdge(e, f);
        ArcEdge e6 = new ArcEdge(R, false, true, f, g);
        StraightEdge e7 = new StraightEdge(g, h);
        ArcEdge e8 = new ArcEdge(R, false, true, h, a);

        edges.add(e1);
        edges.add(e2);
        edges.add(e3);
        edges.add(e4);
        edges.add(e5);
        edges.add(e6);
        edges.add(e7);
        edges.add(e8);

        StraightEdge ed1 = new StraightEdge(a, b);
        ArcEdge ed2 = new ArcEdge(R, false, true, c, b);
        StraightEdge ed3 = new StraightEdge(c, d);
        ArcEdge ed4 = new ArcEdge(R, false, true, e, d);
        StraightEdge ed5 = new StraightEdge(e, f);
        ArcEdge ed6 = new ArcEdge(R, false, true, g, f);
        StraightEdge ed7 = new StraightEdge(g, h);
        ArcEdge ed8 = new ArcEdge(R, false, true, a, h);

        DxFedges.add(ed1);
        DxFedges.add(ed2);
        DxFedges.add(ed3);
        DxFedges.add(ed4);
        DxFedges.add(ed5);
        DxFedges.add(ed6);
        DxFedges.add(ed7);
        DxFedges.add(ed8);

        Point2D[] points = offsets(currEdge, nextEdge);
        Point2D offsetXPoint = points[0];
        Point2D offsetYPoint = points[1];

        DimLines.add(new Line("X",offsetXPoint, dimCenter ));
        DimLines.add(new Line("Y",offsetYPoint, dimCenter ));

        return previousInfo;
    }

    public static CutoutViewCreator createCutoutViewCreator() {
        return new CutoutViewCreator() {

            @Override
            public SVGBuilder2 getThumbnailBuilder() {
                return new SVGBuilder2(180, 180)
                    .pathBuilder()
                    .startPath(0, 40)
                    .arcTo(10, 10, 10, 30, false, true)
                    .lineTo(150, 30)
                    .arcTo(10, 10, 160, 40, false, true)
                    .lineTo(160, 120)
                    .arcTo(10, 10, 150, 130, false, true)
                    .lineTo(10, 130)
                    .arcTo(10, 10, 0, 120, false, true)
                    .lineTo(0, 40)
                    .endPath(true);
            }

            @Override
            public SVGBuilder2 getPreviewBuilder() {
                return new SVGBuilder2(200, 200)
                        .pathBuilder()
                        .startPath(15, 40)
                        .arcTo(10, 10, 25, 30, false, true)
                        .lineTo(165, 30)
                        .arcTo(10, 10, 175, 40, false, true)
                        .lineTo(175, 120)
                        .arcTo(10, 10, 165, 130, false, true)
                        .lineTo(25, 130)
                        .arcTo(10, 10, 15, 120, false, true)
                        .lineTo(15, 40)
                        .endPath(true)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(165, 30)
                        .lineToWithText(165, 40, "R")
                        .endPath(false)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(0, 130)
                        .lineToWithText(0, 30, "H")
                        .endPath(false)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(15, 170)
                        .lineToWithText(175, 170, "W")
                        .endPath(false);
            }

            @Override
            public Type getCutoutType() {
                return Type.Interior;
            }

            @Override
            public List<String> getParamNames() {
                return Arrays.asList("W", "H", "R", "A");
            }

            @Override
            public List<String> getCutoutMappingParamNames() {
                return Arrays.asList("W", "H");
            }
        };
    }
}
