package com.core.utility;

import com.core.math.Point2D;
import com.core.math.Vector2D;

public class GeometryHelper {

    public static Point2D findMidPointOfArc(Point2D start, Point2D end, double r) {
        Vector2D dist = Vector2D.create(end, start);
        double d = dist.length() / 2.0;

        double l = Math.sqrt(r * r - d * d);
        double h = r - l;
        dist.normalize();
        dist.multiply(h);

        dist.rotate(Math.toRadians(90.0));

        Vector2D mp = new Vector2D((start.x + end.x) / 2.0, (start.y + end.y) / 2.0);

        mp.add(dist);
        return new Point2D(mp);
    }

    // Backward compatible version - calculates center using old logic
    public static Point2D findCircleCenterOfArc(Point2D start, Point2D end, double r) {
        Vector2D dist = Vector2D.create(end, start);
        double d = dist.length() / 2.0;

        double l = Math.sqrt(r * r - d * d);
        dist.normalize();
        dist.multiply(l);

        dist.rotate(Math.toRadians(-90.0));

        Vector2D mp = new Vector2D((start.x + end.x) / 2.0, (start.y + end.y) / 2.0);

        mp.add(dist);
        return new Point2D(mp);
    }

    public static Point2D findCircleCenterOfArc(Point2D start, Point2D end, double r, boolean largeArc, boolean sweep) {
        double d2 = Math.pow(end.x - start.x, 2) + Math.pow(end.y - start.y, 2);
        double d = Math.sqrt(d2);

        if (d > 2 * r) {
            r = d / 2.0;
        }

        double h = Math.sqrt(Math.max(0, r * r - d2 / 4.0));

        double mx = (start.x + end.x) / 2.0;
        double my = (start.y + end.y) / 2.0;

        // Perpendicular vector normalized — points to the LEFT of the chord (start→end)
        double px = -(end.y - start.y) / d;
        double py = (end.x - start.x) / d;

        // Center selection based on SVG arc flags:
        // CCW (sweep=false) + small (largeArc=false) → center on LEFT → usePlus = true
        // CCW (sweep=false) + large (largeArc=true) → center on RIGHT → usePlus = false
        // CW (sweep=true) + small (largeArc=false) → center on RIGHT → usePlus = false
        // CW (sweep=true) + large (largeArc=true) → center on LEFT → usePlus = true
        // Pattern: usePlus when largeArc == sweep
        boolean usePlus = (largeArc == sweep);

        if (usePlus) {
            return new Point2D(mx + h * px, my + h * py);
        } else {
            return new Point2D(mx - h * px, my - h * py);
        }
    }

    public static Point2D findMidPointOfArc(Point2D start, Point2D end, double r, boolean largeArc, boolean sweep) {
        Point2D center = findCircleCenterOfArc(start, end, r, largeArc, sweep);

        double startAngle = Math.atan2(start.y - center.y, start.x - center.x);
        double endAngle = Math.atan2(end.y - center.y, end.x - center.x);

        double diff = endAngle - startAngle;
        if (!sweep) { // CCW
            if (diff <= 0)
                diff += 2 * Math.PI;
        } else { // CW
            if (diff >= 0)
                diff -= 2 * Math.PI;
        }

        double midAngle = startAngle + diff / 2.0;
        return new Point2D(center.x + r * Math.cos(midAngle), center.y + r * Math.sin(midAngle));
    }

    public static double findCornerToArcDistance(Point2D lineIntersectionPoint,
            Point2D line1Point,
            Point2D line2Point,
            double radius) {
        Vector2D p1 = new Vector2D(line1Point);
        Vector2D p2 = new Vector2D(line2Point);

        Vector2D midPoint = p1.added(p2).divided(2.0);
        double d = Vector2D.distance(p1, midPoint);
        double l = Vector2D.distance(midPoint, new Vector2D(lineIntersectionPoint));

        return (l * radius) / d;
    }

    public static double findArcLength(Point2D start, Point2D end, double r, boolean isLarge) {
        Vector2D dist = Vector2D.create(start, end);

        double chord = dist.length();
        if (chord > 2 * r)
            chord = 2 * r;
        double theta = 2 * Math.asin(chord / (2 * r));
        double s = r * theta;
        return isLarge ? ((2 * Math.PI * r) - s) : s;
    }

}
