package com.core.svg;

import com.core.edge.ArcEdge;
import com.core.edge.CubicCurveEdge;
import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.math.Point2D;
import com.core.utility.BoundingBox;

import java.util.List;
import java.util.Map;

public class SVGMapper {

    private static final String EMPTY_STRING = "";

    public String edgeListToSVG(List<Edge> edges, Map<Long, List<Edge>> cutoutEdges, BoundingBox boundingBox) {
        return generate(edges, boundingBox);
    }

    private String generate(List<Edge> edges, BoundingBox boundingBox) {
        SVGBuilder2 svgBuilder = new SVGBuilder2((int)Math.ceil(boundingBox.getWidth()) + 20, (int)Math.ceil(boundingBox.getHeight()) + 20);
        SVGBuilder2.SvgPathBuilder pathBuilder = svgBuilder.pathBuilder();

        if (edges.isEmpty()) {
            return svgBuilder.build();
        }

        //System.out.println("Adding first edge");
        buildFirstEdge(edges.get(0), pathBuilder);

        for (int i = 1; i < edges.size(); i++) {
            //System.out.println("Adding next edge");
            buildNextEdge(edges.get(i), pathBuilder);
        }

        return pathBuilder.endPath(true).build();
    }

    private void buildNextEdge(Edge edge, SVGBuilder2.SvgPathBuilder pathBuilder) {
        if (edge.getEdgeType() == Edge.Type.Straight) {
            StraightEdge straightEdge = (StraightEdge) edge;

            if (straightEdge.getChildren().isEmpty()) {
                Point2D ep = straightEdge.getEndPoint();

                pathBuilder.lineTo(ep.x, ep.y);
                //System.out.println("Next straight edge added");
            } else {
                for (int j = 0; j < straightEdge.getChildren().size(); j++) {
                    buildChildEdge(straightEdge.getChildren().get(j), pathBuilder);
                    //System.out.println("Next straight edge child" + j + " added");
                }
            }
        } else if (edge.getEdgeType() == Edge.Type.Arc) {
            ArcEdge arcEdge = (ArcEdge) edge;
            Point2D ep = arcEdge.getEndPoint();

            pathBuilder.arcTo(arcEdge.getRadius(),
                    arcEdge.getRadius(),
                    ep.x, ep.y,
                    arcEdge.isLargeArc(),
                    arcEdge.isSweep());
            System.out.println("===> large= " + arcEdge.isLargeArc() + " sweep= " + arcEdge.isSweep());
            //System.out.println("Next arc edge added");
        } else if (edge.getEdgeType() == Edge.Type.CubicCurve) {
            CubicCurveEdge cubicCurveEdge = (CubicCurveEdge) edge;
        }
    }

    private void buildFirstEdge(Edge edge, SVGBuilder2.SvgPathBuilder pathBuilder) {
        if (edge.getEdgeType() == Edge.Type.Straight) {
            StraightEdge straightEdge = (StraightEdge) edge;

            if (straightEdge.getChildren().isEmpty()) {
                Point2D sp = straightEdge.getStartPoint();
                Point2D ep = straightEdge.getEndPoint();

                pathBuilder.startPath(sp.x, sp.y);
                pathBuilder.lineTo(ep.x, ep.y);
                //System.out.println("First straight edge added");
            } else {
                for (int j = 0; j < straightEdge.getChildren().size(); j++) {
                    buildChildEdge(straightEdge.getChildren().get(j), pathBuilder);
                    //System.out.println("First straight edge child " + j + " added");
                }
            }
        } else if (edge.getEdgeType() == Edge.Type.Arc) {
            ArcEdge arcEdge = (ArcEdge) edge;
            Point2D sp = arcEdge.getStartPoint();
            Point2D ep = arcEdge.getEndPoint();

            pathBuilder.startPath(sp.x, sp.y);
            pathBuilder.arcTo(arcEdge.getRadius(),
                    arcEdge.getRadius(),
                    ep.x, ep.y,
                    arcEdge.isLargeArc(),
                    arcEdge.isSweep());
            System.out.println("===> large= " + arcEdge.isLargeArc() + " sweep= " + arcEdge.isSweep());
            //System.out.println("First arc edge added");
        } else if (edge.getEdgeType() == Edge.Type.CubicCurve) {
            CubicCurveEdge cubicCurveEdge = (CubicCurveEdge) edge;
        }
    }

    private void buildChildEdge(Edge child, SVGBuilder2.SvgPathBuilder pathBuilder) {
        buildNextEdge(child, pathBuilder);
    }
}
