package com.core.cutout.impl;

import com.core.cutout.CutoutViewCreator;
import com.core.cutout.EdgeCutout;
import com.core.cutout.InteriorCutout;
import com.core.cutout.attachment.Attachment;
import com.core.cutout.attachment.EdgeAttachment;
import com.core.cutout.attachment.InteriorAttachment;
import com.core.edge.ArcEdge;
import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.math.Point2D;
import com.core.shape.ParamList;
import com.core.svg.SVGBuilder;
import com.core.svg.SVGBuilder2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.core.math.Line;

public class Cutout_108 extends InteriorCutout {

    public Cutout_108(String cutoutNo, Attachment attachment) {
        super(108, cutoutNo, (InteriorAttachment) attachment);
    }

    //@Override
    public Point2D attach(int idx, List<Edge> edges, List<Edge> baseEdges, Point2D previousPoint) {
        return null;
    }

    @Override
public CutoutAttachInfo attach(int idx, Edge currEdge, Edge nextEdge, List<Edge> edges,List<Edge> DxFedges, List<Line> DimLines, CutoutAttachInfo previousInfo, boolean dxf) {
        ParamList p = new ParamList(params);
        double W = p.getParam("W").getValue();
        double R = p.getParam("R").getValue();
        double H = 2 * R;

        Point2D cutoutCenter = calculateCutoutCenter(currEdge, nextEdge,W+R*2, R*2,true);
        Point2D dimCenter = calculateCutoutCenter(currEdge, nextEdge, 0,0,true);
        Point2D p_tl = new Point2D(cutoutCenter.x + R, cutoutCenter.y);
        Point2D p_bl = new Point2D(cutoutCenter.x + R, cutoutCenter.y + H);
        Point2D p_br = new Point2D(cutoutCenter.x + W + R, cutoutCenter.y + H);
        Point2D p_tr = new Point2D(cutoutCenter.x + W + R, cutoutCenter.y );

        StraightEdge e1 = new StraightEdge(p_bl, p_br);
        ArcEdge e2 = new ArcEdge(R, true, true, p_br, p_tr);
        StraightEdge e3 = new StraightEdge(p_tr, p_tl);
        ArcEdge e4 = new ArcEdge(R, false, true, p_tl, p_bl);

        StraightEdge ed1 = new StraightEdge(p_bl, p_br);
        ArcEdge ed2 = new ArcEdge(R, true, true, p_tr, p_br);
        StraightEdge ed3 = new StraightEdge(p_tr, p_tl);
        ArcEdge ed4 = new ArcEdge(R, false, true, p_bl, p_tl);

        edges.add(e1);
        edges.add(e2);
        edges.add(e3);
        edges.add(e4);

        DxFedges.add(ed1);
        DxFedges.add(ed2);
        DxFedges.add(ed3);
        DxFedges.add(ed4);

        Point2D[] points = offsets(currEdge, nextEdge);
        Point2D offsetXPoint = points[0];
        Point2D offsetYPoint = points[1];

        DimLines.add(new Line("X",offsetXPoint,  dimCenter ));
        DimLines.add(new Line("Y",offsetYPoint,  dimCenter ));

        return previousInfo;
    }

    public static CutoutViewCreator createCutoutViewCreator() {
        return new CutoutViewCreator() {

            @Override
            public SVGBuilder2 getThumbnailBuilder() {
                return new SVGBuilder2(180, 180)
                    .pathBuilder()
                    .startPath(30, 110)
                    .arcTo(30, 30, 30, 50, true, true)
                    .lineTo(130, 50)
                    .arcTo(30, 30, 130, 110, true, true)
                    .lineTo(30, 110)
                    .endPath(true);
            }

            @Override
            public SVGBuilder2 getPreviewBuilder() {
                return new SVGBuilder2(200, 200)
                        .pathBuilder()
                        .startPath(40, 110)
                        .arcTo(30, 30, 40, 50, true, true)
                        .lineTo(140, 50)
                        .arcTo(30, 30, 140, 110, true, true)
                        .lineTo(40, 110)
                        .endPath(true)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(40, 17)
                        .lineToWithText(140, 17, "W")
                        .endPath(false)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(40, 80)
                        .lineToWithText(40, 50, "R")
                        .endPath(false);
            }

            @Override
            public Type getCutoutType() {
                return Type.Interior;
            }

            @Override
            public List<String> getParamNames() {
                return Arrays.asList("W", "R", "A");
            }

            @Override
            public List<String> getCutoutMappingParamNames() {
                return Arrays.asList("W", "R");
            }
        };
    }
}
