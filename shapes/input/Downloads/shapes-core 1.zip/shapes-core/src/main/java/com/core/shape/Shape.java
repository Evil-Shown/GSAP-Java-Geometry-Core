package com.core.shape;

import com.core.cutout.Cutout;
import com.core.edge.Edge;
import com.core.utility.EdgeDimCutTuple;

import java.util.List;
import java.util.Map;
import com.core.math.Line;
import java.util.Optional;
public interface Shape {

    String getShapeNo();

    double getCircumference();

    double getArea();

    void resize(List<Param> params);

    void rotate(double angle);

    void updateTrims(double top, double right, double bottom, double left);

    void flipVertical(boolean flip);

    void flipHorizontal(boolean flip);

    Cutout addEdgeCutout(String cutoutId, String edgeId, double offset, boolean startOffset);

    Cutout addCornerCutout(String cutoutId, String edgeId);

    List<Param> getParams();

    TrimInfo getTrims();

    String getThumbnailSVG();

    String getPreviewSVG();

    List<Edge> getAllEdges(Map<String, Double> services,boolean dxf);

    List<Line> getCutOutDims(Map<String, Double> services);

    EdgeDimCutTuple getShapeEdges(Map<String, Double> services,Map<String, Double> coatingRemovals );

    List<TrimLine> getTrimLines(Map<String, Double> services, boolean isShape31);

    Cutout addInteriorCutout(String cutoutNo, String edgeId, double offsetX, double offsetY);

    Map<Long, List<Edge>> getInteriorCutoutEdges(Map<String, Double> services, Map<Long, List<Line>> CutoutDimLine);

    Map<Long, List<Edge>> getInteriorCutoutEdgesDxF(Map<String, Double> services);

}
