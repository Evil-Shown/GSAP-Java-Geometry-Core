package com.core.utility;

import com.core.shape.Param;
import com.core.shape.ShapeImpl;
import com.core.shape.ShapeView;
import com.core.shape.transformer.ShapeTransformer;

public class ShapeBuilder {

    private final ShapeImpl shapeImpl = new ShapeImpl();

    private ShapeBuilder() {
    }

    public static ShapeBuilder newBuilder() {
        return new ShapeBuilder();
    }

    public ShapeBuilder setInternalShapeId(int internalShapeId) {
        this.shapeImpl.setInternalShapeId(internalShapeId);
        return this;
    }

    public ShapeBuilder setShapeNo(String shapeNo) {
        this.shapeImpl.setShapeNo(shapeNo);
        return this;
    }

    public ShapeBuilder addParam(String name, double value) {
        this.shapeImpl.getParams().add(new Param(name, value));
        return this;
    }

    public ShapeBuilder setThumbnailSVG(String svg) {
        this.shapeImpl.setThumbnailSVG(svg);
        return this;
    }

    public ShapeBuilder setPreviewSVG(String svg) {
        this.shapeImpl.setPreviewSVG(svg);
        return this;
    }

    public ShapeBuilder setTransformer(ShapeTransformer transformer) {
        this.shapeImpl.setTransformer(transformer);
        return this;
    }

    public ShapeView buildThumbnailShape() {
        return new ShapeView(
            this.shapeImpl.getInternalShapeId(),
            this.shapeImpl.getShapeNo(),
            this.shapeImpl.getThumbnailSVG(),
            this.shapeImpl.getPreviewSVG(),
            this.shapeImpl.getParams(),
            this.shapeImpl.getTrims()
        );
    }

    public ShapeImpl build() {
        return this.shapeImpl;
    }
}
