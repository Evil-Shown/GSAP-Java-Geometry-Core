package com.core.shape.transformer.impl;

import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.edge.builder.EdgeBuilder;
import com.core.math.Point2D;
import com.core.shape.Param;
import com.core.shape.ParamList;
import com.core.shape.ShapeConstants;
import com.core.shape.transformer.ShapeTransformer;
import com.core.utility.EdgeDimCutTuple;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ShapeTransformer_127 extends ShapeTransformer {
    @Override
    public List<Edge> resize(List<Param> params, Map<String, Double> services) {
        ParamList p = new ParamList(params);
        double H = p.getParam("H").getValue();
        double L = p.getParam("L").getValue();
        double L1 = p.getParam("L1").getValue();

        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E4")) {
            trimLeft += services.get("E4");
        }

        Point2D p0 = new Point2D(trimLeft, trimBottom);
        Point2D p1 = new Point2D(p0.x + L -L1, p0.y);
        Point2D p2 = new Point2D(p0.x +L, p0.y + H);
        Point2D p3 = new Point2D(p0.x + L1, p0.y + H);

        List<Edge> edges = new EdgeBuilder()
                .startPoint(p0)
                .straightEdge(p1)
                .straightEdge(p2)
                .straightEdge(p3)
                .straightEdge(p0)
                .build();

        calculateCircumference(edges);
        calculateArea(params);

        return edges;
    }

    @Override
    public EdgeDimCutTuple resize2(List<Param> params, Map<String, Double> services, Map<String, Double> coatingRemovals) {
        ParamList p = new ParamList(params);
        double H = p.getParam("H").getValue();
        double L = p.getParam("L").getValue();
        double L1 = p.getParam("L1").getValue();

        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E4")) {
            trimLeft += services.get("E4");
        }

        Point2D p0 = new Point2D(trimLeft, trimBottom);
        Point2D p1 = new Point2D(p0.x + L -L1, p0.y);
        Point2D p2 = new Point2D(p0.x +L, p0.y + H);
        Point2D p3 = new Point2D(p0.x + L1, p0.y + H);

        List<Edge> edges = new EdgeBuilder()
                .startPoint(p0)
                .straightEdge(p1)
                .straightEdge(p2)
                .straightEdge(p3)
                .straightEdge(p0)
                .build();

        List<Edge> dimLines = new ArrayList<>();
        dimLines.add(new StraightEdge(new Point2D(p0.x-150, p0.y), new Point2D(p0.x-150, p3.y), ShapeConstants.H));
        dimLines.add(new StraightEdge(p0, new Point2D(p2.x, p0.y), ShapeConstants.L));
        dimLines.add(new StraightEdge(new Point2D(p3.x, p3.y),new Point2D(p0.x, p3.y),  ShapeConstants.L1));

        calculateCircumference(edges);
        calculateArea(params);

        double sT = services.getOrDefault("E3", 0.0);
        double sR = services.getOrDefault("E2", 0.0);
        double sB = services.getOrDefault("E1", 0.0);
        double sL = services.getOrDefault("E4", 0.0);

        Point2D cP0 = new Point2D(trimLeft-sL, trimBottom-sB);
        Point2D cP1 = new Point2D(cP0.x + L-L1 + sL + sR, cP0.y);
        Point2D cP2 = new Point2D(cP0.x + sL + L + sR,cP1.y + H  + sB + sT);
        Point2D cP3 = new Point2D(cP0.x + L1, cP2.y);

        List<Edge> cEdges = new EdgeBuilder()
                .startPoint(cP0)
                .straightEdge(cP1)
                .straightEdge(cP2)
                .straightEdge(cP3)
                .straightEdge(cP0)
                .build();

        double t = coatingRemovals.getOrDefault("E3", 0.0);
        double r = coatingRemovals.getOrDefault("E2", 0.0);
        double b = coatingRemovals.getOrDefault("E1", 0.0);
        double l = coatingRemovals.getOrDefault("E4", 0.0);

        double m = H/L1;
        double thita = Math.atan(m);
        double c = m*(L1-L) + r/Math.cos(thita);
        double x1 = (b-c)/m;
        double x2 = (H-t-c)/m;

        double c1 =-l/Math.cos(thita);
        double x3 = (H-t-c1)/m;
        double x4 = (b-c1)/m;


        Point2D crP00 = new Point2D(trimLeft, trimBottom);
        Point2D crP0 = new Point2D(trimLeft+x4, trimBottom+b);
        Point2D crP1 = new Point2D(crP00.x + x1, crP0.y);
        Point2D crP2 = new Point2D(crP00.x + x2,crP00.y + H -t);
        Point2D crP3 = new Point2D(crP00.x + x3,crP2.y);
        List<Edge> crEdges = new EdgeBuilder()
                .startPoint(crP0)
                .straightEdge(crP1)
                .straightEdge(crP2)
                .straightEdge(crP3)
                .straightEdge(crP0)
                .build();

        return new EdgeDimCutTuple(edges, dimLines, cEdges, crEdges);

    }

    //W*H - ((H - H1) * (W - W2) / 2) - ((H - H2) * (W - W1) / 2)
    private void calculateArea(List<Param> params) {
        ParamList p = new ParamList(params);
        double H = p.getParam(ShapeConstants.H).getValue();
        double L1 = p.getParam(ShapeConstants.L1).getValue();
        double L = p.getParam(ShapeConstants.L).getValue();
        this.area =(L-L1)* H;
    }

}

