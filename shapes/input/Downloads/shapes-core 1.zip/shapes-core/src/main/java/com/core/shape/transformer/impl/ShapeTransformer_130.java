package com.core.shape.transformer.impl;

import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.edge.builder.EdgeBuilder;
import com.core.math.Point2D;
import com.core.shape.Param;
import com.core.shape.ParamList;
import com.core.shape.ShapeConstants;
import com.core.shape.transformer.ShapeTransformer;
import com.core.utility.EdgeDimCutTuple;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ShapeTransformer_130 extends ShapeTransformer {
    @Override
    public List<Edge> resize(List<Param> params, Map<String, Double> services) {
        ParamList p = new ParamList(params);
        double H = p.getParam("H").getValue();
        double H1 = p.getParam("H1").getValue();
        double L = p.getParam("L").getValue();
        double R = p.getParam("R").getValue();

        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E4")) {
            trimLeft += services.get("E4");
        }

        Point2D p0 = new Point2D(trimLeft, trimBottom);
        Point2D p1 = new Point2D(p0.x + L, p0.y);
        Point2D p2 = new Point2D(p1.x, p1.y + H1);
        Point2D p3 = new Point2D(p0.x, p0.y + H);

        calculateArea(params);
        List<Edge> edges = new EdgeBuilder()
                .startPoint(p0)
                .straightEdge(p1)
                .straightEdge(p2)
                .arcEdge(R, false, false, p3)
                .straightEdge(p0)
                .build();

        calculateCircumference(edges);
        return edges;
    }

    @Override
    public EdgeDimCutTuple resize2(List<Param> params, Map<String, Double> services, Map<String, Double> coatingRemovals) {
        ParamList p = new ParamList(params);
        double H = p.getParam("H").getValue();
        double H1 = p.getParam("H1").getValue();
        double L = p.getParam("L").getValue();
        double R = p.getParam("R").getValue();

        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E4")) {
            trimLeft += services.get("E4");
        }

        Point2D p0 = new Point2D(trimLeft, trimBottom);
        Point2D p1 = new Point2D(p0.x + L, p0.y);
        Point2D p2 = new Point2D(p1.x, p1.y + H1);
        Point2D p3 = new Point2D(p0.x, p0.y + H);

        List<Edge> edges = new EdgeBuilder()
                .startPoint(p0)
                .straightEdge(p1)
                .straightEdge(p2)
                .arcEdge(R, false, false, p3)
                .straightEdge(p0)
                .build();

        List<Edge> dimLines = new ArrayList<>();
        dimLines.add(new StraightEdge(p0, p1, ShapeConstants.L));
        dimLines.add(new StraightEdge(new Point2D(p0.x - 150, p0.y), new Point2D(p3.x - 150, p3.y), ShapeConstants.H));
        dimLines.add(new StraightEdge(p1, p2, ShapeConstants.H1));

        calculateArea(params);
        calculateCircumference(edges);
        double sT = services.getOrDefault("E3", 0.0);
        double sR = services.getOrDefault("E2", 0.0);
        double sB = services.getOrDefault("E1", 0.0);
        double sL = services.getOrDefault("E4", 0.0);

        Point2D cP0 = new Point2D(trimLeft-sL, trimBottom-sB);
        Point2D cP1 = new Point2D(cP0.x + L + sL + sR, cP0.y);
        Point2D cP2 = new Point2D(cP1.x,cP1.y + H1 + sB+sT);
        Point2D cP3 = new Point2D(cP0.x, cP0.y + H + sB+sT);

        List<Edge> cEdges = new EdgeBuilder()
                .startPoint(cP0)
                .straightEdge(cP1)
                .straightEdge(cP2)
                .arcEdge(R + sT, false, false, cP3)
                .straightEdge(cP0)
                .build();

        double t = coatingRemovals.getOrDefault("E3", 0.0);
        double r = coatingRemovals.getOrDefault("E2", 0.0);
        double b = coatingRemovals.getOrDefault("E1", 0.0);
        double l = coatingRemovals.getOrDefault("E4", 0.0);

        double ll = Math.sqrt((H-H1)*(H-H1)+L*L)/2;
        double thita = Math.asin(ll/R);
        double alpha = Math.asin((H-H1)/(2*ll));
        double beta = Math.PI/2-thita-alpha;
        double cx = L - R*Math.cos(beta);
        double cy = H1 - R*Math.sin(beta);
        double y1 = Math.sqrt((R-t)*(R-t)-(L-r-cx)*(L-r-cx))+cy;
        double y2 = Math.sqrt((R-t)*(R-t)-(l-cx)*(l-cx))+cy;

        Point2D crP00 = new Point2D(trimLeft, trimBottom);
        Point2D crP0 = new Point2D(trimLeft+l, trimBottom+b);
        Point2D crP1 = new Point2D(crP00.x + L - r, crP0.y);
        Point2D crP2 = new Point2D(crP1.x,crP00.y + y1);
        Point2D crP3 = new Point2D(crP0.x, crP00.y + y2);

        List<Edge> crEdges = new EdgeBuilder()
                .startPoint(crP0)
                .straightEdge(crP1)
                .straightEdge(crP2)
                .arcEdge(R - t, false, false, crP3)
                .straightEdge(crP0)
                .build();

         return new EdgeDimCutTuple(edges, dimLines, cEdges, crEdges);
    }

    private void calculateArea(List<Param> params) {

        ParamList p = new ParamList(params);
        double R = p.getParam(ShapeConstants.R).getValue();
        double L = p.getParam(ShapeConstants.L).getValue();
        double H = p.getParam(ShapeConstants.H).getValue();
        double H1 = p.getParam(ShapeConstants.H1).getValue();

        double a1 = L * (H + H1) / 2;
        double l = Math.sqrt(L * L + (H - H1) * (H - H1)) / 2;
        double thita = Math.asin(l / R) * 2;
        double a2 = R * R * thita;
        double a3 = L * (H - H1) / 2;

        this.area = a1 + a2 - a3;

    }
}
