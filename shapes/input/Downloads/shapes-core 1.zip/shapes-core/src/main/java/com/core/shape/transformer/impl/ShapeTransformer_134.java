package com.core.shape.transformer.impl;

import com.core.edge.ArcEdge;
import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.edge.builder.EdgeBuilder;
import com.core.math.Point2D;
import com.core.shape.Param;
import com.core.shape.ParamList;
import com.core.shape.ShapeConstants;
import com.core.shape.transformer.ShapeTransformer;
import com.core.utility.EdgeDimCutTuple;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ShapeTransformer_134 extends ShapeTransformer {

    @Override
    public List<Edge> resize(List<Param> params, Map<String, Double> services) {
        ParamList p = new ParamList(params);
        double W = p.getParam(ShapeConstants.W).getValue();
        double H = p.getParam(ShapeConstants.H).getValue();
        double H1 = p.getParam(ShapeConstants.H1).getValue();
        double A1 = p.getParam(ShapeConstants.A1).getValue();
        double A = p.getParam(ShapeConstants.A).getValue();

        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E4")) {
            trimLeft += services.get("E4");
        }

        Point2D p0 = new Point2D(trimLeft, trimBottom);
        Point2D p1 = new Point2D(p0.x + W, p0.y);
        Point2D p2 = new Point2D(p1.x - H1 * Math.cos(Math.toRadians(A1)),p1.y + H1 * Math.sin(Math.toRadians(A1)));
        Point2D p3 = new Point2D(p0.x + H * Math.cos(Math.toRadians(A)), p0.y+ H * Math.sin(Math.toRadians(A)));

        List<Edge> edges = new EdgeBuilder()
                .startPoint(p0)
                .straightEdge(p1)
                .straightEdge(p2)
                .straightEdge(p3)
                .straightEdge(p0)
                .build();

        calculateCircumference(edges);
        calculateArea(params);
        return edges;
    }

    @Override
    public EdgeDimCutTuple resize2(List<Param> params, Map<String, Double> services, Map<String, Double> coatingRemovals) {
        ParamList p = new ParamList(params);
        double W = p.getParam(ShapeConstants.W).getValue();
        double H = p.getParam(ShapeConstants.H).getValue();
        double H1 = p.getParam(ShapeConstants.H1).getValue();
        double A1 = p.getParam(ShapeConstants.A1).getValue();
        double A = p.getParam(ShapeConstants.A).getValue();

        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E4")) {
            trimLeft += services.get("E4");
        }

        Point2D p0 = new Point2D(trimLeft, trimBottom);
        Point2D p1 = new Point2D(p0.x + W, p0.y);
        Point2D p2 = new Point2D(p1.x - H1 * Math.cos(Math.toRadians(A1)),p1.y + H1 * Math.sin(Math.toRadians(A1)));
        Point2D p3 = new Point2D(p0.x + H * Math.cos(Math.toRadians(A)), p0.y+ H * Math.sin(Math.toRadians(A)));

        List<Edge> edges = new EdgeBuilder()
                .startPoint(p0)
                .straightEdge(p1)
                .straightEdge(p2)
                .straightEdge(p3)
                .straightEdge(p0)
                .build();

        calculateCircumference(edges);
        calculateArea(params);

        List<Edge> dimLines = new ArrayList<>();
        dimLines.add(new StraightEdge(p0, p1, ShapeConstants.W));
        dimLines.add(new StraightEdge(p3, p0, ShapeConstants.H));
        dimLines.add(new StraightEdge(p1, p2,  ShapeConstants.H1));

        double sT = services.getOrDefault("E3", 0.0);
        double sR = services.getOrDefault("E2", 0.0);
        double sB = services.getOrDefault("E1", 0.0);
        double sL = services.getOrDefault("E4", 0.0);

        Point2D cP0 = new Point2D(trimLeft-sL, trimBottom-sB);
        Point2D cP1 = new Point2D(cP0.x + W + sL + sR, p0.y);
        Point2D cP2 = new Point2D(cP1.x - H1 * Math.cos(Math.toRadians(A1))+sR,cP1.y + H1 * Math.sin(Math.toRadians(A1))+sB+sT);
        Point2D cP3 = new Point2D(cP0.x + H * Math.cos(Math.toRadians(A))-sL, cP0.y+ H * Math.sin(Math.toRadians(A))+sB+sT);

        List<Edge> cEdges = new EdgeBuilder()
                .startPoint(cP0)
                .straightEdge(cP1)
                .straightEdge(cP2)
                .straightEdge(cP3)
                .straightEdge(cP0)
                .build();

        double sTc = coatingRemovals.getOrDefault("E3", 0.0);
        double sRc = coatingRemovals.getOrDefault("E2", 0.0);
        double sBc = coatingRemovals.getOrDefault("E1", 0.0);
        double sLc = coatingRemovals.getOrDefault("E4", 0.0);

        Point2D crP0 = new Point2D(trimLeft+sLc, trimBottom+sBc);
        Point2D crP1 = new Point2D(crP0.x + W - sLc - sRc, crP0.y);
        Point2D crP2 = new Point2D(crP1.x+(H1-sTc-sBc)/Math.tan(Math.toRadians(180-A1)),crP1.y + H1 - sTc -sBc);
        Point2D crP3 = new Point2D(crP0.x+(H-sTc-sBc)/Math.tan(Math.toRadians(A)), crP0.y+H- sTc -sBc);
        List<Edge> crEdges = new EdgeBuilder()
                .startPoint(crP0)
                .straightEdge(crP1)
                .straightEdge(crP2)
                .straightEdge(crP3)
                .straightEdge(crP0)
                .build();

        return new EdgeDimCutTuple(edges, dimLines, cEdges, crEdges);
    }

    //L*H
    private void calculateArea(List<Param> params) {
        ParamList p = new ParamList(params);
        double W = p.getParam(ShapeConstants.W).getValue();
        double H = p.getParam(ShapeConstants.H).getValue();
        double H1 = p.getParam(ShapeConstants.H1).getValue();
        double A = p.getParam(ShapeConstants.A).getValue();
        double A1 = p.getParam(ShapeConstants.A1).getValue();

        double x2 = W;
        double x3 = W - H1 * Math.cos(Math.toRadians(A1));
        double y3 = H1 * Math.sin(Math.toRadians(A1));
        double x4 = H * Math.cos(Math.toRadians(A));
        double y4 = H * Math.sin(Math.toRadians(A));
        this.area = 0.5 * Math.abs(x2 * y3 + x3*y4 - x4*y3);
    }

}
