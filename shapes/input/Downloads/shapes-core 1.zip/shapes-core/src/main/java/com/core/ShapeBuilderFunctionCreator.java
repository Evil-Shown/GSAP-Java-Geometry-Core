package com.core;

import com.core.utility.ShapeBuilder;

@FunctionalInterface
public interface ShapeBuilderFunctionCreator {
    ShapeBuilder createBuilder();
}
