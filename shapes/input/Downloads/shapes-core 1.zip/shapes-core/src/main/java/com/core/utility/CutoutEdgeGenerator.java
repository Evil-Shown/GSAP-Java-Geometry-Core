package com.core.utility;

import com.core.cutout.*;
import com.core.cutout.attachment.EdgeAttachment;
import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.shape.ShapeHelper;

import java.util.*;
import com.core.math.Line;

public class CutoutEdgeGenerator {

    private final List<AbstractCutout> cutouts;
    private final List<Edge> baseEdges;

    public CutoutEdgeGenerator(List<AbstractCutout> cutouts, List<Edge> baseEdges) {
        this.cutouts = cutouts;
        this.baseEdges = baseEdges;
    }




    public Map<Long, List<Edge>> generateInteriorCutoutEdges(Map<Long, List<Line>> CutoutDimLine) {
        Map<Long, List<Edge>> cutoutEdges = new HashMap<>();

        cutouts.forEach(cutout -> {
            if (cutout.getCutoutType() == Cutout.Type.Interior) {
                List<Edge> newEdges = new ArrayList<>();
                List<Edge> newDxFEdges = new ArrayList<>();
                List<Line> DimLine = new ArrayList<>();

                InteriorCutout interiorCutout = (InteriorCutout) cutout;

                for (int k = 0; k < baseEdges.size(); k++) {
                    Edge edge = baseEdges.get(k);
                    if (edge.getEdgeId().equalsIgnoreCase(interiorCutout.getAttachment().getEdgeId())) {
                        Edge nextEdge = k == (baseEdges.size() - 1) ? baseEdges.get(0) : baseEdges.get(k + 1);

                        cutout.attach(cutouts.size(), edge, nextEdge, newEdges,newDxFEdges, DimLine, null,true);
                        cutoutEdges.put(cutout.getCutoutId(), newEdges);
                        CutoutDimLine.put(cutout.getCutoutId(), DimLine);

                        /*Vector2D xVec = Vector2D.create(edge.getEndPoint(), edge.getStartPoint());
                        Vector2D yVec = Vector2D.create(nextEdge.getStartPoint(), nextEdge.getEndPoint());

                        xVec.normalize();
                        yVec.normalize();
                        xVec.multiply(interiorCutout.getAttachment().getOffsetX());
                        yVec.multiply(interiorCutout.getAttachment().getOffsetY());

                        Vector2D corner = new Vector2D(edge.getEndPoint());
                        corner.add(xVec);
                        corner.add(yVec);

                        Point2D cutoutCenter = corner.toPoint();
                        StraightEdge e1 = new StraightEdge(edge.getEndPoint(), cutoutCenter);

                        cutoutEdges.put(cutout.getCutoutId(), Arrays.asList(e1));*/
                        break;
                    }
                }
            }else if(cutout.getCutoutType() == Cutout.Type.Edge) {
                List<Edge> newEdges = new ArrayList<>();
                List<Edge> newDxFEdges = new ArrayList<>();
                List<Line> DimLine = new ArrayList<>();

                EdgeCutout edgeCutout = (EdgeCutout) cutout;
                for (int k = 0; k < baseEdges.size(); k++) {
                    Edge edge = baseEdges.get(k);
                    if (edge.getEdgeId().equalsIgnoreCase(edgeCutout.getAttachment().getEdgeId())) {
                        Edge nextEdge = k == (baseEdges.size() - 1) ? baseEdges.get(0) : baseEdges.get(k + 1);

                        cutout.attach(cutouts.size(), edge, nextEdge, newEdges,newDxFEdges, DimLine,null,true);
                        cutoutEdges.put(cutout.getCutoutId(), newEdges);
                        CutoutDimLine.put(cutout.getCutoutId(), DimLine);
                        break;
                    }
                }
      }
            else if(cutout.getCutoutType() == Cutout.Type.Corner) {
                List<Edge> newEdges = new ArrayList<>();
                List<Edge> newDxFEdges = new ArrayList<>();
                List<Line> DimLine = new ArrayList<>();

                CornerCutout cornerCutout = (CornerCutout) cutout;
                for (int k = 0; k < baseEdges.size(); k++) {
                    Edge edge = baseEdges.get(k);
                    if (edge.getEdgeId().equalsIgnoreCase(cornerCutout.getAttachment().getEdgeId())) {
                        Edge nextEdge = k == (baseEdges.size() - 1) ? baseEdges.get(0) : baseEdges.get(k + 1);

                        cutout.attach(cutouts.size(), edge, nextEdge, newEdges,newDxFEdges, DimLine, null,true);
                        cutoutEdges.put(cutout.getCutoutId(), newEdges);
                        break;
                    }
                }
            }
        });
        return cutoutEdges;
    }

    public Map<Long, List<Edge>> generateInteriorCutoutDxFEdges() {
        Map<Long, List<Edge>> cutoutEdges = new HashMap<>();
        cutouts.forEach(cutout -> {
            if (cutout.getCutoutType() == Cutout.Type.Interior) {
                List<Edge> newEdges = new ArrayList<>();
                List<Edge> newDxFEdges = new ArrayList<>();
                List<Line> DimLine = new ArrayList<>();

                InteriorCutout interiorCutout = (InteriorCutout) cutout;

                for (int k = 0; k < baseEdges.size(); k++) {
                    Edge edge = baseEdges.get(k);
                    if (edge.getEdgeId().equalsIgnoreCase(interiorCutout.getAttachment().getEdgeId())) {
                        Edge nextEdge = k == (baseEdges.size() - 1) ? baseEdges.get(0) : baseEdges.get(k + 1);

                        cutout.attach(cutouts.size(), edge, nextEdge, newEdges,newDxFEdges, DimLine, null,true);
                        cutoutEdges.put(cutout.getCutoutId(), newDxFEdges);

                        break;
                    }
                }
            }
            else if (cutout.getCutoutType() == Cutout.Type.Edge) {
                List<Edge> newEdges = new ArrayList<>();
                List<Edge> newDxFEdges = new ArrayList<>();
                List<Line> DimLine = new ArrayList<>();

                EdgeCutout edgeCutout = (EdgeCutout) cutout;

                for (int k = 0; k < baseEdges.size(); k++) {
                    Edge edge = baseEdges.get(k);
                    if (edge.getEdgeId().equalsIgnoreCase(edgeCutout.getAttachment().getEdgeId())) {
                        Edge nextEdge = k == (baseEdges.size() - 1) ? baseEdges.get(0) : baseEdges.get(k + 1);

                        cutout.attach(cutouts.size(), edge, nextEdge, newEdges,newDxFEdges, DimLine, null,true);
                        cutoutEdges.put(cutout.getCutoutId(), newDxFEdges);
                        break;
                    }
                }
            }
            else if (cutout.getCutoutType() == Cutout.Type.Corner) {
                List<Edge> newEdges = new ArrayList<>();
                List<Edge> newDxFEdges = new ArrayList<>();
                CornerCutout cornerCutout = (CornerCutout) cutout;
                for (int k = 0; k < baseEdges.size(); k++) {
                    Edge edge = baseEdges.get(k);
                    if (edge.getEdgeId().equalsIgnoreCase(cornerCutout.getAttachment().getEdgeId())) {
                        Edge nextEdge = k == (baseEdges.size() - 1) ? baseEdges.get(0) : baseEdges.get(k + 1);

                        cutout.attach(cutouts.size(), edge, nextEdge, newEdges,newDxFEdges, null,null,true);
                        cutoutEdges.put(cutout.getCutoutId(), newDxFEdges);
                        break;
                    }
                }
            }
        });

        return cutoutEdges;
    }

    public List<Edge> generate(boolean dxf) {
        List<Edge> newEdges = new ArrayList<>();
        List<Edge> newEdges2 = new ArrayList<>();
        List<Line> newDimLine = new ArrayList<>();
        AbstractCutout.CutoutAttachInfo cutoutAttachInfo = null;

        for (int k = 0; k < baseEdges.size(); k++) {
            Edge edge = baseEdges.get(k);
            Map<Double, AbstractCutout> attachedCutouts = getAttachedCutouts(edge);

            if (cutoutAttachInfo != null && !cutoutAttachInfo.isOnNextEdge) {
                cutoutAttachInfo = null;
            }

            if (attachedCutouts.isEmpty()) {
                if (cutoutAttachInfo == null) {
                    newEdges.add(edge);
                } else {
                    cutoutAttachInfo = null;
                }
                continue;
            }

            cutoutAttachInfo = buildEdge(k, edge, newEdges,newDimLine, cutoutAttachInfo,dxf);
            if (k == baseEdges.size() - 1 && cutoutAttachInfo != null && cutoutAttachInfo.isOnNextEdge) {
                Edge firstEdge = newEdges.get(0);
                // Update the first edge
                if (firstEdge.getEdgeType() != Edge.Type.Straight) {
                    throw new RuntimeException("Cutouts on unsupported edges");
                }
                StraightEdge straightEdge = (StraightEdge) firstEdge;
                straightEdge.setStartPoint(cutoutAttachInfo.lastPoint);
                // Remove the last edge
                newEdges.remove(newEdges.size() - 1);
            }
        }
        return newEdges;
    }

    private AbstractCutout.CutoutAttachInfo buildEdge(int k, Edge edge, List<Edge> newEdges, List<Line> newDim, AbstractCutout.CutoutAttachInfo cutoutAttachInfo,boolean dxf) {
        Map<Double, AbstractCutout> attachedCutouts = getAttachedCutouts(edge);

        List<AbstractCutout> sortedCutouts = new ArrayList<>();
        while (!attachedCutouts.isEmpty()) {
            AbstractCutout cutout = getNearestCutout(attachedCutouts);
            sortedCutouts.add(cutout);
        }

        Edge nextEdge = k == (baseEdges.size() - 1) ? baseEdges.get(0) : baseEdges.get(k + 1);

        for (int i = 0; i < sortedCutouts.size(); i++) {
            AbstractCutout cutout = sortedCutouts.get(i);
            if (cutout.getCutoutType() != Cutout.Type.Interior) {
                List<Edge> newDxFEdges = new ArrayList<>();
                cutoutAttachInfo = cutout.attach(i, edge, nextEdge, newEdges, newDxFEdges,newDim, cutoutAttachInfo, dxf);
            }
        }
        return cutoutAttachInfo;
    }

    public AbstractCutout getNearestCutout(Map<Double, AbstractCutout> cutouts) {
        double min = Double.MAX_VALUE;
        AbstractCutout nearestCutout = null;
        for (Map.Entry<Double, AbstractCutout> entry : cutouts.entrySet()) {
            if (entry.getValue().getCutoutType() != Cutout.Type.Interior) {
                if (entry.getKey() < min) {
                    nearestCutout = entry.getValue();
                    min = entry.getKey();
                }
            }
        }
        cutouts.values().remove(nearestCutout);
        return nearestCutout;
    }

    private Map<Double, AbstractCutout> getAttachedCutouts(Edge edge) {
        Map<Double, AbstractCutout> attachedCutouts = new HashMap<>();
        for (AbstractCutout cutout : cutouts) {
            if (Cutouts.isEdgeCutout(cutout)) {
                EdgeAttachment attachment = ((EdgeCutout) cutout).getAttachment();
                if (attachment.getEdgeId().equalsIgnoreCase(edge.getEdgeId())) {
                    double offset = attachment.isStartOffset() ? attachment.getOffset() :
                            ShapeHelper.getEdgeLength(edge) - attachment.getOffset();
                    attachedCutouts.put(offset, cutout);
                }
            } else if (Cutouts.isCornerCutout(cutout)) {
                if (((CornerCutout) cutout).getAttachment().getEdgeId().equalsIgnoreCase(edge.getEdgeId())) {
                    attachedCutouts.put((double) Integer.MAX_VALUE, cutout);
                }
            } else if (Cutouts.isInteriorCutout(cutout)) {
                //if (((InteriorCutout) cutout).getAttachment().getEdgeId().equalsIgnoreCase(edge.getEdgeId())) {
                //    attachedCutouts.put((double) Integer.MAX_VALUE, cutout);
                //}
                // Ignore Interior cutout
            }
        }
        return attachedCutouts;
    }
}
