package com.core.shape;

public class Param {

    private String name;
    private double value;

    public Param() {
    }

    public Param(String name, double value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getValue() {
        return value;
    }

    public void setValue(double value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "{" + name + "=" + value + "}";
    }
}
