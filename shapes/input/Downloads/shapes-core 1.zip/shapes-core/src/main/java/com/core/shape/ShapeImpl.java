package com.core.shape;

import com.core.cutout.*;
import com.core.cutout.attachment.CornerAttachment;
import com.core.cutout.attachment.EdgeAttachment;
import com.core.cutout.attachment.InteriorAttachment;
import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.math.Point2D;
import com.core.shape.transformer.ShapeTransformer;
import com.core.utility.BoundingBox;
import com.core.utility.CutoutEdgeGenerator;
import com.core.utility.EdgeDimCutTuple;
import org.javatuples.Pair;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.core.math.Line;

public class ShapeImpl implements Shape {

    private int internalShapeId;
    private String shapeNo;
    private List<Param> params = new ArrayList<>();
    private final List<AbstractCutout> cutouts = new ArrayList<>();
    private ShapeTransformer transformer;
    private String thumbnailSVG;
    private String previewSVG;
    private final List<Pair<String, Object>> rotFlipActions = new ArrayList<>();
    private double topTrim = 0;
    private double rightTrim = 0;
    private double bottomTrim = 0;
    private double leftTrim = 0;

    public ShapeImpl() {
    }

    public double getCircumference() {
        return this.transformer.getCircumference();
    }

    public double getArea() {
        return this.transformer.getArea();
    }

    public int getInternalShapeId() {
        return internalShapeId;
    }

    public void setInternalShapeId(int internalShapeId) {
        this.internalShapeId = internalShapeId;
    }

    public String getShapeNo() {
        return shapeNo;
    }

    public void setShapeNo(String shapeNo) {
        this.shapeNo = shapeNo;
    }

    public List<Param> getParams() {
        return params;
    }

    public void setThumbnailSVG(String thumbnailSVG) {
        this.thumbnailSVG = thumbnailSVG;
    }

    @Override
    public String getThumbnailSVG() {
        return thumbnailSVG;
    }

    public void setPreviewSVG(String previewSVG) {
        this.previewSVG = previewSVG;
    }

    @Override
    public String getPreviewSVG() {
        return previewSVG;
    }

    public void setTransformer(ShapeTransformer transformer) {
        this.transformer = transformer;
    }

    @Override
    public void resize(List<Param> params) {
        this.params = params;
    }

    @Override
    public void rotate(double angle) {
        rotFlipActions.add(new Pair<>("rotate", angle));
    }

    @Override
    public void updateTrims(double top, double right, double bottom, double left) {
        this.topTrim = top;
        this.rightTrim = right;
        this.bottomTrim = bottom;
        this.leftTrim = left;
    }

    @Override
    public TrimInfo getTrims() {
        return new TrimInfo(
            this.topTrim,
            this.rightTrim,
            this.bottomTrim,
            this.leftTrim
        );
    }

    @Override
    public void flipVertical(boolean flip) {
        rotFlipActions.add(new Pair<>("vertical_flip", flip));
    }

    @Override
    public void flipHorizontal(boolean flip) {
        rotFlipActions.add(new Pair<>("horizontal_flip", flip));
    }

    @Override
    public Cutout addEdgeCutout(String cutoutNo, String edgeId, double offset, boolean startOffset) {
        int internalId = Cutouts.getInternalCutoutId(cutoutNo);
        AbstractCutout cutout = Cutouts.create(internalId, cutoutNo, EdgeAttachment.newBuilder()
            .setEdgeId(edgeId)
            .setOffset(offset)
            .setStartOffset(startOffset)
            .build());
        this.cutouts.add(cutout);
        return cutout;
    }

    @Override
    public Cutout addCornerCutout(String cutoutNo, String edgeId) {
        int internalId = Cutouts.getInternalCutoutId(cutoutNo);
        AbstractCutout cutout = Cutouts.create(internalId, cutoutNo, CornerAttachment.newBuilder()
            .setEdgeId(edgeId)
            .build());
        this.cutouts.add(cutout);
        return cutout;
    }

    @Override
    public Cutout addInteriorCutout(String cutoutNo, String edgeId, double offsetX, double offsetY) {
        int internalId = Cutouts.getInternalCutoutId(cutoutNo);
        AbstractCutout cutout = Cutouts.create(internalId, cutoutNo, InteriorAttachment.newBuilder()
            .setEdgeId(edgeId)
            .setOffsetX(offsetX)
            .setOffsetY(offsetY)
            .build());
        this.cutouts.add(cutout);
        return cutout;
    }

    @Override
    public Map<Long, List<Edge>> getInteriorCutoutEdges(Map<String, Double> services,Map<Long, List<Line>> CutoutDimLine) {

        List<Param> allParams = new ArrayList<>(params);
        allParams.addAll(buildTrimParams());

        List<Edge> skeletonEdges = this.transformer.resize(allParams, services);
        List<Edge> shapeEdges = skeletonEdges.stream().map(Edge::copy).toList();
       // Map<Long, List<Line>> CutoutDimLine = new HashMap<>();

        CutoutEdgeGenerator generator = new CutoutEdgeGenerator(cutouts, shapeEdges);
        Map<Long, List<Edge>> cutoutEdges = generator.generateInteriorCutoutEdges(CutoutDimLine );
        Map<Long, List<Edge>> newEdges = new HashMap<>();

        for (Map.Entry<Long, List<Line>> entry : CutoutDimLine.entrySet()) {
            List<Line> edges = entry.getValue();

            CutoutDimLine.put(entry.getKey(), edges);
        }

        for (Map.Entry<Long, List<Edge>> entry : cutoutEdges.entrySet()) {
            List<Edge> edges = entry.getValue();
            for (Pair<String, Object> action : rotFlipActions) {
                if (action.getValue0().equalsIgnoreCase("rotate")) {
                    double angle = (double) action.getValue1();
                    angle = angle > 360 ? angle - 360 : angle;
                    angle = angle < -360 ? angle + 360 : angle;
                    edges = this.transformer.rotate(angle, edges, false);
                } else if (action.getValue0().equalsIgnoreCase("vertical_flip")) {
                    boolean flip = (boolean) action.getValue1();
                    edges = this.transformer.flipVertical(edges);
                } else if (action.getValue0().equalsIgnoreCase("horizontal_flip")) {
                    boolean flip = (boolean) action.getValue1();
                    edges = this.transformer.flipHorizontal(edges);
                }
            }
            newEdges.put(entry.getKey(), edges);
        }
        return newEdges;
    }

    @Override
    public Map<Long, List<Edge>> getInteriorCutoutEdgesDxF(Map<String, Double> services) {

        List<Param> allParams = new ArrayList<>(params);
        allParams.addAll(buildTrimParams());

        List<Edge> skeletonEdges = this.transformer.resize(allParams, services);
        List<Edge> shapeEdges = skeletonEdges.stream().map(Edge::copy).toList();

        CutoutEdgeGenerator generator = new CutoutEdgeGenerator(cutouts, shapeEdges);
        Map<Long, List<Edge>> cutoutEdges = generator.generateInteriorCutoutDxFEdges();
        Map<Long, List<Edge>> newEdges = new HashMap<>();

        for (Map.Entry<Long, List<Edge>> entry : cutoutEdges.entrySet()) {
            List<Edge> edges = entry.getValue();
            for (Pair<String, Object> action : rotFlipActions) {
                if (action.getValue0().equalsIgnoreCase("rotate")) {
                    double angle = (double) action.getValue1();
                    angle = angle > 360 ? angle - 360 : angle;
                    angle = angle < -360 ? angle + 360 : angle;
                    edges = this.transformer.rotate(angle, edges, false);
                } else if (action.getValue0().equalsIgnoreCase("vertical_flip")) {
                    boolean flip = (boolean) action.getValue1();
                    edges = this.transformer.flipVertical(edges);
                } else if (action.getValue0().equalsIgnoreCase("horizontal_flip")) {
                    boolean flip = (boolean) action.getValue1();
                    edges = this.transformer.flipHorizontal(edges);
                }
            }
            newEdges.put(entry.getKey(), edges);
        }
        return newEdges;
    }

    @Override
    public List<Edge> getAllEdges(Map<String, Double> services,boolean dxf) {
        List<Param> allParams = new ArrayList<>(params);
        allParams.addAll(buildTrimParams());

        List<Edge> skeletonEdges = this.transformer.resize(allParams, services);
        List<Edge> shapeEdges = skeletonEdges.stream().map(Edge::copy).toList();

        CutoutEdgeGenerator generator = new CutoutEdgeGenerator(cutouts, shapeEdges);
        List<Edge> newEdges = generator.generate(dxf);
        System.out.println("size= " +newEdges.size()+" Test test  TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT");

        for (Pair<String, Object> action : rotFlipActions) {
            if (action.getValue0().equalsIgnoreCase("rotate")) {
                double angle = (double) action.getValue1();
                angle = angle > 360 ? angle - 360 : angle;
                angle = angle < -360 ? angle + 360 : angle;
                newEdges = this.transformer.rotate(angle, newEdges, false);
            } else if (action.getValue0().equalsIgnoreCase("vertical_flip")) {
                boolean flip = (boolean) action.getValue1();
                newEdges = this.transformer.flipVertical(newEdges);
            } else if (action.getValue0().equalsIgnoreCase("horizontal_flip")) {
                boolean flip = (boolean) action.getValue1();
                newEdges = this.transformer.flipHorizontal(newEdges);
            }
        }
        return newEdges;
    }

    @Override
    public List<Line> getCutOutDims(Map<String, Double> services) {
        List<Param> allParams = new ArrayList<>(params);

        allParams.addAll(buildTrimParams());

        List<Edge> skeletonEdges = this.transformer.resize(allParams, services);
        List<Edge> shapeEdges = skeletonEdges.stream().map(Edge::copy).toList();

        CutoutEdgeGenerator generator = new CutoutEdgeGenerator(cutouts, shapeEdges);
        List<Line> newDim =  new ArrayList<>();
        System.out.println("newDim.size= "+newDim.size()+ "  checked 2 44444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444444");
        return newDim;
    }

    @Override
    public EdgeDimCutTuple getShapeEdges(Map<String, Double> services,Map<String, Double> coatingRemovals ) {
        List<Param> allParams = new ArrayList<>(params);
        allParams.addAll(buildTrimParams());

        EdgeDimCutTuple edgeDimPair = this.transformer.resize2(allParams, services, coatingRemovals);
        List<Edge> skeletonEdges = edgeDimPair.edges();
        List<Edge> dimLines = edgeDimPair.dimLines();
        List<Edge> cutEdges = edgeDimPair.cutEdges();
        List<Edge> cotEdges = edgeDimPair.coatingEdges();

        skeletonEdges.forEach(edge -> System.out.println(
            "[" + edge.getStartPoint().x + ", " + edge.getStartPoint().y + "] => " +
                "[" + edge.getEndPoint().x + ", " + edge.getEndPoint().y + "]"
            ));

        //List<Edge> skeletonEdges = this.transformer.resize(allParams);
        List<Edge> newEdges = skeletonEdges.stream().map(Edge::copy).toList();
        List<Edge> newDimLines = dimLines.stream().map(Edge::copy).toList();
        List<Edge> newCutEdges = cutEdges.stream().map(Edge::copy).toList();
        List<Edge> newCotEdges = cotEdges.stream().map(Edge::copy).toList();
        boolean isVerticallyFlipped = false;
        boolean isHorizontallyFlipped = false;
        for (Pair<String, Object> action : rotFlipActions) {
            if (action.getValue0().equalsIgnoreCase("rotate")) {
                double angle = (double) action.getValue1();
                angle = angle > 360 ? angle - 360 : angle;
                angle = angle < -360 ? angle + 360 : angle;
                newEdges = this.transformer.rotate(angle, newEdges, false);
                newDimLines = this.transformer.rotate(angle, newDimLines, false);
                newCutEdges = this.transformer.rotate(angle, newCutEdges, false);
                newCotEdges = this.transformer.rotate(angle, newCotEdges, false);
            } else if (action.getValue0().equalsIgnoreCase("vertical_flip")) {
                boolean flip = (boolean) action.getValue1();
                newEdges = this.transformer.flipVertical(newEdges);
                newDimLines = this.transformer.flipVertical(newDimLines);
                newCutEdges = this.transformer.flipVertical(newCutEdges);
                newCotEdges = this.transformer.flipVertical(newCotEdges);
                isVerticallyFlipped = !isVerticallyFlipped;
            } else if (action.getValue0().equalsIgnoreCase("horizontal_flip")) {
                boolean flip = (boolean) action.getValue1();
                newEdges = this.transformer.flipHorizontal(newEdges);
                newDimLines = this.transformer.flipHorizontal(newDimLines);
                newCutEdges = this.transformer.flipHorizontal(newCutEdges);
                newCotEdges = this.transformer.flipHorizontal(newCotEdges);
                isHorizontallyFlipped = !isHorizontallyFlipped;
            }
        }

        if (isVerticallyFlipped != isHorizontallyFlipped) {
            System.out.println("Flip states differ - swapping dimension line points");
            List<Edge> swappedDimLines = new ArrayList<>();

            for (Edge dimLine : newDimLines) {
                // Create new edge with swapped points

                Point2D newStart = dimLine.getEndPoint().copy();
                Point2D newEnd = dimLine.getStartPoint().copy();

                StraightEdge modified = new StraightEdge(newStart, newEnd);
                modified.setEdgeId(dimLine.getEdgeId());
                modified.setOriginalEdgeId(dimLine.getOriginalEdgeId());
                swappedDimLines.add(modified);

            }

            newDimLines = swappedDimLines;
        }
        System.out.println("Current Flip States:");
        System.out.println("  Vertical Flip: " + (isVerticallyFlipped ? "ACTIVE" : "INACTIVE"));
        System.out.println("  Horizontal Flip: " + (isHorizontallyFlipped ? "ACTIVE" : "INACTIVE"));

        return new EdgeDimCutTuple(newEdges, newDimLines, newCutEdges, newCotEdges) ;
    }

    @Override
    public List<TrimLine> getTrimLines(Map<String, Double> services, boolean isShape31) {
        List<Param> allParams = new ArrayList<>(params);
        allParams.addAll(buildTrimParams());

        List<Edge> skeletonEdges = this.transformer.resize(allParams, services);
        //BoundingBox bb = ShapeHelper.calculateCutSize(skeletonEdges, services);
        List<Edge> adjustedEdges = ShapeHelper.serviceAdjustedEdges(skeletonEdges, services);

        Map<String, Double> services2 = new HashMap<>();
        services2.put("E1", 0.0);
        services2.put("E2", 0.0);
        services2.put("E3", 0.0);
        services2.put("E4", 0.0);
        services2.put("E5", 0.0);
        services2.put("E6", 0.0);
        services2.put("E7", 0.0);
        services2.put("E8", 0.0);

        EdgeDimCutTuple edgeDimpair = this.transformer.resize2(allParams,services,services2);
        List<Edge> adjustedEdges2 = edgeDimpair.cutEdges();
        BoundingBox bb = BoundingBox.fromEdges(adjustedEdges2 ,isShape31);
        BoundingBox b0b = BoundingBox.fromEdges(skeletonEdges,isShape31);

        System.out.println("updated = " + bb);
        System.out.println("old = " + b0b);

        List<Edge> trimEdges = buildTrimEdges(bb);

        for (Pair<String, Object> action : rotFlipActions) {
            if (action.getValue0().equalsIgnoreCase("rotate")) {
                double angle = (double) action.getValue1();
                angle = angle > 360 ? angle - 360 : angle;
                angle = angle < -360 ? angle + 360 : angle;
                trimEdges = this.transformer.rotate(angle, trimEdges, false);
            } else if (action.getValue0().equalsIgnoreCase("vertical_flip")) {
                boolean flip = (boolean) action.getValue1();
                trimEdges = this.transformer.flipVertical(trimEdges);
            } else if (action.getValue0().equalsIgnoreCase("horizontal_flip")) {
                boolean flip = (boolean) action.getValue1();
                trimEdges = this.transformer.flipHorizontal(trimEdges);
            }
        }

        return trimEdges.stream()
            .map(edge -> {
                TrimLine line = new TrimLine(edge.getEdgeId());
                line.setStartPoint(edge.getStartPoint());
                line.setEndPoint(edge.getEndPoint());
                return line;
            }).toList();
    }

    private List<Edge> buildTrimEdges(BoundingBox bb) {
        Point2D origin = new Point2D(0, 0);
        double W = bb.getMaxPoint().x;
        double H = bb.getMaxPoint().y;

        StraightEdge bottom = new StraightEdge(origin, new Point2D(W + rightTrim, 0), "bottom");
        StraightEdge right = new StraightEdge(bottom.getEndPoint(), new Point2D(bottom.getEndPoint().x, H + topTrim), "right");
        StraightEdge top = new StraightEdge(right.getEndPoint(), new Point2D(0, right.getEndPoint().y), "top");
        StraightEdge left = new StraightEdge(top.getEndPoint(), origin, "left");

        return List.of(bottom, right, top, left);
    }

    private List<Param> buildTrimParams() {
        return List.of(
            new Param(ShapeConstants.TRIM_TOP, topTrim),
            new Param(ShapeConstants.TRIM_RIGHT, rightTrim),
            new Param(ShapeConstants.TRIM_BOTTOM, bottomTrim),
            new Param(ShapeConstants.TRIM_LEFT, leftTrim)
        );
    }

}
