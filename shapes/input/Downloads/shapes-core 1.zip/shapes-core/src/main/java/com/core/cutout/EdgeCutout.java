package com.core.cutout;


import com.core.cutout.attachment.EdgeAttachment;
import com.core.edge.Edge;
import com.core.math.Point2D;
import com.core.math.Vector2D;

public abstract class EdgeCutout extends AbstractCutout {

    protected EdgeAttachment attachment;

    public EdgeCutout(int internalId, String cutoutNo, EdgeAttachment attachment) {
        super(internalId, cutoutNo);
        this.attachment = attachment;
    }

    public EdgeAttachment getAttachment() {
        return attachment;
    }

    @Override
    public Type getCutoutType() {
        return Type.Edge;
    }

    protected Point2D calculateConnerPoint(Edge currEdge, boolean isStartOffset) {
        if(isStartOffset)
            return currEdge.getStartPoint();
        else
            return currEdge.getEndPoint();
    }

    protected Point2D calculateCutoutCenter(Edge currEdge, boolean isStartOffset) {
        Vector2D xVec = Vector2D.create(currEdge.getEndPoint(), currEdge.getStartPoint());
        xVec.normalize();
        xVec.multiply(attachment.getOffset());
        if(isStartOffset){
            Vector2D corner = new Vector2D(currEdge.getStartPoint());
            corner.subtract(xVec);
            return corner.toPoint();
     }else{
            Vector2D corner = new Vector2D(currEdge.getEndPoint());
            corner.add(xVec);
            return corner.toPoint();
        }
    }
}
