package com.core.cutout.impl;

import com.core.cutout.CornerCutout;
import com.core.cutout.CutoutViewCreator;
import com.core.cutout.EdgeCutout;
import com.core.cutout.attachment.Attachment;
import com.core.cutout.attachment.CornerAttachment;
import com.core.cutout.attachment.EdgeAttachment;
import com.core.edge.ArcEdge;
import com.core.edge.Edge;
import com.core.math.Line;
import com.core.edge.StraightEdge;
import com.core.math.Point2D;
import com.core.math.Vector2D;
import com.core.shape.ParamList;
import com.core.svg.SVGBuilder;
import com.core.svg.SVGBuilder2;
import com.core.utility.GeometryHelper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Cutout_111 extends CornerCutout {

        public Cutout_111(String cutoutNo, Attachment attachment) {
            super(111, cutoutNo, (CornerAttachment) attachment);
        }

        //@Override
        public Point2D attach(int idx, List<Edge> edges, List<Edge> baseEdges, Point2D previousPoint) {
            return null;
        }

    @Override
public CutoutAttachInfo attach(int idx, Edge currEdge, Edge nextEdge, List<Edge> edges,List<Edge> DxFedges, List<Line> DimLines, CutoutAttachInfo previousInfo, boolean dxf) {
        ParamList p = new ParamList(params);
        double W = p.getParam("W").getValue();
        double H = p.getParam("H").getValue();
        double R = p.getParam("R1").getValue();
        double R2 = p.getParam("R2").getValue();

        Vector2D currVec = Vector2D.create(currEdge.getEndPoint(), currEdge.getStartPoint());
        currVec.normalize();
        currVec.multiply(W);

        Vector2D vw = new Vector2D(currEdge.getEndPoint());
        vw.add(currVec);

        Vector2D nextVec = Vector2D.create(nextEdge.getStartPoint(), nextEdge.getEndPoint());
        nextVec.normalize();
        nextVec.multiply(H);

        Vector2D vh = new Vector2D(nextEdge.getStartPoint());
        vh.add(nextVec);

        Vector2D vt = vw.added(nextVec);

        Vector2D r1 = Vector2D.create(vt, vw);
        r1.normalize();
        r1.multiply(R);

        Vector2D r11 = Vector2D.create(vt, vw);
        r11.normalize();
        r11.multiply(R2);

        Vector2D r2 = Vector2D.create(vt, vh);
        r2.normalize();
        r2.multiply(R);

        Vector2D r22 = Vector2D.create(vt, vh);
        r22.normalize();
        r22.multiply(R2);

        Vector2D r3 = Vector2D.create(vw, vt);
        r3.normalize();
        r3.multiply(R);

        Vector2D r4 = Vector2D.create(vh,vt);
        r4.normalize();
        r4.multiply(R);

        Vector2D vb = vt.copy();
        vb.add(r2);

        Vector2D vc = vw.copy();
        vc.add(r2);
        vc.add(r3);

        Vector2D vw1 = vw.copy();
        vw1.add(r2);

        Vector2D vh1 = vh.copy();
        vh1.add(r1);

        Vector2D vo = vt.added(r1);
        vo.add(r2);

        Vector2D vd = vo.copy();
        vd.add(r11);

        Vector2D ve = vo.copy();
        ve.add(r22);

        Vector2D vf = vh1.copy();
        vf.add(r4);

        StraightEdge e1 = new StraightEdge(currEdge.getStartPoint(), new Point2D(vw));
        e1.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-1");
        e1.setOriginalEdgeId(currEdge.getOriginalEdgeId());
        edges.add(e1);
        DxFedges.add(e1);

        ArcEdge e2 = new ArcEdge(R, false, false, e1.getEndPoint(), new Point2D(vc));
        e2.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-2");
        if(dxf)
            edges.add(e2);
        DxFedges.add(e2);

        StraightEdge e3 = new StraightEdge(e2.getEndPoint(), new Point2D(vd));
        e3.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-3");
        edges.add(e3);
        DxFedges.add(e3);

        ArcEdge e4 = new ArcEdge(R2, false, true, e3.getEndPoint(), new Point2D(ve));
        e4.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-4");
        if(dxf)
            edges.add(e4);

        ArcEdge eDxf4 = new ArcEdge(R2, false, true, new Point2D(ve), e3.getEndPoint());
        eDxf4.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-4");
        DxFedges.add(eDxf4);

        StraightEdge e5 = new StraightEdge(e4.getEndPoint(), new Point2D(vf));
        e5.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-5");
        edges.add(e5);
        DxFedges.add(e5);

        ArcEdge e6 = new ArcEdge(R, false, false, e5.getEndPoint(), new Point2D(vh));
        e6.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-6");
        if(dxf)
            edges.add(e6);
        DxFedges.add(e6);

        StraightEdge e7 = new StraightEdge(e6.getEndPoint(), nextEdge.getEndPoint());
        e7.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-7");
        e7.setOriginalEdgeId(currEdge.getOriginalEdgeId());
        edges.add(e7);
        DxFedges.add(e7);

        CutoutAttachInfo info = new CutoutAttachInfo();
        info.isOnNextEdge = true;
        info.lastPoint = e7.getStartPoint();

        calculateWaste();

        return info;
    }




    public static CutoutViewCreator createCutoutViewCreator() {
        return new CutoutViewCreator() {

            @Override
            public SVGBuilder2 getThumbnailBuilder() {
                return new SVGBuilder2(180, 180)
                        .pathBuilder()
                        .strokeOpacity("0.25")
                        .startPath(0, 30)
                        .lineTo(0, 50)
                        .endPath(false)
                        .pathBuilder()
                        //.startPath(0, 30)
                        .startPath(0, 50)
                        .arcTo(20, 20, 20, 70, false, false)
                        .lineTo(90, 70)
                        .arcTo(20, 20, 110, 90, false, true)
                        .lineTo(110, 130)
                        .arcTo(20, 20, 130, 150, false, false)
                        //.lineTo(160, 130)
                        .endPath(false)
                        .pathBuilder()
                        .strokeOpacity("0.25")
                        .startPath(130, 150)
                        .lineTo(150, 150)
                        .endPath(false);
            }

            @Override
            public SVGBuilder2 getPreviewBuilder() {
                return new SVGBuilder2(200, 200)
                        .pathBuilder()
                        .strokeOpacity("0.25")
                        .startPath(10, 30)
                        .lineTo(10, 50)
                        .endPath(false)
                        .pathBuilder()
                        //.startPath(0, 30)
                        .startPath(10, 50)
                        .arcTo(20, 20, 30, 70, false, false)
                        .lineTo(100, 70)
                        .arcTo(20, 20, 120, 90, false, true)
                        .lineTo(120, 130)
                        .arcTo(20, 20, 140, 150, false, false)
                        //.lineTo(160, 130)
                        .endPath(false)
                        .pathBuilder()
                        .strokeOpacity("0.25")
                        .startPath(140, 150)
                        .lineTo(160, 150)
                        .endPath(false)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(0, 150)
                        .lineToWithText(0, 50, "H")
                        .endPath(false)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(10, 0)
                        .lineToWithText(140, 0, "W")
                        .endPath(false)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(100, 70)
                        .lineToWithText(100, 90, "R2")
                        .endPath(false)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(30, 70)
                        .lineToWithText(30, 50, "R1")
                        .endPath(false);
            }

            @Override
            public Type getCutoutType() {
                return Type.Corner;
            }

            @Override
            public List<String> getParamNames() {
                return Arrays.asList("W", "H", "R1", "R2");
            }

            @Override
            public List<String> getCutoutMappingParamNames() {
                return Arrays.asList("W", "H", "R1", "R2");
            }
        };
    }

    private void calculateWaste() {
        ParamList p = new ParamList(params);
        double W = p.getParam("W").getValue();
        double H = p.getParam("H").getValue();
        double R1 = p.getParam("R1").getValue();
        double R2 = p.getParam("R2").getValue();
        waste = (H-R1)*(W-R1) + R1*R1*2 - ((Math.PI * R1 * R1) / 2.0) + R2*R2-((Math.PI * R2 * R2) / 4.0);
    }
}
