package com.core.shape;

public class ShapeConstants {

  public static final String W = "W";
  public static final String H = "H";
  public static final String W1 = "W1";
  public static final String W2 = "W2";
  public static final String H1 = "H1";
  public static final String H2 = "H2";
  public static final String R = "R";
  public static final String L = "L";
  public static final String L1 = "L1";
  public static final String L2 = "L2";
  public static final String G = "G";
  public static final String A1 = "A1";
  public static final String A = "A";

  public static final String TRIM_TOP = "TOP";
  public static final String TRIM_RIGHT = "RIGHT";
  public static final String TRIM_BOTTOM = "BOTTOM";
  public static final String TRIM_LEFT = "LEFT";

  private ShapeConstants() {}
}
