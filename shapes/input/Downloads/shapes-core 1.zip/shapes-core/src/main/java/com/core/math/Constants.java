package com.core.math;

public class Constants {

    public static double EPSILON = 0.001;

}
