package com.core.edge;

import com.core.math.Point2D;
import com.core.math.Vector2D;
import com.core.utility.MathHelper;

import java.util.ArrayList;
import java.util.List;

public class StraightEdge implements Edge {
    private Point2D startPoint;
    private Point2D endPoint;
    private String edgeId;
    private String originalEdgeId;
    private boolean largeArc;
    private boolean sweep;
    private final List<Edge> children = new ArrayList<>();

    public StraightEdge() {
        this.startPoint = null;
        this.endPoint = null;
        this.edgeId = "";
        this.originalEdgeId = "";
    }

    public StraightEdge(Point2D startPoint, Point2D endPoint) {
        this.startPoint = startPoint;
        this.endPoint = endPoint;
        this.edgeId = "";
        this.originalEdgeId = "";
    }

    public StraightEdge(Point2D startPoint, Point2D endPoint, String edgeId) {
        this.startPoint = startPoint;
        this.endPoint = endPoint;
        this.edgeId = edgeId;
        this.originalEdgeId = edgeId;
    }

    @Override
    public Point2D getStartPoint() {
        return startPoint;
    }

    public void setStartPoint(Point2D startPoint) {
        this.startPoint = startPoint;
    }

    @Override
    public Point2D getEndPoint() {
        return endPoint;
    }

    public void setEndPoint(Point2D endPoint) {
        this.endPoint = endPoint;
    }

    @Override
    public boolean getIsSweep() {
        return sweep;
    }

    public void setIsSweep(boolean l) {
        this.sweep = l;
    }

    @Override
    public Edge copy() {
        StraightEdge edge = new StraightEdge();
        edge.setEdgeId(this.edgeId);
        edge.setOriginalEdgeId(this.originalEdgeId);
        edge.setStartPoint(this.startPoint.copy());
        edge.setEndPoint(this.endPoint.copy());
        for (Edge child : children) {
            edge.getChildren().add(child.copy());
        }
        return edge;
    }

    @Override
    public void reverse() {
        Point2D temp = this.startPoint;
        this.startPoint = this.endPoint;
        this.endPoint = temp;
    }

    @Override
    public void debug() {
        System.out.print(this.edgeId + " [(" + MathHelper.round2(this.startPoint.x) + ", " +
          MathHelper.round2(this.startPoint.y) + ") => (" + MathHelper.round2(this.endPoint.x) + ", " +
          MathHelper.round2(this.endPoint.y) + ")]");
    }

    @Override
    public void rotate(double angle) {
        Point2D sp = Point2D.rotatePoint(Math.toRadians(angle), startPoint);
        Point2D ep = Point2D.rotatePoint(Math.toRadians(angle), endPoint);
        this.setStartPoint(sp);
        this.setEndPoint(ep);

        for (Edge child : children) {
            child.rotate(angle);
        }
    }

    @Override
    public Type getEdgeType() {
        return Type.Straight;
    }

    @Override
    public String getEdgeId() {
        return edgeId;
    }

    @Override
    public String getOriginalEdgeId() {
        return originalEdgeId;
    }

    public void setEdgeId(String edgeId) {
        this.edgeId = edgeId;
    }

    public void setOriginalEdgeId(String originalEdgeId) {
        this.originalEdgeId = originalEdgeId;
    }

    public List<Edge> getChildren() {
        return children;
    }

    @Override
    public double getLength() {
        return Vector2D.distance(new Vector2D(startPoint), new Vector2D(endPoint));
    }
    @Override
    public double getRadius() {
        return 0.0;
    }

    @Override
    public boolean getIsLargeArc() {
        return largeArc;
    }

    public void setIsLargeArc(boolean l) {
        this.largeArc = l;
    }

}
