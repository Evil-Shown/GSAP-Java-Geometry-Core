package com.core.shape.transformer;

import com.core.edge.Edge;
import com.core.edge.ArcEdge;
import com.core.shape.Param;
import com.core.utility.CoordinateSystemMapper;
import com.core.utility.EdgeDimCutTuple;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public abstract class ShapeTransformer {

    protected final CoordinateSystemMapper coordinateSystemMapper = new CoordinateSystemMapper();
    protected double area = 0.0;
    protected double circumference = 0.0;

    public abstract List<Edge> resize(List<Param> params, Map<String, Double> services);
    public abstract EdgeDimCutTuple resize2(List<Param> params, Map<String, Double> services, Map<String, Double> coatingRemovals);

    public double getArea() {
        return this.area;
    }

    public double getCircumference() {
        return this.circumference;
    }

    public List<Edge> rotate(double angle, List<Edge> edges, boolean flipRotation) {
        double rotAngle = flipRotation ? -angle : angle;
        return edges.stream()
                .map(Edge::copy)
                .peek(edge -> edge.rotate(rotAngle))
                .toList();
    }

    public List<Edge> flipHorizontal(List<Edge> edges) {
        return edges.stream()
                .map(Edge::copy)
                .peek(edge -> {
                    // Flip X coordinates
                    edge.getStartPoint().x *= -1.0;
                    edge.getEndPoint().x *= -1.0;

                    // For arc edges, also flip the sweep direction
                    if (edge instanceof ArcEdge) {
                        ArcEdge arcEdge = (ArcEdge) edge;
                        arcEdge.setSweep(!arcEdge.isSweep());
                    }
                })
                .toList();
    }

    public List<Edge> flipVertical(List<Edge> edges) {
        return edges.stream()
                .map(Edge::copy)
                .peek(edge -> {
                    // Flip Y coordinates
                    edge.getStartPoint().y *= -1.0;
                    edge.getEndPoint().y *= -1.0;

                    // For arc edges, also flip the sweep direction
                    if (edge instanceof ArcEdge) {
                        ArcEdge arcEdge = (ArcEdge) edge;
                        arcEdge.setSweep(!arcEdge.isSweep());
                    }
                })
                .toList();
    }

    protected void calculateCircumference(List<Edge> edges) {
        this.circumference = 0.0;
        for (Edge edge : edges) {
            this.circumference += edge.getLength();
        }
    }
}