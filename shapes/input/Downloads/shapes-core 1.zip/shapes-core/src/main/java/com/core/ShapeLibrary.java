package com.core;

import com.core.cutout.Cutout;
import com.core.cutout.CutoutView;
import com.core.shape.CustomShape;
import com.core.shape.Shape;
import com.core.shape.ShapeView;

import java.util.List;

public abstract class ShapeLibrary {

    public static ShapeLibrary initialize(String filePath) {
        return new ShapeLibraryImpl(filePath);
    }

    public abstract Shape createShape(int internalShapeId, String shapeNoText);

    public abstract ShapeView createShapeView(int internalShapeId, String shapeNoText);

    public abstract CutoutView createCutoutView(int internalCutoutId, String cutoutNoText);

    public abstract List<Integer> getAllInternalShapeIds();

    public abstract List<Integer> getAllInternalCutoutIds();

    public abstract List<String> getCutoutParams(int internalCutoutId);

    public abstract List<String> getCutoutMappingParamNames(int internalCutoutId);

    public abstract boolean addCustomShape(CustomShape customShape);

    public abstract Shape createCustomShape(int shapeId);
}
