package com.core.math;

import static com.core.math.Constants.EPSILON;

public class Point2D {
    public double x;
    public double y;

    public Point2D(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public Point2D(Vector2D vec) {
        this.x = vec.x;
        this.y = vec.y;
    }

    public double distanceTo(Point2D point) {
        double dx = point.x - this.x;
        double dy = point.y - this.y;
        return Math.sqrt(dy * dy + dx * dx);
    }

    public static Point2D rotatePoint(double radians, Point2D point) {
        return new Point2D(
            point.x * Math.cos(radians) - point.y * Math.sin(radians),
            point.x * Math.sin(radians) + point.y * Math.cos(radians)
        );
    }

    public static boolean isSame(Point2D p1, Point2D p2) {
        double dx = p1.x - p2.x;
        double dy = p1.y - p2.y;

        return Math.abs(dx) < EPSILON && Math.abs(dy) < EPSILON;
    }

    public Point2D copy() {
        return new Point2D(this.x, this.y);
    }

    public boolean isSame(Point2D p) {
        return isSame(this, p);
    }

    public static double clamped(double value) {
        int invValue = (int) value;
        double fr = value - invValue;

        if (fr > 0.0 && fr < EPSILON) {
            return  (fr + 0.5 > 1.0) ? Math.ceil(value) : Math.floor(value);
        }
        return value;
    }

    @Override
    public String toString() {
        return "Point2D[" + x + ", " + y + "]";
    }

}
