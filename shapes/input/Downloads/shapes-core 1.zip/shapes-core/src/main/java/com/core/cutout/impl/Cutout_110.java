package com.core.cutout.impl;

import com.core.cutout.CutoutViewCreator;
import com.core.cutout.EdgeCutout;
import com.core.cutout.InteriorCutout;
import com.core.cutout.attachment.Attachment;
import com.core.cutout.attachment.EdgeAttachment;
import com.core.cutout.attachment.InteriorAttachment;
import com.core.edge.ArcEdge;
import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.math.Point2D;
import com.core.shape.ParamList;
import com.core.svg.SVGBuilder;
import com.core.svg.SVGBuilder2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.core.math.Line;

public class Cutout_110 extends InteriorCutout {

    public Cutout_110(String cutoutNo, Attachment attachment) {
        super(110, cutoutNo, (InteriorAttachment) attachment);
    }

    //@Override
    public Point2D attach(int idx, List<Edge> edges, List<Edge> baseEdges, Point2D previousPoint) {
        return null;
    }

    @Override
public CutoutAttachInfo attach(int idx, Edge currEdge, Edge nextEdge, List<Edge> edges,List<Edge> DxFedges, List<Line> DimLines, CutoutAttachInfo previousInfo, boolean dxf) {
        ParamList p = new ParamList(params);
        double H = p.getParam("H").getValue();
        double R = p.getParam("R").getValue();


        Point2D cutoutCenter = calculateCutoutCenter(currEdge, nextEdge, 0,0,true);
        Point2D dimCenter = calculateCutoutCenter(currEdge, nextEdge, 0,0,true);

        Point2D a = new Point2D(cutoutCenter.x , cutoutCenter.y+H- R);
        Point2D b = new Point2D(cutoutCenter.x, cutoutCenter.y);
        Point2D c = new Point2D(cutoutCenter.x + 2*R, cutoutCenter.y);
        Point2D d = new Point2D(cutoutCenter.x + 2*R, cutoutCenter.y +H- R);

        StraightEdge e1 = new StraightEdge(a, b);
        StraightEdge e2 = new StraightEdge(b, c);
        StraightEdge e3 = new StraightEdge(c, d);
        ArcEdge e4 = new ArcEdge(R, false, true, a, d);

        edges.add(e1);
        edges.add(e2);
        edges.add(e3);
        edges.add(e4);

        Point2D[] points = offsets(currEdge, nextEdge);
        Point2D offsetXPoint = points[0];
        Point2D offsetYPoint = points[1];

        DimLines.add(new Line("X",offsetXPoint,  dimCenter ));
        DimLines.add(new Line("Y",offsetYPoint,  dimCenter ));

        return previousInfo;
    }

    public static CutoutViewCreator createCutoutViewCreator() {
        return new CutoutViewCreator() {

            @Override
            public SVGBuilder2 getThumbnailBuilder() {
                return new SVGBuilder2(180, 180)
                        .pathBuilder()
                        .startPath(30, 130)
                        .lineTo(130, 130)
                        .lineTo(130, 50)
                        .arcTo(50, 50, 30, 50, false, false)
                        .lineTo(30, 130)
                        .endPath(true);
            }

            @Override
            public SVGBuilder2 getPreviewBuilder() {
                return new SVGBuilder2(180, 180)
                        .pathBuilder()
                        .startPath(30, 130)
                        .lineTo(130, 130)
                        .lineTo(130, 50)
                        .arcTo(50, 50, 30, 50, false, false)
                        .lineTo(30, 130)
                        .endPath(true)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(130, 50)
                        .lineToWithText(80, 50, "R")
                        .endPath(false)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(0, 130)
                        .lineToWithText(0, 0, "H")
                        .endPath(false);
            }

            @Override
            public Type getCutoutType() {
                return Type.Interior;
            }

            @Override
            public List<String> getParamNames() {
                return Arrays.asList("H", "R", "A");
            }

            @Override
            public List<String> getCutoutMappingParamNames() {
                return Arrays.asList("H", "R");
            }
        };
    }
    private void calculateWaste() {
        ParamList p = new ParamList(params);
        double R = p.getParam("R").getValue();
        double H = p.getParam("H").getValue();
        waste = H * H + ((Math.PI * R * R) / 2.0);
    }
}
