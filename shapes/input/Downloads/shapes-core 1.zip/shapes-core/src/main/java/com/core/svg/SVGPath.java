package com.core.svg;

public class SVGPath {

    private String id;
    private String d;
    private String stroke;
    private String strokeWidth;
    private double translateX;
    private double translateY;
    private double cx;
    private double cy;
    private double sx;
    private double sy;
    private double ex;
    private double ey;
    private double length;

    public SVGPath() {
    }

    public SVGPath(String d, String stroke, String strokeWidth, double translateX, double translateY,
                   double cx, double cy, double sx, double sy, double ex, double ey, double length) {
        this.id = "";
        this.d = d;
        this.stroke = stroke;
        this.strokeWidth = strokeWidth;
        this.translateX = translateX;
        this.translateY = translateY;
        this.cx = cx;
        this.cy = cy;
        this.sx = sx;
        this.sy = sy;
        this.ex = ex;
        this.ey = ey;
        this.length = length;
    }

    public SVGPath(String id, String d, String stroke, String strokeWidth, double translateX, double translateY,
                   double cx, double cy, double sx, double sy, double ex, double ey, double length) {
        this.id = id;
        this.d = d;
        this.stroke = stroke;
        this.strokeWidth = strokeWidth;
        this.translateX = translateX;
        this.translateY = translateY;
        this.cx = cx;
        this.cy = cy;
        this.sx = sx;
        this.sy = sy;
        this.ex = ex;
        this.ey = ey;
        this.length = length;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getD() {
        return d;
    }

    public void setD(String d) {
        this.d = d;
    }

    public String getStroke() {
        return stroke;
    }

    public void setStroke(String stroke) {
        this.stroke = stroke;
    }

    public String getStrokeWidth() {
        return strokeWidth;
    }

    public void setStrokeWidth(String strokeWidth) {
        this.strokeWidth = strokeWidth;
    }

    public double getTranslateX() {
        return translateX;
    }

    public void setTranslateX(double translateX) {
        this.translateX = translateX;
    }

    public double getTranslateY() {
        return translateY;
    }

    public void setTranslateY(double translateY) {
        this.translateY = translateY;
    }

    public double getCx() {
        return cx;
    }

    public void setCx(double cx) {
        this.cx = cx;
    }

    public double getCy() {
        return cy;
    }

    public void setCy(double cy) {
        this.cy = cy;
    }

    public double getSx() {
        return sx;
    }

    public void setSx(double sx) {
        this.sx = sx;
    }

    public double getSy() {
        return sy;
    }

    public void setSy(double sy) {
        this.sy = sy;
    }

    public double getEx() {
        return ex;
    }

    public void setEx(double ex) {
        this.ex = ex;
    }

    public double getEy() {
        return ey;
    }

    public void setEy(double ey) {
        this.ey = ey;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }
}
