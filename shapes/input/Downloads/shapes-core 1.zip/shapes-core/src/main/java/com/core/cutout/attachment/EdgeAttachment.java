package com.core.cutout.attachment;

import com.core.cutout.Cutout;

public class EdgeAttachment implements Attachment {

    private String edgeId;
    private double offset;
    private boolean startOffset;

    public String getEdgeId() {
        return edgeId;
    }

    public void setEdgeId(String edgeId) {
        this.edgeId = edgeId;
    }

    public double getOffset() {
        return offset;
    }

    public void setOffset(double offset) {
        this.offset = offset;
    }

    public boolean isStartOffset() {
        return startOffset;
    }

    public void setStartOffset(boolean startOffset) {
        this.startOffset = startOffset;
    }

    @Override
    public Cutout.Type getAttachmentType() {
        return Cutout.Type.Edge;
    }

    public static class Builder {
        private EdgeAttachment attachment = new EdgeAttachment();

        private Builder() {}

        public Builder setEdgeId(String edgeId) {
            this.attachment.setEdgeId(edgeId);
            return this;
        }

        public Builder setOffset(double offset) {
            this.attachment.setOffset(offset);
            return this;
        }

        public Builder setStartOffset(boolean startOffset) {
            this.attachment.setStartOffset(startOffset);
            return this;
        }

        public EdgeAttachment build() {
            return attachment;
        }
    }

    public static Builder newBuilder() {
        return new Builder();
    }
}
