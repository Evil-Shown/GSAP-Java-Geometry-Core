package com.core.cutout;

import com.core.cutout.attachment.InteriorAttachment;
import com.core.edge.Edge;
import com.core.math.Line;
import com.core.math.Point2D;
import com.core.math.Vector2D;
import static com.core.math.Constants.EPSILON;
import java.util.List;

public abstract class InteriorCutout extends AbstractCutout {

    protected InteriorAttachment attachment;

    public InteriorCutout(int internalId, String cutoutNo, InteriorAttachment attachment) {
        super(internalId, cutoutNo);
        this.attachment = attachment;
    }

    public InteriorAttachment getAttachment() {
        return attachment;
    }

    @Override
    public Type getCutoutType() {
        return Type.Interior;
    }
    protected Point2D  findRefEges(Edge currEdge, Edge nextEdge) {
        Point2D[] points = offsets(currEdge, nextEdge);
        Point2D offsetXPoint = points[0];
        Point2D offsetYPoint = points[1];
        Point2D dimCenter = calculateCutoutCenter(currEdge, nextEdge, 0,0, false);
        double x_normal=1;
        double y_normal=1;
        if(offsetXPoint.x== dimCenter.x) {if(offsetYPoint.x>dimCenter.x)x_normal =0;}
            else if(offsetXPoint.x> dimCenter.x) x_normal=0;

        if(offsetYPoint.y==dimCenter.y) {if(offsetXPoint.y > dimCenter.y) y_normal=0;}
            else if(offsetYPoint.y>dimCenter.y) y_normal=0;
System.out.println("offsetXPoint.x="+offsetXPoint.x+ "dimCenter.x="+dimCenter.x+ "  klklklklklklkl");
        Point2D xy =new Point2D(x_normal,y_normal);

        return xy;
    }

    protected Point2D calculateCutoutCenter(Edge currEdge, Edge nextEdge, double w, double h, boolean fromCutout) {
        Vector2D corner = new Vector2D(currEdge.getEndPoint());

        boolean currIsHorizontal = Math.abs(currEdge.getEndPoint().y - currEdge.getStartPoint().y) < EPSILON;
        boolean currIsVertical = Math.abs(currEdge.getEndPoint().x - currEdge.getStartPoint().x) < EPSILON;
        boolean nextIsHorizontal = Math.abs(nextEdge.getStartPoint().y - nextEdge.getEndPoint().y) < EPSILON;
        boolean nextIsVertical = Math.abs(nextEdge.getStartPoint().x - nextEdge.getEndPoint().x) < EPSILON;

        Point2D refEdgeVH = new Point2D(1,1);

        if (fromCutout) {
            refEdgeVH = findRefEges(currEdge, nextEdge);
        }


        boolean currIsAxisAligned = currIsHorizontal || currIsVertical;
        boolean nextIsAxisAligned = nextIsHorizontal || nextIsVertical;

        boolean x_normal=true;
        boolean y_normal=true;
        // Use projected axis booleans (currIsHorizontal1, etc.) for determining normal directions
//        if(currIsHorizontal && (currEdge.getEndPoint().x > currEdge.getStartPoint().x)) x_normal=false;
//        if(currIsVertical && (currEdge.getEndPoint().y > currEdge.getStartPoint().y)) y_normal=false;
//        if(nextIsHorizontal && (nextEdge.getEndPoint().x < nextEdge.getStartPoint().x)) x_normal=false;
//        if(nextIsVertical && (nextEdge.getEndPoint().y < nextEdge.getStartPoint().y)) y_normal=false;
        if(refEdgeVH.x==0) x_normal=false;
        if(refEdgeVH.y==0) y_normal=false;
        Vector2D xVec, yVec;
        double offsetXValue = attachment.getOffsetX();
        double offsetYValue = attachment.getOffsetY();

        if(!x_normal) offsetXValue = offsetXValue+w;
        if(!y_normal) offsetYValue = offsetYValue+h;
        // Case 2: Both edges are NOT horizontal/vertical - use H/V axes
        if (!currIsAxisAligned && !nextIsAxisAligned) {
            // Use horizontal and vertical axes
            xVec = new Vector2D(1, 0);  // Horizontal
            yVec = new Vector2D(0, 1);  // Vertical

            // Determine direction to point inside the shape
            // Check which direction is "inside" based on edge directions
            Vector2D currDir = Vector2D.create(currEdge.getEndPoint(), currEdge.getStartPoint());
            Vector2D nextDir = Vector2D.create(nextEdge.getStartPoint(), nextEdge.getEndPoint());

            // Adjust xVec direction (check if we need to flip it)
            if (shouldFlipX(currDir, nextDir)) {
                xVec.multiply(-1);
            }

            // Adjust yVec direction (check if we need to flip it)
            if (shouldFlipY(currDir, nextDir)) {
                yVec.multiply(-1);
            }

            xVec.multiply(offsetXValue);
            yVec.multiply(offsetYValue);
        }
        // Case 1: Only one edge is horizontal/vertical
        else if (currIsAxisAligned != nextIsAxisAligned) {
            if (currIsAxisAligned) {
                // Use currEdge as first axis
                xVec = Vector2D.create(currEdge.getEndPoint(), currEdge.getStartPoint());
                xVec.normalize();

                // Create perpendicular axis pointing inside
                yVec = new Vector2D(-xVec.y, xVec.x);  // 90° rotation

                // Check if yVec points inside using nextEdge direction
                Vector2D nextDir = Vector2D.create(nextEdge.getStartPoint(), nextEdge.getEndPoint());
                if (yVec.dot(nextDir) < 0) {
                    yVec.multiply(-1);
                }

                xVec.multiply(offsetXValue);
                yVec.multiply(offsetYValue);
            } else {
                // Use nextEdge as first axis (treat as yVec for consistency)
                yVec = Vector2D.create(nextEdge.getStartPoint(), nextEdge.getEndPoint());
                yVec.normalize();

                // Create perpendicular axis pointing inside
                xVec = new Vector2D(yVec.y, -yVec.x);  // 90° rotation

                // Check if xVec points inside using currEdge direction
                Vector2D currDir = Vector2D.create(currEdge.getEndPoint(), currEdge.getStartPoint());
                if (xVec.dot(currDir) < 0) {
                    xVec.multiply(-1);
                }
                if(currEdge.getEndPoint().x == currEdge.getStartPoint().x ||
                        nextEdge.getStartPoint().y == nextEdge.getEndPoint().y) {
                    // Swap the offsets when dealing with vertical/horizontal edges
                    xVec.multiply(offsetYValue);
                    yVec.multiply(offsetXValue);
                } else {
                    xVec.multiply(offsetXValue);
                    yVec.multiply(offsetYValue);
                }
            }
        }
        // Normal case: Both edges are horizontal/vertical (90° angle)
        else {
            xVec = Vector2D.create(currEdge.getEndPoint(), currEdge.getStartPoint());
            yVec = Vector2D.create(nextEdge.getStartPoint(), nextEdge.getEndPoint());
            xVec.normalize();
            yVec.normalize();
            if(currEdge.getEndPoint().x == currEdge.getStartPoint().x ||
                    nextEdge.getStartPoint().y == nextEdge.getEndPoint().y) {
                // Swap the offsets when dealing with vertical/horizontal edges
                xVec.multiply(offsetYValue);
                yVec.multiply(offsetXValue);
            } else {
                xVec.multiply(offsetXValue);
                yVec.multiply(offsetYValue);
            }
        }

        corner.add(xVec);
        corner.add(yVec);

        return corner.toPoint();
    }

    // Helper method to determine if horizontal axis should be flipped
    private boolean shouldFlipX(Vector2D currDir, Vector2D nextDir) {
        // Use cross product to determine interior direction
        double cross = currDir.x * nextDir.y - currDir.y * nextDir.x;
        // Logic depends on your coordinate system and winding order
        return cross > 0;  // Adjust based on your needs
    }

    // Helper method to determine if vertical axis should be flipped
    private boolean shouldFlipY(Vector2D currDir, Vector2D nextDir) {
        // Use cross product to determine interior direction
        double cross = currDir.x * nextDir.y - currDir.y * nextDir.x;
        // Logic depends on your coordinate system and winding order
        return cross < 0;  // Adjust based on your needs
    }
    protected Point2D[] offsets(Edge currEdge, Edge nextEdge) {
        Vector2D corner = new Vector2D(currEdge.getEndPoint());

        boolean currIsHorizontal = Math.abs(currEdge.getEndPoint().y - currEdge.getStartPoint().y) < EPSILON;
        boolean currIsVertical = Math.abs(currEdge.getEndPoint().x - currEdge.getStartPoint().x) < EPSILON;
        boolean nextIsHorizontal = Math.abs(nextEdge.getStartPoint().y - nextEdge.getEndPoint().y) < EPSILON;
        boolean nextIsVertical = Math.abs(nextEdge.getStartPoint().x - nextEdge.getEndPoint().x) < EPSILON;

        boolean currIsAxisAligned = currIsHorizontal || currIsVertical;
        boolean nextIsAxisAligned = nextIsHorizontal || nextIsVertical;

        Vector2D xVec, yVec;
        double offsetXValue = attachment.getOffsetX();
        double offsetYValue = attachment.getOffsetY();

        // Case 2: Both edges are NOT horizontal/vertical - use H/V axes
        if (!currIsAxisAligned && !nextIsAxisAligned) {
            // Use horizontal and vertical axes
            xVec = new Vector2D(1, 0);  // Horizontal
            yVec = new Vector2D(0, 1);  // Vertical

            // Determine direction to point inside the shape
            Vector2D currDir = Vector2D.create(currEdge.getEndPoint(), currEdge.getStartPoint());
            Vector2D nextDir = Vector2D.create(nextEdge.getStartPoint(), nextEdge.getEndPoint());

            // Adjust xVec direction
            if (shouldFlipX(currDir, nextDir)) {
                xVec.multiply(-1);
            }

            // Adjust yVec direction
            if (shouldFlipY(currDir, nextDir)) {
                yVec.multiply(-1);
            }

            xVec.multiply(offsetXValue);
            yVec.multiply(offsetYValue);
        }
        // Case 1: Only one edge is horizontal/vertical
        else if (currIsAxisAligned != nextIsAxisAligned) {
            if (currIsAxisAligned) {
                // Use currEdge as first axis
                xVec = Vector2D.create(currEdge.getEndPoint(), currEdge.getStartPoint());
                xVec.normalize();

                // Create perpendicular axis pointing inside
                yVec = new Vector2D(-xVec.y, xVec.x);  // 90° rotation

                // Check if yVec points inside using nextEdge direction
                Vector2D nextDir = Vector2D.create(nextEdge.getStartPoint(), nextEdge.getEndPoint());
                if (yVec.dot(nextDir) < 0) {
                    yVec.multiply(-1);
                }
                if(currEdge.getEndPoint().x == currEdge.getStartPoint().x ||
                        nextEdge.getStartPoint().y == nextEdge.getEndPoint().y) {
                    // Swap the offsets when dealing with vertical/horizontal edges
                    xVec.multiply(offsetYValue);
                    yVec.multiply(offsetXValue);
                } else {
                    xVec.multiply(offsetXValue);
                    yVec.multiply(offsetYValue);
                }
            } else {
                // Use nextEdge as first axis (treat as yVec for consistency)
                yVec = Vector2D.create(nextEdge.getStartPoint(), nextEdge.getEndPoint());
                yVec.normalize();

                // Create perpendicular axis pointing inside
                xVec = new Vector2D(yVec.y, -yVec.x);  // 90° rotation

                // Check if xVec points inside using currEdge direction
                Vector2D currDir = Vector2D.create(currEdge.getEndPoint(), currEdge.getStartPoint());
                if (xVec.dot(currDir) < 0) {
                    xVec.multiply(-1);
                }
                if(currEdge.getEndPoint().x == currEdge.getStartPoint().x ||
                        nextEdge.getStartPoint().y == nextEdge.getEndPoint().y) {
                    // Swap the offsets when dealing with vertical/horizontal edges
                    xVec.multiply(offsetYValue);
                    yVec.multiply(offsetXValue);
                } else {
                    xVec.multiply(offsetXValue);
                    yVec.multiply(offsetYValue);
                }
            }
        }
        // Normal case: Both edges are horizontal/vertical (90° angle)
        else {
            xVec = Vector2D.create(currEdge.getEndPoint(), currEdge.getStartPoint());
            yVec = Vector2D.create(nextEdge.getStartPoint(), nextEdge.getEndPoint());
            xVec.normalize();
            yVec.normalize();
            if(currEdge.getEndPoint().x == currEdge.getStartPoint().x ||
                    nextEdge.getStartPoint().y == nextEdge.getEndPoint().y) {
                // Swap the offsets when dealing with vertical/horizontal edges
                xVec.multiply(offsetYValue);
                yVec.multiply(offsetXValue);
            } else {
                xVec.multiply(offsetXValue);
                yVec.multiply(offsetYValue);
            }
        }

        // Calculate offset points on each axis
        // offsetXPoint: point on X-axis (corner + xVec)
        // offsetYPoint: point on Y-axis (corner + yVec)
        Vector2D offsetX = corner.copy();
        Vector2D offsetY = corner.copy();

        offsetX.add(xVec);
        offsetY.add(yVec);

        return new Point2D[]{offsetX.toPoint(), offsetY.toPoint()};
    }
}
