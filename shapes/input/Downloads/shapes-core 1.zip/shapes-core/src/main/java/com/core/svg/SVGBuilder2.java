package com.core.svg;

import com.core.math.Point2D;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SVGBuilder2 {
    private final StringBuilder sb = new StringBuilder();
    private final List<String> elements = new ArrayList<>();
    private int sizeX = 240;
    private int sizeY = 240;

    public static class SvgPathBuilder {
        private final StringBuffer sb = new StringBuffer();
        private final SVGBuilder2 svgBuilder;
        private String fill = null;
        private String stroke = null;
        private String dashPattern = null;
        private String strokeOpacity = null;
        private String vectorEffect = null;
        private String strokeWidth = null;
        private String lineCap = null;
        private String translate = null;
        private double sx = 0;
        private double sy = 0;
        private Map<String, Point2D> textMap = new HashMap();

        public SvgPathBuilder(SVGBuilder2 svgBuilder) {
            this.svgBuilder = svgBuilder;
        }

        public SVGBuilder2.SvgPathBuilder startPath(double x, double y) {
            sb.append("<path d=\"").append("M ").append(x).append(" ").append(y).append(" ");
            sx = x;
            sy = y;
            return this;
        }

        public SVGBuilder2.SvgPathBuilder startPath(double x, double y, String id) {
            sb.append("<path class=\"control-edge\" id=\"").append(id).append("\" d=\"").append("M ").append(x).append(" ").append(y).append(" ");
            sx = x;
            sy = y;
            return this;
        }

        public SVGBuilder2.SvgPathBuilder lineTo(double x, double y) {
            sb.append("L ").append(x).append(" ").append(y).append(" ");
            sx = x;
            sy = y;
            return this;
        }

        public SVGBuilder2.SvgPathBuilder lineToWithText(double x, double y, String text) {
            sb.append("L ").append(x).append(" ").append(y).append(" ");
            double cx = (sx + x) / 2.0;
            double cy = (sy + y) / 2.0;
            textMap.put(text, new Point2D(cx, cy));
            sx = x;
            sy = y;
            return this;
        }

        public SVGBuilder2.SvgPathBuilder arcTo(double rx, double ry, double endX, double endY, boolean largeArc, boolean sweep) {
            sb.append("A ").append(rx).append(" ").append(ry).append(" 0 ")
                .append(largeArc ? "1 " : "0 ")
                .append(sweep ? "1 " : "0 ")
                .append(endX).append(" ").append(endY).append(" ");
            sx = endX;
            sy = endY;
            return this;
        }

        public SVGBuilder2.SvgPathBuilder arcToWithText(double rx, double ry, double endX, double endY, boolean largeArc, boolean sweep, String text) {
            sb.append("A ").append(rx).append(" ").append(ry).append(" 0 ")
                .append(largeArc ? "1 " : "0 ")
                .append(sweep ? "1 " : "0 ")
                .append(endX).append(" ").append(endY).append(" ");
            double cx = (sx + endX) / 2.0;
            double cy = (sy + endY) / 2.0;
            textMap.put(text, new Point2D(cx, cy));
            sx = endX;
            sy = endY;
            return this;
        }

        public SVGBuilder2.SvgPathBuilder cubicCurveTo() {
            // TODO
            return this;
        }

        public SVGBuilder2.SvgPathBuilder fill(String fill) {
            this.fill = fill;
            return this;
        }

        public SVGBuilder2.SvgPathBuilder stroke(String stroke) {
            this.stroke = stroke;
            return this;
        }

        public SVGBuilder2.SvgPathBuilder strokeDash(String dashPattern) {
            this.dashPattern = dashPattern;
            return this;
        }

        public SVGBuilder2.SvgPathBuilder strokeOpacity(String strokeOpacity) {
            this.strokeOpacity = strokeOpacity;
            return this;
        }

        public SVGBuilder2.SvgPathBuilder vectorEffect(String vectorEffect) {
            this.vectorEffect = vectorEffect;
            return this;
        }

        public SVGBuilder2.SvgPathBuilder strokeWidth(String strokeWidth) {
            this.strokeWidth = strokeWidth;
            return this;
        }

        public SVGBuilder2.SvgPathBuilder lineCap(String lineCap) {
            this.lineCap = lineCap;
            return this;
        }

        public SVGBuilder2.SvgPathBuilder translate(int x, int y) {
            this.translate = "translate(" + x + "," + y + ")";
            return this;
        }

        public SVGBuilder2 endPath(boolean close) {
            if (close) {
                sb.append("Z");
            }
            sb.append("\" ");

            if (fill != null && !fill.isEmpty()) {
                sb.append("fill=\"").append(fill).append("\" ");
            }
            if (stroke != null && !stroke.isEmpty()) {
                sb.append("stroke=\"").append(stroke).append("\" ");
            }
            if (dashPattern != null && !dashPattern.isEmpty()) {
                sb.append("stroke-dasharray=\"").append(dashPattern).append("\" ");
            }
            if (strokeOpacity != null && !strokeOpacity.isEmpty()) {
                sb.append("stroke-opacity=\"").append(strokeOpacity).append("\" ");
            }
            if (strokeWidth != null && !strokeWidth.isEmpty()) {
                sb.append("stroke-width=\"").append(strokeWidth).append("\" ");
            }
            if (lineCap != null && !lineCap.isEmpty()) {
                sb.append("stroke-linecap=\"").append(lineCap).append("\" ");
            }
            if (vectorEffect != null && !vectorEffect.isEmpty()) {
                sb.append("vector-effect=\"").append(vectorEffect).append("\" ");
            }
            if (translate != null && !translate.isEmpty()) {
                sb.append("transform=\"").append(translate).append("\" ");
            }
            sb.append(" />\n");

            for (Map.Entry<String, Point2D> entry : textMap.entrySet()) {
                Point2D p = entry.getValue();
                sb.append("<circle cx=\"");
                sb.append(p.x);
                sb.append("\" cy=\"");
                sb.append(p.y);
                sb.append("\" ");
                sb.append("transform=\"");
                sb.append(translate);
                sb.append("\" r=\"12\" fill=\"white\" stroke=\"none\" />\n");
                sb.append("<text x=\"");
                sb.append(p.x);
                sb.append("\" y=\"");
                sb.append(p.y);
                sb.append("\" transform=\"");
                sb.append(translate);
                sb.append("\" fill=\"blue\" text-anchor=\"middle\" dominant-baseline=\"middle\" font-size=\"1em\">");
                sb.append(entry.getKey());
                sb.append("</text>\n");
            }

            String content = sb.toString();
            //System.out.println(content);
            svgBuilder.elements.add(content);
            return svgBuilder;
        }

    }

    public SVGBuilder2(int sizeX, int sizeY) {
        this.sizeX = sizeX;
        this.sizeY = sizeY;
    }

    public SVGBuilder2.SvgPathBuilder pathBuilder() {
        SVGBuilder2.SvgPathBuilder pathBuilder = new SVGBuilder2.SvgPathBuilder(this);
        return pathBuilder.fill("none")
            .stroke("black")
            .vectorEffect("non-scaling-stroke")
            .strokeWidth("2")
            .translate(10, 10)
            .lineCap("round");
    }

    private void addCenterText(String text) {
        sb.append("<circle cx=\"120\" cy=\"120\" r=\"25\" fill=\"black\" stroke=\"none\" />\n");
        sb.append("<text x=\"0\" y=\"0\" transform=\"translate(120,120)\" fill=\"white\" text-anchor=\"middle\" dominant-baseline=\"middle\" font-weight=\"bold\" font-size=\"1.5em\">");
        sb.append(text);
        sb.append("</text>\n");
    }

    public String build() {
        sb.append("<svg width=\"");
        sb.append(sizeX);
        sb.append("\" height=\"");
        sb.append(sizeY);
        sb.append("\" xmlns=\"http://www.w3.org/2000/svg\">\n");
        for (String path : elements) {
            sb.append("\t").append(path).append("\n");
        }
        sb.append("</svg>");
        return sb.toString();
    }
}
