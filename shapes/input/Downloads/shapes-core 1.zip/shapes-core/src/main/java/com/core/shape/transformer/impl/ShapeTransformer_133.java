package com.core.shape.transformer.impl;

import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.edge.builder.EdgeBuilder;
import com.core.math.Point2D;
import com.core.shape.Param;
import com.core.shape.ParamList;
import com.core.shape.ShapeConstants;
import com.core.shape.transformer.ShapeTransformer;
import com.core.utility.EdgeDimCutTuple;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ShapeTransformer_133 extends ShapeTransformer {

    @Override
    public List<Edge> resize(List<Param> params, Map<String, Double> services) {
        ParamList p = new ParamList(params);
        double W = p.getParam(ShapeConstants.W).getValue();
        double H = p.getParam(ShapeConstants.H).getValue();
        double H1 = p.getParam(ShapeConstants.H1).getValue();
        double W1 = p.getParam(ShapeConstants.W1).getValue();

        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E4")) {
            trimLeft += services.get("E4");
        }

        Point2D p0 = new Point2D(trimLeft, trimBottom);
        Point2D p1 = new Point2D(p0.x + W1, p0.y);
        Point2D p2 = new Point2D(p1.x,p1.y + H-H1);
        Point2D p3 = new Point2D(p0.x+W, p2.y);
        Point2D p4 = new Point2D(p0.x+W, p3.y+H1);
        Point2D p5 = new Point2D(p0.x, p0.y+H);

        List<Edge> edges = new EdgeBuilder()
                .startPoint(p0)
                .straightEdge(p1)
                .straightEdge(p2)
                .straightEdge(p3)
                .straightEdge(p4)
                .straightEdge(p5)
                .straightEdge(p0)
                .build();

        calculateCircumference(edges);
        calculateArea(params);
        return edges;
    }

    @Override
    public EdgeDimCutTuple resize2(List<Param> params, Map<String, Double> services, Map<String, Double> coatingRemovals) {
        ParamList p = new ParamList(params);
        double W = p.getParam(ShapeConstants.W).getValue();
        double H = p.getParam(ShapeConstants.H).getValue();
        double H1 = p.getParam(ShapeConstants.H1).getValue();
        double W1 = p.getParam(ShapeConstants.W1).getValue();

        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E4")) {
            trimLeft += services.get("E4");
        }

        Point2D p0 = new Point2D(trimLeft, trimBottom);
        Point2D p1 = new Point2D(p0.x + W1, p0.y);
        Point2D p2 = new Point2D(p1.x,p1.y + H-H1);
        Point2D p3 = new Point2D(p0.x+W, p2.y);
        Point2D p4 = new Point2D(p0.x+W, p3.y+H1);
        Point2D p5 = new Point2D(p0.x, p0.y+H);

        List<Edge> edges = new EdgeBuilder()
                .startPoint(p0)
                .straightEdge(p1)
                .straightEdge(p2)
                .straightEdge(p3)
                .straightEdge(p4)
                .straightEdge(p5)
                .straightEdge(p0)
                .build();

        calculateCircumference(edges);
        calculateArea(params);

        List<Edge> dimLines = new ArrayList<>();
        dimLines.add(new StraightEdge(p4, p5, ShapeConstants.W));
        dimLines.add(new StraightEdge(p5, p0, ShapeConstants.H));
        dimLines.add(new StraightEdge(p0, p1, ShapeConstants.W1));
        dimLines.add(new StraightEdge(p3, p4, ShapeConstants.H1));

        double sT = services.getOrDefault("E5", 0.0);
        double sR = services.getOrDefault("E4", 0.0);
        double sB = services.getOrDefault("E1", 0.0);
        double sL = services.getOrDefault("E6", 0.0);

        Point2D cP0 = new Point2D(trimLeft-sL, trimBottom-sB);
        Point2D cP1 = new Point2D(cP0.x + W1 + sL + sR, cP0.y);
        Point2D cP2 = new Point2D(cP1.x,cP1.y + H -H1);
        Point2D cP3 = new Point2D(cP1.x + W -W1, cP2.y);
        Point2D cP4 = new Point2D(cP3.x, cP0.y + H + sB + sT);
        Point2D cP5 = new Point2D(cP0.x, cP0.y + H + sB + sT);

        List<Edge> cEdges = new EdgeBuilder()
                .startPoint(cP0)
                .straightEdge(cP1)
                .straightEdge(cP2)
                .straightEdge(cP3)
                .straightEdge(cP4)
                .straightEdge(cP5)
                .straightEdge(cP0)
                .build();

        double t = coatingRemovals.getOrDefault("E5", 0.0);
        double l2 = coatingRemovals.getOrDefault("E4", 0.0);
        double b = coatingRemovals.getOrDefault("E1", 0.0);
        double l = coatingRemovals.getOrDefault("E6", 0.0);
        double r = coatingRemovals.getOrDefault("E2", 0.0);
        double b2 = coatingRemovals.getOrDefault("E3", 0.0);

        Point2D crP00 = new Point2D(trimLeft, trimBottom);
        Point2D crP0 = new Point2D(trimLeft+l, trimBottom+b);
        Point2D crP1 = new Point2D(crP00.x + W1 - r, crP0.y);
        Point2D crP2 = new Point2D(crP1.x,crP00.y + H -H1+b2);
        Point2D crP3 = new Point2D(crP00.x+W-l2, crP2.y);
        Point2D crP4 = new Point2D(crP3.x, crP00.y+H- t);
        Point2D crP5 = new Point2D(crP0.x, crP4.y);
        List<Edge> crEdges = new EdgeBuilder()
                .startPoint(crP0)
                .straightEdge(crP1)
                .straightEdge(crP2)
                .straightEdge(crP3)
                .straightEdge(crP4)
                .straightEdge(crP5)
                .straightEdge(crP0)
                .build();

        return new EdgeDimCutTuple(edges, dimLines, cEdges, crEdges);

    }

    //L*H
    private void calculateArea(List<Param> params) {
        ParamList p = new ParamList(params);
        double W = p.getParam(ShapeConstants.W).getValue();
        double H = p.getParam(ShapeConstants.H).getValue();
        double W1 = p.getParam(ShapeConstants.W1).getValue();
        double H1 = p.getParam(ShapeConstants.H1).getValue();
        this.area = (W1 * H) + (H1 * (W-W1));
    }

}
