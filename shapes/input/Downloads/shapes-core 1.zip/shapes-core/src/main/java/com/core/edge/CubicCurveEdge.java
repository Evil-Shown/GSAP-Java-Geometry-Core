package com.core.edge;

import com.core.math.Point2D;

import java.util.ArrayList;
import java.util.List;

public class CubicCurveEdge implements Edge {
    private Point2D startPoint;
    private Point2D endPoint;
    private String edgeId;
    private String originalEdgeId;
    private Point2D controlSP;
    private Point2D controlEP;
    private boolean largeArc;
    private boolean sweep;
    private final List<Edge> children = new ArrayList<>();

    public CubicCurveEdge() {
    }

    public CubicCurveEdge(Point2D startPoint, Point2D endPoint, String edgeId, Point2D controlSP, Point2D controlEP) {
        this.startPoint = startPoint;
        this.endPoint = endPoint;
        this.edgeId = edgeId;
        this.controlSP = controlSP;
        this.controlEP = controlEP;
    }

    @Override
    public Point2D getStartPoint() {
        return startPoint;
    }

    public void setStartPoint(Point2D startPoint) {
        this.startPoint = startPoint;
    }

    @Override
    public Point2D getEndPoint() {
        return endPoint;
    }

    public void setEndPoint(Point2D endPoint) {
        this.endPoint = endPoint;
    }

    @Override
    public boolean getIsSweep() {
        return sweep;
    }

    public void setIsSweep(boolean l) {
        this.sweep = l;
    }

    @Override
    public Edge copy() {
        CubicCurveEdge edge = new CubicCurveEdge();
        edge.setEdgeId(this.edgeId);
        edge.setOriginalEdgeId(this.originalEdgeId);
        edge.setStartPoint(this.startPoint.copy());
        edge.setEndPoint(this.endPoint.copy());
        edge.setControlSP(this.controlSP.copy());
        edge.setControlEP(this.controlEP.copy());
        return edge;
    }

    @Override
    public void reverse() {
        Point2D temp = this.startPoint;
        this.startPoint = this.endPoint;
        this.endPoint = temp;
        temp = this.controlSP;
        this.controlSP = this.controlEP;
        this.controlEP = temp;
    }

    @Override
    public void debug() {
        System.out.print(this.edgeId + " [(" + this.startPoint.x + ", " + this.startPoint.y +
            ") => (" + this.endPoint.x + ", " + this.endPoint.y + ")]");
    }

    @Override
    public void rotate(double angle) {

    }

    @Override
    public Type getEdgeType() {
        return Type.CubicCurve;
    }

    @Override
    public String getEdgeId() {
        return edgeId;
    }

    @Override
    public String getOriginalEdgeId() {
        return originalEdgeId;
    }

    public void setEdgeId(String edgeId) {
        this.edgeId = edgeId;
    }

    public void setOriginalEdgeId(String originalEdgeId) {
        this.originalEdgeId = originalEdgeId;
    }

    public Point2D getControlSP() {
        return controlSP;
    }

    public void setControlSP(Point2D controlSP) {
        this.controlSP = controlSP;
    }

    public Point2D getControlEP() {
        return controlEP;
    }

    public void setControlEP(Point2D controlEP) {
        this.controlEP = controlEP;
    }

    public List<Edge> getChildren() {
        return children;
    }

    @Override
    public double getLength() {
        throw new RuntimeException("Not implemented");
    }

    @Override
    public double getRadius() {
        return 0.0;
    }

    @Override
    public boolean getIsLargeArc() {
        return largeArc;
    }

    public void setIsLargeArc(boolean l) {
        this.largeArc = l;
    }

    public boolean isSweep() {
        return sweep;
    }

    public void setSweep(boolean sweep) {
        this.sweep = sweep;
    }
}
