package com.core.cutout;

import com.core.cutout.attachment.CornerAttachment;
import com.core.edge.Edge;

import java.util.List;

public abstract class CornerCutout extends AbstractCutout {

    protected CornerAttachment attachment;

    public CornerCutout(int internalId, String cutoutNo, CornerAttachment attachment) {
        super(internalId, cutoutNo);
        this.attachment = attachment;
    }

    public CornerAttachment getAttachment() {
        return attachment;
    }

    @Override
    public Type getCutoutType() {
        return Type.Corner;
    }
}
