package com.core.cutout.impl;

import com.core.cutout.CutoutViewCreator;
import com.core.cutout.EdgeCutout;
import com.core.cutout.InteriorCutout;
import com.core.cutout.attachment.Attachment;
import com.core.cutout.attachment.EdgeAttachment;
import com.core.cutout.attachment.InteriorAttachment;
import com.core.edge.ArcEdge;
import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.math.Point2D;
import com.core.math.Vector2D;
import com.core.shape.ParamList;
import com.core.svg.SVGBuilder;
import com.core.svg.SVGBuilder2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.core.math.Line;

public class Cutout_109 extends InteriorCutout {

    public Cutout_109(String cutoutNo, Attachment attachment) {
        super(109, cutoutNo, (InteriorAttachment) attachment);
    }

    //@Override
    public Point2D attach(int idx, List<Edge> edges, List<Edge> baseEdges, Point2D previousPoint) {
        return null;
    }

    @Override
public CutoutAttachInfo attach(int idx, Edge currEdge, Edge nextEdge, List<Edge> edges,List<Edge> DxFedges, List<Line> DimLines, CutoutAttachInfo previousInfo, boolean dxf) {
        ParamList p = new ParamList(params);
        double R = p.getParam("R").getValue();

        Point2D cutoutCenter = calculateCutoutCenter(currEdge, nextEdge,R*2,R*2,true);
        Point2D dimCenter = calculateCutoutCenter(currEdge, nextEdge, 0,0,true);
        Point2D[] points = offsets(currEdge, nextEdge);
        Point2D offsetXPoint = points[0];
        Point2D offsetYPoint = points[1];

        Point2D p_ml = new Point2D(cutoutCenter.x - R, cutoutCenter.y);
        Point2D p_mr = new Point2D(cutoutCenter.x + R, cutoutCenter.y);

        ArcEdge e1 = new ArcEdge(R, true, true, p_ml, p_mr);
        ArcEdge e2 = new ArcEdge(R, true, true, p_mr, p_ml);

        edges.add(e1);
        edges.add(e2);

        DimLines.add(new Line("X",offsetXPoint, dimCenter ));
        DimLines.add(new Line("Y",offsetYPoint, dimCenter ));

        return previousInfo;
    }

    public static CutoutViewCreator createCutoutViewCreator() {
        return new CutoutViewCreator() {

            @Override
            public SVGBuilder2 getThumbnailBuilder() {
                return new SVGBuilder2(180, 180)
                    .pathBuilder()
                    .startPath(130, 80)
                    .arcTo(50, 50, 30, 80, true, true)
                    .arcTo(50, 50, 130, 80, true, true)
                    .endPath(true);
            }

            @Override
            public SVGBuilder2 getPreviewBuilder() {
                return new SVGBuilder2(180, 180)
                        .pathBuilder()
                        .startPath(130, 80)
                        .arcTo(50, 50, 30, 80, true, true)
                        .arcTo(50, 50, 130, 80, true, true)
                        .endPath(true)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(80, 80)
                        .lineToWithText(130, 80, "R")
                        .endPath(false);
            }

            @Override
            public Type getCutoutType() {
                return Type.Interior;
            }

            @Override
            public List<String> getParamNames() {
                return Arrays.asList("R");
            }

            @Override
            public List<String> getCutoutMappingParamNames() {
                return Arrays.asList("R");
            }
        };
    }
}