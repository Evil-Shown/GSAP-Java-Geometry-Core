package com.core.shape.transformer.impl;

import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.edge.builder.EdgeBuilder;
import com.core.math.Point2D;
import com.core.shape.Param;
import com.core.shape.ParamList;
import com.core.shape.ShapeConstants;
import com.core.shape.transformer.ShapeTransformer;
import com.core.utility.EdgeDimCutTuple;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ShapeTransformer_135 extends ShapeTransformer {
    @Override
    public List<Edge> resize(List<Param> params, Map<String, Double> services) {
        ParamList p = new ParamList(params);
        double H = p.getParam("H").getValue();
        double L = p.getParam("L").getValue();
        double R = p.getParam("R").getValue();

        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E7")) {
            trimLeft += services.get("E7");
        }

        Point2D p0 = new Point2D(trimLeft, trimBottom);
        Point2D p1 = new Point2D(p0.x + R, p0.y);
        Point2D p2 = new Point2D(p0.x+L-R,p1.y );
        Point2D p3 = new Point2D(p0.x+L, p0.y + R);
        Point2D p4 = new Point2D(p0.x+L, p0.y +H- R);
        Point2D p5 = new Point2D(p0.x+L-R, p0.y +H);
        Point2D p6 = new Point2D(p0.x+R, p5.y );
        Point2D p7 = new Point2D(p0.x, p6.y - R);
        Point2D p8 = new Point2D(p0.x, p0.y+R);

        calculateArea(params);
        return new EdgeBuilder()
                .startPoint(p1)
                .straightEdge(p2)
                .arcEdge(R, false, false, p3)
                .straightEdge(p4)
                .arcEdge(R, false, false, p5)
                .straightEdge(p6)
                .arcEdge(R, false, false, p7)
                .straightEdge(p8)
                .arcEdge(R, false, false, p1)
                .build();
    }

    @Override
    public EdgeDimCutTuple resize2(List<Param> params, Map<String, Double> services, Map<String, Double> coatingRemovals) {
        ParamList p = new ParamList(params);
        double H = p.getParam("H").getValue();
        double L = p.getParam("L").getValue();
        double R = p.getParam("R").getValue();

        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E7")) {
            trimLeft += services.get("E7");
        }

        Point2D p0 = new Point2D(trimLeft, trimBottom);
        Point2D p1 = new Point2D(p0.x + R, p0.y);
        Point2D p2 = new Point2D(p0.x+L-R,p1.y );
        Point2D p3 = new Point2D(p0.x+L, p0.y + R);
        Point2D p4 = new Point2D(p0.x+L, p0.y +H- R);
        Point2D p5 = new Point2D(p0.x+L-R, p0.y +H);
        Point2D p6 = new Point2D(p0.x+R, p5.y );
        Point2D p7 = new Point2D(p0.x, p6.y - R);
        Point2D p8 = new Point2D(p0.x, p0.y+R);
        Point2D p9 = new Point2D(p0.x+L, p0.y);
        Point2D p10 = new Point2D(p0.x+L, p0.y+H);

        List<Edge> edges = new EdgeBuilder()
                .startPoint(p1)
                .straightEdge(p2)
                .arcEdge(R, false, false, p3)
                .straightEdge(p4)
                .arcEdge(R, false, false, p5)
                .straightEdge(p6)
                .arcEdge(R, false, false, p7)
                .straightEdge(p8)
                .arcEdge(R, false, false, p1)
                .build();

        List<Edge> dimLines = new ArrayList<>();
        dimLines.add(new StraightEdge(p0, p9, ShapeConstants.L));
        dimLines.add(new StraightEdge(p9, p10, ShapeConstants.H));
        dimLines.add(new StraightEdge(new Point2D(p7.x, p7.y),new Point2D(p7.x+R ,p7.y), ShapeConstants.R));

        calculateCircumference(edges);
        calculateArea(params);

        double s1 = services.getOrDefault("E1", 0.0);
        double s2 = services.getOrDefault("E2", 0.0);
        double s3 = services.getOrDefault("E3", 0.0);
        double s4 = services.getOrDefault("E4", 0.0);
        double s5 = services.getOrDefault("E5", 0.0);
        double s6 = services.getOrDefault("E6", 0.0);
        double s7 = services.getOrDefault("E7", 0.0);
        double s8 = services.getOrDefault("E8", 0.0);

        Point2D st = new Point2D(Math.max(s7,s8),Math.max(s1,s8));

        Point2D cP0 = new Point2D(trimLeft-st.x, trimBottom-st.y);
        Point2D cP1 = new Point2D(cP0.x + R+ st.x, cP0.y);
        Point2D cP2 = new Point2D(cP0.x+L-R+st.x,cP1.y );
        Point2D cP3 = new Point2D(cP2.x, cP2.y +s1-s2);
        Point2D cP4 = new Point2D(cP3.x+R+s2, cP0.y +st.y+R);
        Point2D cP5 = new Point2D(cP4.x+s3-s2, cP4.y );
        Point2D cP6 = new Point2D(cP5.x, cP5.y+H-2*R);
        Point2D cP7 = new Point2D(cP6.x-s3+s4, cP6.y);
        Point2D cP8 = new Point2D(cP7.x-s4-R, cP7.y+R+s4);
        Point2D cP9 = new Point2D(cP7.x-s4-R, cP8.y-s4+s5);
        Point2D cP10 = new Point2D(cP8.x-L+2*R, cP9.y);
        Point2D cP11 = new Point2D(cP10.x, cP9.y+s6-s5);
        Point2D cP12 = new Point2D(cP11.x-R-s6, cP11.y-s6-R);
        Point2D cP13 = new Point2D(cP12.x+s6-s7, cP12.y);
        Point2D cP14 = new Point2D(cP13.x, cP13.y-H+2*R);
        Point2D cP15 = new Point2D(cP14.x-s8+s7, cP14.y);
        Point2D cP16 = new Point2D(cP15.x+R+ s8, cP1.y+s1-s8);


        System.out.println(cP0+" "+cP1+" "+cP2+" "+cP3+" "+cP4+" "+cP5+" "+cP6+" "+cP7+" "+cP8+" " +cP9+" "+cP10+" 11="+cP11+" 12="+cP12+" "+cP13+" "+" " +cP14+" "+cP15+" "+cP16+"  kkkkk");
        List<Edge> cEdges = new EdgeBuilder()
                .startPoint(cP1)
                .straightEdge(cP2)
                .straightEdge(cP3)
                .arcEdge(R+s2, false, false, cP4)
                .straightEdge(cP5)
                .straightEdge(cP6)
                .straightEdge(cP7)
                .arcEdge(R+s4, false, false, cP8)
                .straightEdge(cP9)
                .straightEdge(cP10)
                .straightEdge(cP11)
                .arcEdge(R+s6, false, false, cP12)
                .straightEdge(cP13)
                .straightEdge(cP14)
                .straightEdge(cP15)
                .arcEdge(R+s8, false, false, cP16)
                .straightEdge(cP1)
                .build();

        double c1 = coatingRemovals.getOrDefault("E1", 0.0);
        double c2 = coatingRemovals.getOrDefault("E2", 0.0);
        double c3 = coatingRemovals.getOrDefault("E3", 0.0);
        double c4 = coatingRemovals.getOrDefault("E4", 0.0);
        double c5 = coatingRemovals.getOrDefault("E5", 0.0);
        double c6 = coatingRemovals.getOrDefault("E6", 0.0);
        double c7 = coatingRemovals.getOrDefault("E7", 0.0);
        double c8 = coatingRemovals.getOrDefault("E8", 0.0);

        Point2D crP0 = new Point2D(trimLeft, trimBottom);
        Point2D crP1 = new Point2D(crP0.x + R, crP0.y+c1);
        Point2D crP2 = new Point2D(crP1.x+L-R*2,crP1.y);
        Point2D crP3 = new Point2D(crP2.x, crP0.y+c2);
        Point2D crP4 = new Point2D(crP0.x+L-c2, crP0.y+R);
        Point2D crP5 = new Point2D(crP0.x+L-c3, crP4.y);
        Point2D crP6 = new Point2D(crP5.x, crP0.y+H-R);
        Point2D crP7 = new Point2D(crP0.x+L-c4, crP6.y);
        Point2D crP8 = new Point2D(crP0.x+L-R, crP0.y+H-c4);
        Point2D crP9 = new Point2D(crP0.x+L-R, crP0.y+H-c5);
        Point2D crP10 = new Point2D(crP0.x+R, crP9.y);
        Point2D crP11 = new Point2D(crP10.x, crP0.y+H-c6);
        Point2D crP12 = new Point2D(crP0.x+c6, crP0.y+H-R);
        Point2D crP13 = new Point2D(crP0.x+c7, crP12.y);
        Point2D crP14 = new Point2D(crP13.x, crP0.y+R);
        Point2D crP15 = new Point2D(crP0.x+c8, crP14.y);
        Point2D crP16 = new Point2D(crP0.x+R, crP0.y+c8);
        List<Edge> crEdges = new EdgeBuilder()
                .startPoint(crP1)
                .straightEdge(crP2)
                .straightEdge(crP3)
                .arcEdge(R-c2, false, false, crP4)
                .straightEdge(crP5)
                .straightEdge(crP6)
                .straightEdge(crP7)
                .arcEdge(R-c4, false, false, crP8)
                .straightEdge(crP9)
                .straightEdge(crP10)
                .straightEdge(crP11)
                .arcEdge(R-c6, false, false, crP12)
                .straightEdge(crP13)
                .straightEdge(crP14)
                .straightEdge(crP15)
                .arcEdge(R-c8, false, false, crP16)
                .straightEdge(crP1)
                .build();



        return new EdgeDimCutTuple(edges, dimLines, cEdges, crEdges);
    }

    private void calculateArea(List<Param> params) {

        ParamList p = new ParamList(params);
        double L = p.getParam(ShapeConstants.L).getValue();
        double H = p.getParam(ShapeConstants.H).getValue();
        double R = p.getParam(ShapeConstants.R).getValue();

        this.area =H*L-R*R*(4-Math.PI);

    }


}
