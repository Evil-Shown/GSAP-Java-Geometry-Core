package com.core.cutout.impl;

import com.core.cutout.CutoutViewCreator;
import com.core.cutout.EdgeCutout;
import com.core.cutout.attachment.Attachment;
import com.core.cutout.attachment.EdgeAttachment;
import com.core.edge.ArcEdge;
import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.math.Point2D;
import com.core.math.Vector2D;
import com.core.shape.ParamList;
import com.core.svg.SVGBuilder;
import com.core.svg.SVGBuilder2;
import com.core.math.Line;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Cutout_104 extends EdgeCutout {

    public Cutout_104(String cutoutNo, Attachment attachment) {
        super(104, cutoutNo, (EdgeAttachment) attachment);
    }

    //@Override
    public Point2D attach(int idx, List<Edge> edges, List<Edge> baseEdges, Point2D previousPoint) {
        return null;
    }

    @Override
public CutoutAttachInfo attach(int idx, Edge currEdge, Edge nextEdge, List<Edge> edges,List<Edge> DxFedges, List<Line> DimLines, CutoutAttachInfo previousInfo, boolean dxf) {
        ParamList p = new ParamList(params);
        double W = p.getParam("W").getValue();
        double R = p.getParam("R").getValue();
        double offset = attachment.getOffset();

        Vector2D edgeVec = Vector2D.create(currEdge.getStartPoint(), currEdge.getEndPoint());

        if (!attachment.isStartOffset()) {
            offset = edgeVec.length() - offset;
        }

        Vector2D v1 = edgeVec.normalized();
        if(attachment.isStartOffset())
            v1.multiply(offset);
        else
            v1.multiply(offset - W );

        Vector2D p1 = new Vector2D(currEdge.getStartPoint());
        p1.add(v1);

        Point2D startPoint = currEdge.getStartPoint();
        if (previousInfo != null) {
            edges.remove(edges.size() - 1);
            startPoint = previousInfo.lastPoint;
        }

        StraightEdge e1 = new StraightEdge(startPoint, new Point2D(p1));
        e1.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-1");
        e1.setOriginalEdgeId(currEdge.getOriginalEdgeId());
        edges.add(e1);
        DxFedges.add(e1);

        Vector2D v2 = edgeVec.normalized();
        v2.multiply(R);
        Vector2D t1 = v2.copy();
        v2.rotate(Math.toRadians(90.0));
        v2.add(t1);

        Vector2D p2 = new Vector2D(e1.getEndPoint());
        p2.add(v2);

        ArcEdge e2 = new ArcEdge(R, false, true, e1.getEndPoint(), new Point2D(p2));
        e2.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-2");
        //edge.getChildren().add(e3);
        if(dxf)
        edges.add(e2);

        ArcEdge eDxF2 = new ArcEdge(R, false, true, new Point2D(p2), e1.getEndPoint());
        eDxF2.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-2");
        //edge.getChildren().add(e3);
        DxFedges.add(eDxF2);

        Vector2D v3 = edgeVec.normalized();
        v3.multiply(W - 2 * R);

        Vector2D p3 = new Vector2D(e2.getEndPoint());
        p3.add(v3);

        StraightEdge e3 = new StraightEdge(e2.getEndPoint(), new Point2D(p3));
        e3.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-3");
        edges.add(e3);
        DxFedges.add(e3);

        Vector2D v4 = edgeVec.normalized();
        v4.multiply(W);

        Vector2D p4 = new Vector2D(e1.getEndPoint());
        p4.add(v4);

        ArcEdge e4 = new ArcEdge(R, false, true, e3.getEndPoint(), new Point2D(p4));
        e4.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-4");
        //edge.getChildren().add(e3);
        if(dxf)
            edges.add(e4);

        ArcEdge eDxF4 = new ArcEdge(R, false, true, new Point2D(p4), e3.getEndPoint());
        e4.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-4");
        DxFedges.add(eDxF4);

        StraightEdge e5 = new StraightEdge(e4.getEndPoint(), currEdge.getEndPoint());
        e5.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-5");
        e5.setOriginalEdgeId(currEdge.getOriginalEdgeId());
        edges.add(e5);
        DxFedges.add(e5);

        CutoutAttachInfo info = new CutoutAttachInfo();
        info.isOnNextEdge = false;
        info.lastPoint = e5.getStartPoint();

        calculateWaste();
        calculateCircumference(List.of(e2, e3, e4));

        Point2D connerPoint = calculateConnerPoint(currEdge,attachment.isStartOffset());
        Point2D cutoutCenterPoint = calculateCutoutCenter(currEdge,attachment.isStartOffset());
        DimLines.add(new Line("E",cutoutCenterPoint, connerPoint ));

        return info;
    }

    public static CutoutViewCreator createCutoutViewCreator() {
        return new CutoutViewCreator() {

            @Override
            public SVGBuilder2 getThumbnailBuilder() {
                return new SVGBuilder2(180, 180)
                    .pathBuilder()
                    .strokeOpacity("0.25")
                    .startPath(0, 90)
                    .lineTo(25, 90)
                    .endPath(false)
                    .pathBuilder()
                    //.startPath(0, 90)
                    .startPath(25, 90)
                    .arcTo(20, 20, 45, 70, false, true)
                    .lineTo(115, 70)
                    .arcTo(20, 20, 135, 90, false, true)
                    //.lineTo(160, 90)
                    .endPath(false)
                    .pathBuilder()
                    .strokeOpacity("0.25")
                    .startPath(135, 90)
                    .lineTo(160, 90)
                    .endPath(false);
            }

            @Override
            public SVGBuilder2 getPreviewBuilder() {
                return new SVGBuilder2(200, 200)
                        .pathBuilder()
                        .strokeOpacity("0.25")
                        .startPath(10, 90)
                        .lineTo(35, 90)
                        .endPath(false)
                        .pathBuilder()
                        //.startPath(0, 90)
                        .startPath(35, 90)
                        .arcTo(20, 20, 55, 70, false, true)
                        .lineTo(125, 70)
                        .arcTo(20, 20, 145, 90, false, true)
                        //.lineTo(160, 90)
                        .endPath(false)
                        .pathBuilder()
                        .strokeOpacity("0.25")
                        .startPath(145, 90)
                        .lineTo(170, 90)
                        .endPath(false)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(35, 100)
                        .lineToWithText(145, 100, "W")
                        .endPath(false)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(0, 90)
                        .lineToWithText(0, 70, "R")
                        .endPath(false);
            }

            @Override
            public Type getCutoutType() {
                return Type.Edge;
            }

            @Override
            public List<String> getParamNames() {
                return Arrays.asList("W", "R");
            }

            @Override
            public List<String> getCutoutMappingParamNames() {
                return Arrays.asList("W", "R");
            }
        };
    }

    private void calculateWaste() {
        ParamList p = new ParamList(params);
        double W = p.getParam("W").getValue();
        double R = p.getParam("R").getValue();
        waste = (W - 2 * R) * R + (Math.PI * R * R) / 2.0;
    }
}
