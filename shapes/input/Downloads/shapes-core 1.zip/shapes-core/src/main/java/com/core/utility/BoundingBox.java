package com.core.utility;

import com.core.edge.ArcEdge;
import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.math.Point2D;

import java.util.ArrayList;
import java.util.List;

public class BoundingBox {

    private final Point2D minPoint; // Origin
    private final Point2D maxPoint;

    private BoundingBox(Point2D minPoint, Point2D maxPoint) {
        this.minPoint = minPoint;
        this.maxPoint = maxPoint;
    }

    public Point2D getMinPoint() {
        return minPoint;
    }

    public Point2D getMaxPoint() {
        return maxPoint;
    }

    public Point2D getOrigin() {
        return minPoint;
    }

    public double getWidth() {
        return maxPoint.x - minPoint.x;
    }

    public double getHeight() {
        return maxPoint.y - minPoint.y;
    }

    public static BoundingBox fromPoints(List<Point2D> points) {
        double minX = Double.MAX_VALUE, maxX = Double.MIN_VALUE;
        double minY = Double.MAX_VALUE, maxY = Double.MIN_VALUE;

        for (Point2D p : points) {
            if (p.x < minX)
                minX = p.x;
            if (p.x > maxX)
                maxX = p.x;
            if (p.y < minY)
                minY = p.y;
            if (p.y > maxY)
                maxY = p.y;
        }
        return new BoundingBox(new Point2D(minX, minY), new Point2D(maxX, maxY));
    }

    public static BoundingBox fromArc(Point2D start, Point2D end, double r, boolean isShape131, boolean sweep,
            boolean largeArc) {
        Point2D C = GeometryHelper.findCircleCenterOfArc(start, end, r, largeArc, sweep);
        Point2D M = GeometryHelper.findMidPointOfArc(start, end, r, largeArc, sweep);

        Point2D A = start;
        Point2D B = end;

        Point2D E = new Point2D(C.x + r, C.y);
        Point2D N = new Point2D(C.x, C.y + r);
        Point2D W = new Point2D(C.x - r, C.y);
        Point2D S = new Point2D(C.x, C.y - r);

        double ABM = (A.x * (B.y - M.y) + B.x * (M.y - A.y) + M.x * (A.y - B.y)) / 2.0;
        double ABE = (A.x * (B.y - E.y) + B.x * (E.y - A.y) + E.x * (A.y - B.y)) / 2.0;
        double ABN = (A.x * (B.y - N.y) + B.x * (N.y - A.y) + N.x * (A.y - B.y)) / 2.0;
        double ABW = (A.x * (B.y - W.y) + B.x * (W.y - A.y) + W.x * (A.y - B.y)) / 2.0;
        double ABS = (A.x * (B.y - S.y) + B.x * (S.y - A.y) + S.x * (A.y - B.y)) / 2.0;

        double maxX;
        double maxY;
        double minX;
        double minY;

        // Use a small epsilon for signed area comparison to avoid precision issues
        double eps = 1e-9;
        maxX = (ABM * ABE) > eps ? E.x : Math.max(A.x, B.x);
        maxY = (ABM * ABN) > eps ? N.y : Math.max(A.y, B.y);
        minX = (ABM * ABW) > eps ? W.x : Math.min(A.x, B.x);
        minY = (ABM * ABS) > eps ? S.y : Math.min(A.y, B.y);

        double d = Math.sqrt(Math.pow(start.x - end.x, 2) + Math.pow(start.y - end.y, 2)) / 2;
        double h = Math.sqrt(Math.max(0, r * r - d * d));

        if (end.y == start.y && end.y > C.y) {
            if (isShape131) {
                minX = C.x - r;
                maxX = minX + r * 2;
                maxY = end.y + h + r;
                minY = end.y;
            }
        }
        return new BoundingBox(new Point2D(minX, minY), new Point2D(maxX, maxY));
    }

    public static BoundingBox fromEdges(List<Edge> edges, boolean isShape31) { // TODO: Support cubic curves
        List<Point2D> points = new ArrayList<>();

        boolean isShape131 = isShape31;
        // if(edges.size()==2){
        // for(Edge e : edges) {
        // if(e.getEdgeType() == Edge.Type.Straight){
        // isShape131 = true;
        // break;
        // }
        // }
        // }
        for (Edge e : edges) {
            if (e.getEdgeType() == Edge.Type.Straight) {
                StraightEdge straightEdge = (StraightEdge) e;
                points.add(straightEdge.getStartPoint());
                points.add(straightEdge.getEndPoint());
            } else if (e.getEdgeType() == Edge.Type.Arc) {
                ArcEdge arcEdge = (ArcEdge) e;
                // if(!isLargeArc) isLargeArc = arcEdge.getIsLargeArc();
                BoundingBox boundingBox = BoundingBox.fromArc(
                        arcEdge.getStartPoint(),
                        arcEdge.getEndPoint(),
                        arcEdge.getRadius(),
                        isShape131,
                        arcEdge.getIsSweep(),
                        arcEdge.getIsLargeArc());

                points.add(boundingBox.getMinPoint());
                points.add(boundingBox.getMaxPoint());
            } else if (e.getEdgeType() == Edge.Type.CubicCurve) {
                throw new RuntimeException("CubicCurve[BBox] Not implemented yet");
            }
        }
        return fromPoints(points);
    }

    @Override
    public String toString() {
        return "BoundingBox{" +
                "minPoint=" + minPoint +
                ", maxPoint=" + maxPoint +
                '}';
    }
}
