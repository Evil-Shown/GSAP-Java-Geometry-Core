package com.core.cutout.impl;

import com.core.cutout.CutoutViewCreator;
import com.core.cutout.attachment.Attachment;
import com.core.cutout.attachment.EdgeAttachment;
import com.core.cutout.EdgeCutout;
import com.core.edge.ArcEdge;
import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.exception.InvalidAttachmentException;
import com.core.math.Point2D;
import com.core.math.Vector2D;
import com.core.shape.ParamList;
import com.core.svg.SVGBuilder;
import com.core.svg.SVGBuilder2;

import java.util.Arrays;
import java.util.List;
import com.core.math.Line;

public class Cutout_101 extends EdgeCutout {

    public Cutout_101(String cutoutNo, Attachment attachment) {
        super(101, cutoutNo, (EdgeAttachment) attachment);
    }

    //@Override
    public Point2D attach(int idx, List<Edge> edges, List<Edge> baseEdges, Point2D previousPoint) {
        ParamList p = new ParamList(params);
        double W = p.getParam("W").getValue();
        double H = p.getParam("H").getValue();
        double R = p.getParam("R").getValue();

        StraightEdge edge = getStraightEdge(baseEdges);
        double offset = attachment.getOffset();

        Vector2D edgeVec = Vector2D.create(edge.getStartPoint(), edge.getEndPoint());

        if (!attachment.isStartOffset()) {
            offset = edgeVec.length() - offset;
        }

        Vector2D v1 = edgeVec.normalized();
        v1.multiply(offset - (W / 2.0));

        Vector2D p1 = new Vector2D(edge.getStartPoint());
        p1.add(v1);

        Point2D startPoint = edge.getStartPoint();
        if (previousPoint != null) {
            edges.remove(edges.size() - 1);
            startPoint = previousPoint;
        }

        StraightEdge e1 = new StraightEdge(startPoint, new Point2D(p1));
        e1.setEdgeId(edge.getEdgeId() + "-" + idx + "-1");
        //edge.getChildren().add(e1);
        edges.add(e1);

        Vector2D v2 = edgeVec.normalized();
        v2.multiply(H - R);
        v2.rotate(Math.toRadians(90.0));

        Vector2D p2 = new Vector2D(e1.getEndPoint());
        p2.add(v2);

        StraightEdge e2 = new StraightEdge(e1.getEndPoint(), new Point2D(p2));
        e2.setEdgeId(edge.getEdgeId() + "-" + idx + "-2");
        //edge.getChildren().add(e2);
        edges.add(e2);

        Vector2D v3 = edgeVec.normalized();
        v3.multiply(R);
        Vector2D v4 = v3.rotated(Math.toRadians(90.0));
        v4.add(v3);

        Vector2D p3 = new Vector2D(e2.getEndPoint());
        p3.add(v4);

        ArcEdge e3 = new ArcEdge(R, true, true, e2.getEndPoint(), new Point2D(p3));
        e3.setEdgeId(edge.getEdgeId() + "-" + idx + "-3");
        //edge.getChildren().add(e3);
        edges.add(e3);

        Vector2D v5 = edgeVec.normalized();
        v5.multiply(W - 2*R);

        Vector2D p4 = new Vector2D(e3.getEndPoint());
        p4.add(v5);

        StraightEdge e4 = new StraightEdge(e3.getEndPoint(), new Point2D(p4));
        e4.setEdgeId(edge.getEdgeId() + "-" + idx + "-4");
        //edge.getChildren().add(e4);
        edges.add(e4);

        Vector2D v6 = edgeVec.normalized();
        v6.multiply(R);
        Vector2D v7 = v6.rotated(Math.toRadians(-90.0));
        v7.add(v6);

        Vector2D p5 = new Vector2D(e4.getEndPoint());
        p5.add(v7);

        ArcEdge e5 = new ArcEdge(R, true, true, e4.getEndPoint(), new Point2D(p5));
        e5.setEdgeId(edge.getEdgeId() + "-" + idx + "-5");
        //edge.getChildren().add(e5);
        edges.add(e5);

        Vector2D v8 = edgeVec.normalized();
        v8.multiply(offset + (W / 2));

        Vector2D p6 = new Vector2D(edge.getStartPoint());
        p6.add(v8);

        StraightEdge e6 = new StraightEdge(e5.getEndPoint(), new Point2D(p6));
        e6.setEdgeId(edge.getEdgeId() + "-" + idx + "-6");
        //edge.getChildren().add(e6);
        edges.add(e6);

        StraightEdge e7 = new StraightEdge(e6.getEndPoint(), edge.getEndPoint());
        e7.setEdgeId(edge.getEdgeId() + "-" + idx + "-7");
        //edge.getChildren().add(e7);
        edges.add(e7);

        calculateWaste();

        return e7.getStartPoint();
    }

    @Override
public CutoutAttachInfo attach(int idx, Edge currEdge, Edge nextEdge, List<Edge> edges,List<Edge> DxFedges, List<Line> DimLines, CutoutAttachInfo previousInfo, boolean dxf) {
        ParamList p = new ParamList(params);
        double W = p.getParam("W").getValue();
        double H = p.getParam("H").getValue();
        double R = p.getParam("R").getValue();
        double offset = attachment.getOffset();

        Vector2D edgeVec = Vector2D.create(currEdge.getStartPoint(), currEdge.getEndPoint());

        if (!attachment.isStartOffset()) {
            offset = edgeVec.length() - offset;
        }

        Vector2D v1 = edgeVec.normalized();
        if(attachment.isStartOffset())
         v1.multiply(offset);
        else
         v1.multiply(offset - W );

        Vector2D p1 = new Vector2D(currEdge.getStartPoint());
        p1.add(v1);

        Point2D startPoint = currEdge.getStartPoint();
        if (previousInfo != null) {
            edges.remove(edges.size() - 1);
            startPoint = previousInfo.lastPoint;
        }

        StraightEdge e1 = new StraightEdge(startPoint, new Point2D(p1));
        e1.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-1");
        e1.setOriginalEdgeId(currEdge.getOriginalEdgeId());
        //edge.getChildren().add(e1);
        edges.add(e1);
        DxFedges.add(e1);

        Vector2D v2 = edgeVec.normalized();
        v2.multiply(H - R);
        v2.rotate(Math.toRadians(90.0));

        Vector2D p2 = new Vector2D(e1.getEndPoint());
        p2.add(v2);

        StraightEdge e2 = new StraightEdge(e1.getEndPoint(), new Point2D(p2));
        e2.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-2");
        //edge.getChildren().add(e2);
        edges.add(e2);
        DxFedges.add(e2);

        Vector2D v3 = edgeVec.normalized();
        v3.multiply(R);
        Vector2D v4 = v3.rotated(Math.toRadians(90.0));
        v4.add(v3);

        Vector2D p3 = new Vector2D(e2.getEndPoint());
        p3.add(v4);


            ArcEdge e3 = new ArcEdge(R, true, true, e2.getEndPoint(), new Point2D(p3));
            e3.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-3");
            //edge.getChildren().add(e3);
        if(dxf) {
            edges.add(e3);
        }
        ArcEdge eDxF3 = new ArcEdge(R, true, true, new Point2D(p3), e2.getEndPoint());
        eDxF3.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-3");
        //edge.getChildren().add(e3);
        DxFedges.add(eDxF3);

        Vector2D v5 = edgeVec.normalized();
        v5.multiply(W - 2*R);

        Vector2D p4 = new Vector2D(e3.getEndPoint());
        p4.add(v5);

        StraightEdge e4 = new StraightEdge(e3.getEndPoint(), new Point2D(p4));
        e4.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-4");
        //edge.getChildren().add(e4);
        edges.add(e4);
        DxFedges.add(e4);

        Vector2D v6 = edgeVec.normalized();
        v6.multiply(R);
        Vector2D v7 = v6.rotated(Math.toRadians(-90.0));
        v7.add(v6);

        Vector2D p5 = new Vector2D(e4.getEndPoint());
        p5.add(v7);


            ArcEdge e5 = new ArcEdge(R, true, true, e4.getEndPoint(), new Point2D(p5));
            e5.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-5");
            //edge.getChildren().add(e5);
        if(dxf) {
            edges.add(e5);
        }
        ArcEdge eDxF5 = new ArcEdge(R, true, true, new Point2D(p5), e4.getEndPoint());
        eDxF5.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-5");
        DxFedges.add(eDxF5);

        Vector2D v8 = edgeVec.normalized();
        if(attachment.isStartOffset())
             v8.multiply(offset + (W ));
        else
            v8.multiply(offset);

        Vector2D p6 = new Vector2D(currEdge.getStartPoint());
        p6.add(v8);

        StraightEdge e6 = new StraightEdge(e5.getEndPoint(), new Point2D(p6));
        e6.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-6");
        //edge.getChildren().add(e6);
        edges.add(e6);
        DxFedges.add(e6);

        StraightEdge e7 = new StraightEdge(e6.getEndPoint(), currEdge.getEndPoint());
        e7.setEdgeId(currEdge.getEdgeId() + "-" + idx + "-7");
        e7.setOriginalEdgeId(currEdge.getOriginalEdgeId());
        //edge.getChildren().add(e7);
        edges.add(e7);
        DxFedges.add(e7);

        CutoutAttachInfo info = new CutoutAttachInfo();
        info.isOnNextEdge = false;
        info.lastPoint = e7.getStartPoint();

        calculateWaste();

        Point2D connerPoint = calculateConnerPoint(currEdge,attachment.isStartOffset());
        Point2D cutoutCenterPoint = calculateCutoutCenter(currEdge,attachment.isStartOffset());
        DimLines.add(new Line("E",cutoutCenterPoint, connerPoint ));

        return info;
    }

    private StraightEdge getStraightEdge(List<Edge> edges) {
        for (Edge edge : edges) {
            if (edge.getEdgeId().equalsIgnoreCase(attachment.getEdgeId())) {
                if (edge.getEdgeType() == Edge.Type.Straight) {
                    return (StraightEdge) edge;
                }
                throw new InvalidAttachmentException("Edge [" + attachment.getEdgeId() + "] is not a straight edge");
            }
        }
        throw new InvalidAttachmentException("Edge [" + attachment.getEdgeId() + "] is not found");
    }

    public static CutoutViewCreator createCutoutViewCreator() {
        return new CutoutViewCreator() {
            @Override
            public SVGBuilder2 getThumbnailBuilder() {
                return new SVGBuilder2(180, 180)
                    .pathBuilder()
                    .strokeOpacity("0.25")
                    .startPath(0, 160)
                    .lineTo(25, 160)
                    .endPath(false)
                    .pathBuilder()
                    //.startPath(0, 160)
                    .startPath(25, 160)
                    .lineTo(25, 50)
                    .arcTo(25, 25, 50, 25, true, true)
                    .lineTo(110, 25)
                    .arcTo(25, 25, 135, 50, true, true)
                    .lineTo(135, 160)
                    //.lineTo(160, 160)
                    .endPath(false)
                    .pathBuilder()
                    .strokeOpacity("0.25")
                    .startPath(135, 160)
                    .lineTo(160, 160)
                    .endPath(false);
            }

            @Override
            public SVGBuilder2 getPreviewBuilder() {
                return new SVGBuilder2(200, 200)
                        .pathBuilder()
                        .strokeOpacity("0.25")
                        .startPath(10, 160)
                        .lineTo(35, 160)
                        .endPath(false)
                        .pathBuilder()
                        //.startPath(0, 160)
                        .startPath(35, 160)
                        .lineTo(35, 50)
                        .arcTo(25, 25, 60, 25, true, true)
                        .lineTo(120, 25)
                        .arcTo(25, 25, 145, 50, true, true)
                        .lineTo(145, 160)
                        //.lineTo(160, 160)
                        .endPath(false)
                        .pathBuilder()
                        .strokeOpacity("0.25")
                        .startPath(145, 160)
                        .lineTo(170, 160)
                        .endPath(false)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(35, 50)
                        .lineToWithText(35, 25, "R")
                        .endPath(false)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(35, 170)
                        .lineToWithText(145, 170, "W")
                        .endPath(false)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(0, 160)
                        .lineToWithText(0, 25, "H")
                        .endPath(false);
            }

            @Override
            public Type getCutoutType() {
                return Type.Edge;
            }

            @Override
            public List<String> getParamNames() {
                return Arrays.asList("W", "H", "R");
            }

            @Override
            public List<String> getCutoutMappingParamNames() {
                return Arrays.asList("W", "H");
            }
        };
    }

    private void calculateWaste() {
        ParamList p = new ParamList(params);
        double W = p.getParam("W").getValue();
        double H = p.getParam("H").getValue();
        double R = p.getParam("R").getValue();
        double Ar = W * H;
        double Ac = (Math.PI * R * R / 2.0) * 3.0;
        waste = Ar + Ac;
    }

}
