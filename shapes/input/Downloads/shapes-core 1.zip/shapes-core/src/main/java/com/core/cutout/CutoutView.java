package com.core.cutout;

public class CutoutView {
    private int internalCutoutId;
    private String cutoutNo;
    private String thumbnailSVG;
    private String previewSVG;
    private String cutoutType;

    public CutoutView() {
    }

    public CutoutView(int internalCutoutId, String cutoutNo, String thumbnailSVG, String previewSVG, String cutoutType) {
        this.internalCutoutId = internalCutoutId;
        this.cutoutNo = cutoutNo;
        this.thumbnailSVG = thumbnailSVG;
        this.previewSVG = previewSVG;
        this.cutoutType = cutoutType;
    }

    public int getInternalCutoutId() {
        return internalCutoutId;
    }

    public void setInternalCutoutId(int internalCutoutId) {
        this.internalCutoutId = internalCutoutId;
    }

    public String getCutoutNo() {
        return cutoutNo;
    }

    public void setCutoutNo(String cutoutNo) {
        this.cutoutNo = cutoutNo;
    }

    public String getThumbnailSVG() {
        return thumbnailSVG;
    }

    public void setThumbnailSVG(String thumbnailSVG) {
        this.thumbnailSVG = thumbnailSVG;
    }

    public String getPreviewSVG() {
        return previewSVG;
    }

    public void setPreviewSVG(String previewSVG) {
        this.previewSVG = previewSVG;
    }

    public String getCutoutType() {
        return cutoutType;
    }

    public void setCutoutType(String cutoutType) {
        this.cutoutType = cutoutType;
    }
}
