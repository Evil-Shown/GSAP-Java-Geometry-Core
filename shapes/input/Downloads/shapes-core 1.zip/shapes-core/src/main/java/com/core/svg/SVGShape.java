package com.core.svg;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SVGShape {
    private double width;
    private double height;
    private List<SVGPath> shapePaths = new ArrayList<>();
    private List<SVGPath> controlPaths = new ArrayList<>();
    private List<SVGPath> dimLines = new ArrayList<>();
    private List<SVGPath> trimLines = new ArrayList<>();
    private Map<Long, SVGPath> interiorCutoutPaths = new HashMap<>();
    private List<SVGPath> CutoutDimLines = new ArrayList<>();

    public SVGShape() {
    }

    public SVGShape(double width, double height,
                    List<SVGPath> shapePaths,
                    List<SVGPath> controlPaths,
                    List<SVGPath> dimLines,
                    List<SVGPath> trimLines,
                    Map<Long, SVGPath> interiorCutoutPaths,
                    List<SVGPath> CutoutDimLines) {
        this.width = width;
        this.height = height;
        this.shapePaths = shapePaths;
        this.controlPaths = controlPaths;
        this.dimLines = dimLines;
        this.trimLines = trimLines;
        this.interiorCutoutPaths = interiorCutoutPaths;
        this.CutoutDimLines = CutoutDimLines;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public SVGPath getShapePath0() {
        return shapePaths.get(0);
    }

    public List<SVGPath> getShapePaths() {
        return shapePaths;
    }

    public void setShapePath(SVGPath shapePath) {
        this.shapePaths.add(shapePath);
    }

    public List<SVGPath> getControlPaths() {
        return controlPaths;
    }

    public void setControlPaths(List<SVGPath> controlPaths) {
        this.controlPaths = controlPaths;
    }

    public List<SVGPath> getTrimLines() {
        return trimLines;
    }

    public void setTrimLines(List<SVGPath> trimLines) {
        this.trimLines = trimLines;
    }

    public List<SVGPath> getDimLines() {
        return dimLines;
    }



    public List<SVGPath> getCutoutDimLines() {
        return CutoutDimLines;
    }

    public void setCutoutDimLines(List<SVGPath> CutoutDimLines) {
        this.CutoutDimLines = CutoutDimLines;
    }

    public Map<Long, SVGPath> getInteriorCutoutPaths() {
        return interiorCutoutPaths;
    }

    public void setInteriorCutoutPaths(Map<Long, SVGPath> interiorCutoutPaths) {
        this.interiorCutoutPaths = interiorCutoutPaths;
    }
}
