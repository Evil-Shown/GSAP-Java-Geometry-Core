package com.core.shape.transformer.impl;

import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.edge.builder.EdgeBuilder;
import com.core.math.Point2D;
import com.core.shape.Param;
import com.core.shape.ParamList;
import com.core.shape.ShapeConstants;
import com.core.shape.transformer.ShapeTransformer;
import com.core.utility.EdgeDimCutTuple;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ShapeTransformer_136 extends ShapeTransformer {
    @Override
    public List<Edge> resize(List<Param> params, Map<String, Double> services) {
        ParamList p = new ParamList(params);
        double H = p.getParam("H").getValue();
        double W = p.getParam("W").getValue();


        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E2")) {
            trimLeft += services.get("E2");
        }

        Point2D p0 = new Point2D(trimLeft, trimBottom);
        Point2D p1 = new Point2D(p0.x + W, p0.y);
        double R = H/2+(W*W)/(8*H);

        calculateArea(params);
        return new EdgeBuilder()
                .startPoint(p0)
                .straightEdge(p1)
                .arcEdge(R, false, false, p0)
                .build();
    }

    @Override
    public EdgeDimCutTuple resize2(List<Param> params, Map<String, Double> services, Map<String, Double> coatingRemovals) {
        ParamList p = new ParamList(params);
        double H = p.getParam("H").getValue();
        double W = p.getParam("W").getValue();

        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E2")) {
            trimLeft += services.get("E2");
        }

        Point2D p0 = new Point2D(trimLeft, trimBottom);
        Point2D p1 = new Point2D(p0.x + W, p0.y);
        double R = H/2+(W*W)/(8*H);

        System.out.println(p0+"  =p0 p1="+p1+" without servise");
        List<Edge> edges = new EdgeBuilder()
                .startPoint(p0)
                .straightEdge(p1)
                .arcEdge(R, false, false, p0)
                .build();

        List<Edge> dimLines = new ArrayList<>();
        dimLines.add(new StraightEdge(p0, p1, ShapeConstants.W));
        dimLines.add(new StraightEdge(new Point2D(p1.x,p0.y),new Point2D(p1.x,p0.y+H), ShapeConstants.H));


        calculateCircumference(edges);
        calculateArea(params);

        double sT = services.getOrDefault("E2", 0.0);
        double sB = services.getOrDefault("E1", 0.0);


        Point2D center = new Point2D((p0.x+p1.x)/2,p0.y+H-R);
        double det = Math.sqrt((R+sT)*(R+sT)-(p0.y-sB-center.y)*(p0.y-sB-center.y));
        Point2D cP0 = new Point2D(center.x-det, p0.y-sB);
        Point2D cP1 = new Point2D(center.x+det, cP0.y);
        System.out.println(cP0+"  =cP0 cP1="+cP1+" with servise");


        List<Edge> cEdges = new EdgeBuilder()
                .startPoint(cP0)
                .straightEdge(cP1)
                .arcEdge(R+sT, false, false, cP0)
                .build();



        double t = coatingRemovals.getOrDefault("E2", 0.0);
        double r = coatingRemovals.getOrDefault("E1", 0.0);
        double a = W/2;
        double b = H-R;
        double det2 = Math.sqrt((R-t)*(R-t)-(r-b)*(r-b));
        Point2D crP0 = new Point2D(trimLeft, trimBottom);
        Point2D crP1 = new Point2D(crP0.x + a - det2, crP0.y+r);
        Point2D crP2 = new Point2D(crP0.x + a + det2, crP0.y+r);

        List<Edge> crEdges = new EdgeBuilder()
                .startPoint(crP1)
                .straightEdge(crP2)
                .arcEdge(R-t, false, false, crP1)
                .build();

        return new EdgeDimCutTuple(edges, dimLines, cEdges, crEdges);
    }

    private void calculateArea(List<Param> params) {

        ParamList p = new ParamList(params);
        double W = p.getParam(ShapeConstants.W).getValue();
        double H = p.getParam(ShapeConstants.H).getValue();
        double R = W/2;
        double thita = Math.atan((W/2)/(R-H))*2;

        this.area =R*R*thita-0.5*W*(R-H);

    }


}
