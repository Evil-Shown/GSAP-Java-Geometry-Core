package com.core.shape;

import com.core.exception.ParamNotFoundException;

import java.util.List;

public class ParamList {

    private List<Param> params;

    public ParamList(List<Param> params) {
        this.params = params;
    }

    public Param getParam(String name) {
        for (Param param : params) {
            if (param.getName().equalsIgnoreCase(name)) {
                return param;
            }
        }
        throw new ParamNotFoundException(name);
    }

    public double getParamValueOrDefault(String name, double defaultValue) {
        for (Param param : params) {
            if (param.getName().equalsIgnoreCase(name)) {
                return param.getValue();
            }
        }
        return defaultValue;
    }
}
