package com.core.cutout.impl;

import com.core.cutout.CornerCutout;
import com.core.cutout.CutoutViewCreator;
import com.core.cutout.attachment.Attachment;
import com.core.cutout.attachment.CornerAttachment;
import com.core.edge.ArcEdge;
import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.exception.InvalidAttachmentException;
import com.core.svg.SVGBuilder2;
import com.core.utility.GeometryHelper;
import com.core.math.Point2D;
import com.core.math.Vector2D;
import com.core.shape.ParamList;
import com.core.svg.SVGBuilder;

import java.util.*;
import com.core.math.Line;

public class Cutout_102 extends CornerCutout {

    public Cutout_102(String cutoutNo, Attachment attachment) {
        super(102, cutoutNo, (CornerAttachment) attachment);
    }

    //@Override
    public Point2D attach(int idx, List<Edge> edges, List<Edge> baseEdges, Point2D previousPoint) {
        List<Edge> cutoutEdges = new ArrayList<>();
        ParamList p = new ParamList(params);
        double R = p.getParam("R").getValue();

        Map<String, StraightEdge> cornerEdges = getCornerEdges(baseEdges);
        StraightEdge curr = cornerEdges.get("current");
        StraightEdge next = cornerEdges.get("next");

        Vector2D currVec = Vector2D.create(curr.getEndPoint(), curr.getStartPoint());
        Vector2D nextVec = Vector2D.create(next.getStartPoint(), next.getEndPoint());
        double dist = 0.0;

        Point2D cornerPoint = curr.getEndPoint();

        if (nextVec.length() < currVec.length()) {
            Vector2D currentVecPoint = currVec.normalized().multiplied(nextVec.length());
            currentVecPoint.add(new Vector2D(curr.getEndPoint()));
            dist = GeometryHelper.findCornerToArcDistance(cornerPoint, next.getEndPoint(), new Point2D(currentVecPoint), R);
        } else {
            Vector2D nextVecPoint = nextVec.normalized().multiplied(currVec.length());
            nextVecPoint.add(new Vector2D(next.getStartPoint()));
            dist = GeometryHelper.findCornerToArcDistance(cornerPoint, new Point2D(nextVecPoint), curr.getStartPoint(), R);
        }

        // TODO: IMPORTANT!!!
        // Child edge concept doesn't work with corner and interior cutouts.
        // We need to create completely new edge list. Need to think about
        // cases that can be problematic. For interior cutouts, edge list
        // doesn't get changed at all.

        Vector2D currDir = Vector2D.create(curr.getEndPoint(), curr.getStartPoint());
        currDir.normalize();
        currDir.multiply(dist);
        Point2D p1 = new Point2D(curr.getEndPoint().x + currDir.x, curr.getEndPoint().y + currDir.y);

        Vector2D nextDir = Vector2D.create(next.getStartPoint(), next.getEndPoint());
        nextDir.normalize();
        nextDir.multiply(dist);
        Point2D p2 = new Point2D(next.getStartPoint().x + nextDir.x, next.getStartPoint().y + nextDir.y);

        Point2D startPoint = curr.getStartPoint();
        if (previousPoint != null) {
            edges.remove(edges.size() - 1);
            startPoint = previousPoint;
        }

        StraightEdge se1 = new StraightEdge();
        se1.setEdgeId(curr.getEdgeId());
        se1.setStartPoint(startPoint);
        se1.setEndPoint(p1);
        cutoutEdges.add(se1);

        ArcEdge ae = new ArcEdge();
        ae.setEdgeId("ARC-" + idx);
        ae.setRadius(R);
        ae.setStartPoint(p1);
        ae.setEndPoint(p2);
        ae.setLargeArc(false);
        ae.setSweep(false);
        cutoutEdges.add(ae);

        StraightEdge se2 = new StraightEdge();
        se1.setEdgeId(next.getEdgeId());
        se2.setStartPoint(p2);
        se2.setEndPoint(next.getEndPoint());
        cutoutEdges.add(se2);

        edges.addAll(cutoutEdges);

        calculateWaste();

        return p2;
    }

    @Override
public CutoutAttachInfo attach(int idx, Edge currEdge, Edge nextEdge, List<Edge> edges,List<Edge> DxFedges, List<Line> DimLines, CutoutAttachInfo previousInfo, boolean dxf) {
        ParamList p = new ParamList(params);
        double R = p.getParam("R").getValue();

        Vector2D currVec = Vector2D.create(currEdge.getEndPoint(), currEdge.getStartPoint());
        Vector2D nextVec = Vector2D.create(nextEdge.getStartPoint(), nextEdge.getEndPoint());
        double dist = 0.0;

        Point2D cornerPoint = currEdge.getEndPoint();
        if (nextVec.length() < currVec.length()) {
            Vector2D currentVecPoint = currVec.normalized().multiplied(nextVec.length());
            currentVecPoint.add(new Vector2D(currEdge.getEndPoint()));
            dist = GeometryHelper.findCornerToArcDistance(cornerPoint, nextEdge.getEndPoint(), new Point2D(currentVecPoint), R);
        } else {
            Vector2D nextVecPoint = nextVec.normalized().multiplied(currVec.length());
            nextVecPoint.add(new Vector2D(nextEdge.getStartPoint()));
            dist = GeometryHelper.findCornerToArcDistance(cornerPoint, new Point2D(nextVecPoint), currEdge.getStartPoint(), R);
        }

        Vector2D currDir = Vector2D.create(currEdge.getEndPoint(), currEdge.getStartPoint());
        currDir.normalize();
        currDir.multiply(dist);
        Point2D p1 = new Point2D(currEdge.getEndPoint().x + currDir.x, currEdge.getEndPoint().y + currDir.y);

        Vector2D nextDir = Vector2D.create(nextEdge.getStartPoint(), nextEdge.getEndPoint());
        nextDir.normalize();
        nextDir.multiply(dist);
        Point2D p2 = new Point2D(nextEdge.getStartPoint().x + nextDir.x, nextEdge.getStartPoint().y + nextDir.y);

        Point2D startPoint = currEdge.getStartPoint();
        if (previousInfo != null) {
            edges.remove(edges.size() - 1);
            startPoint = previousInfo.lastPoint;
        }

        StraightEdge se1 = new StraightEdge();
        se1.setEdgeId(currEdge.getEdgeId());
        se1.setStartPoint(startPoint);
        se1.setEndPoint(p1);
        edges.add(se1);

        ArcEdge ae = new ArcEdge();
        ae.setEdgeId("ARC-" + idx);
        ae.setRadius(R);
        ae.setStartPoint(p1);
        ae.setEndPoint(p2);
        ae.setLargeArc(false);
        ae.setSweep(false);
        if(dxf) {
            edges.add(ae);
        }
        StraightEdge se2 = new StraightEdge();
        se1.setEdgeId(nextEdge.getEdgeId());
        se2.setStartPoint(p2);
        se2.setEndPoint(nextEdge.getEndPoint());
        edges.add(se2);

        CutoutAttachInfo info = new CutoutAttachInfo();
        info.isOnNextEdge = true;
        info.lastPoint = se2.getStartPoint();

        calculateWaste();

        return info;
    }

    private Map<String, StraightEdge> getCornerEdges(List<Edge> edges) {
        Map<String, StraightEdge> attachedEdges = new HashMap<>();
        int nextIdx = -1;
        for (int i = 0; i < edges.size(); i++) {
            Edge edge = edges.get(i);
            if (edge.getEdgeId().equalsIgnoreCase(attachment.getEdgeId())) {
                if (edge.getEdgeType() == Edge.Type.Straight) {
                    attachedEdges.put("current", (StraightEdge) edge);
                    nextIdx = (i == (edges.size() - 1)) ? 0 : i + 1;
                    break;
                } else {
                    throw new InvalidAttachmentException("Attached edge [" +
                        attachment.getEdgeId() + " is not a straight edge");
                }
            }
        }
        if (nextIdx == -1) {
            throw new InvalidAttachmentException("Attached edge [" + attachment.getEdgeId() + "] not found");
        }
        Edge edge = edges.get(nextIdx);
        if (edge.getEdgeType() == Edge.Type.Straight) {
            attachedEdges.put("next", (StraightEdge) edge);
        } else {
            throw new InvalidAttachmentException("Next edge " + edge.getEdgeId() + " is not a straight edge");
        }
        return attachedEdges;
    }

    public static CutoutViewCreator createCutoutViewCreator() {
        return new CutoutViewCreator() {
            @Override
            public SVGBuilder2 getThumbnailBuilder() {
                return new SVGBuilder2(180, 180)
                    .pathBuilder()
                    .strokeOpacity("0.25")
                    .startPath(0, 0)
                    .lineTo(0, 50)
                    .endPath(false)
                    .pathBuilder()
                    //.startPath(0, 0)
                    .startPath(0, 50)
                    .arcTo(110, 110, 110, 160, false, false)
                    //.lineTo(160, 160)
                    .endPath(false)
                    .pathBuilder()
                    .strokeOpacity("0.25")
                    .startPath(110, 160)
                    .lineTo(160, 160)
                    .endPath(false);
            }

            @Override
            public SVGBuilder2 getPreviewBuilder() {
                return new SVGBuilder2(200, 200)
                        .pathBuilder()
                        .strokeOpacity("0.25")
                        .startPath(10, 0)
                        .lineTo(10, 50)
                        .endPath(false)
                        .pathBuilder()
                        //.startPath(0, 0)
                        .startPath(10, 50)
                        .arcTo(110, 110, 120, 160, false, false)
                        //.lineTo(160, 160)
                        .endPath(false)
                        .pathBuilder()
                        .strokeOpacity("0.25")
                        .startPath(120, 160)
                        .lineTo(170, 160)
                        .endPath(false)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(10, 10)
                        .lineToWithText(120, 10, "R")
                        .endPath(false);
            }

            @Override
            public Type getCutoutType() {
                return Type.Corner;
            }

            @Override
            public List<String> getParamNames() {
                return Arrays.asList("R");
            }

            @Override
            public List<String> getCutoutMappingParamNames() {
                return Arrays.asList("R");
            }
        };
    }

    private void calculateWaste() {
        ParamList p = new ParamList(params);
        double R = p.getParam("R").getValue();
        waste = R * R - ((Math.PI * R * R) / 4.0);
    }

}
