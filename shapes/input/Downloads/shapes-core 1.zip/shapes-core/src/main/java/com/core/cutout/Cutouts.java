package com.core.cutout;

import com.core.cutout.attachment.CornerAttachment;
import com.core.cutout.attachment.EdgeAttachment;
import com.core.cutout.attachment.InteriorAttachment;
import com.core.cutout.impl.*;

import java.util.HashMap;
import java.util.Map;

public class Cutouts {

    @FunctionalInterface
    private interface CutoutCreator<T> {
        AbstractCutout create(String cutoutNo, T attachment);
    }

    private static final Map<Integer, CutoutCreator<EdgeAttachment>> edgeCutouts = new HashMap<>();
    private static final Map<Integer, CutoutCreator<CornerAttachment>> cornerCutouts = new HashMap<>();
    private static final Map<Integer, CutoutCreator<InteriorAttachment>> interiorCutouts = new HashMap<>();
    private static final Map<Integer, String> cutoutIdToNumberMap = new HashMap<>();

    public static AbstractCutout create(int internalId, String cutoutNo, EdgeAttachment attachment) {
        return edgeCutouts.get(internalId).create(cutoutNo, attachment);
    }

    public static AbstractCutout create(int internalId, String cutoutNo, CornerAttachment attachment) {
        return cornerCutouts.get(internalId).create(cutoutNo, attachment);
    }

    public static AbstractCutout create(int internalId, String cutoutNo, InteriorAttachment attachment) {
        return interiorCutouts.get(internalId).create(cutoutNo, attachment);
    }

    public static void initialize(Map<Integer, CutoutViewCreator> cutoutViewCreatorMap) {
        edgeCutouts.put(100, Cutout_100::new);
        edgeCutouts.put(101, Cutout_101::new);
        edgeCutouts.put(103, Cutout_103::new);
        edgeCutouts.put(104, Cutout_104::new);
        cornerCutouts.put(102, Cutout_102::new);
        cornerCutouts.put(105, Cutout_105::new);
        cornerCutouts.put(106, Cutout_106::new);
        interiorCutouts.put(107, Cutout_107::new);
        interiorCutouts.put(108, Cutout_108::new);
        interiorCutouts.put(109, Cutout_109::new);
        interiorCutouts.put(110, Cutout_110::new);
        cornerCutouts.put(111, Cutout_111::new);

        cutoutViewCreatorMap.put(100, Cutout_100.createCutoutViewCreator());
        cutoutViewCreatorMap.put(101, Cutout_101.createCutoutViewCreator());
        cutoutViewCreatorMap.put(102, Cutout_102.createCutoutViewCreator());
        cutoutViewCreatorMap.put(103, Cutout_103.createCutoutViewCreator());
        cutoutViewCreatorMap.put(104, Cutout_104.createCutoutViewCreator());
        cutoutViewCreatorMap.put(105, Cutout_105.createCutoutViewCreator());
        cutoutViewCreatorMap.put(106, Cutout_106.createCutoutViewCreator());
        cutoutViewCreatorMap.put(107, Cutout_107.createCutoutViewCreator());
        cutoutViewCreatorMap.put(108, Cutout_108.createCutoutViewCreator());
        cutoutViewCreatorMap.put(109, Cutout_109.createCutoutViewCreator());
        cutoutViewCreatorMap.put(110, Cutout_110.createCutoutViewCreator());
        cutoutViewCreatorMap.put(111, Cutout_111.createCutoutViewCreator());

        cutoutIdToNumberMap.put(100, "100");
        cutoutIdToNumberMap.put(101, "101");
        cutoutIdToNumberMap.put(102, "102");
        cutoutIdToNumberMap.put(103, "103");
        cutoutIdToNumberMap.put(104, "104");
        cutoutIdToNumberMap.put(105, "105");
        cutoutIdToNumberMap.put(106, "106");
        cutoutIdToNumberMap.put(107, "107");
        cutoutIdToNumberMap.put(108, "108");
        cutoutIdToNumberMap.put(109, "109");
        cutoutIdToNumberMap.put(110, "110");
        cutoutIdToNumberMap.put(111, "111");
    }

    public static int getInternalCutoutId(String cutoutNo) {
        for (Map.Entry<Integer, String> entry : cutoutIdToNumberMap.entrySet()) {
            if (entry.getValue().equalsIgnoreCase(cutoutNo)) {
                return entry.getKey();
            }
        }
        throw new RuntimeException("Cutout not found, cutoutNo: " + cutoutNo);
    }

    public static String getCutoutNo(int internalId) {
        for (Map.Entry<Integer, String> entry : cutoutIdToNumberMap.entrySet()) {
            if (entry.getKey() == internalId) {
                return entry.getValue();
            }
        }
        throw new RuntimeException("Cutout not found, internalId: " + internalId);
    }

    public static boolean isEdgeCutout(Cutout cutout) {
        return cutout.getCutoutType() == Cutout.Type.Edge;
    }

    public static boolean isCornerCutout(Cutout cutout) {
        return cutout.getCutoutType() == Cutout.Type.Corner;
    }

    public static boolean isInteriorCutout(Cutout cutout) {
        return cutout.getCutoutType() == Cutout.Type.Interior;
    }

}
