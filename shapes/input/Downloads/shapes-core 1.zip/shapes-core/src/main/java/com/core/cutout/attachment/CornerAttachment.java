package com.core.cutout.attachment;

import com.core.cutout.Cutout;

public class CornerAttachment implements Attachment {

    private String edgeId;

    public String getEdgeId() {
        return edgeId;
    }

    public void setEdgeId(String edgeId) {
        this.edgeId = edgeId;
    }

    @Override
    public Cutout.Type getAttachmentType() {
        return Cutout.Type.Corner;
    }

    public static class Builder {
        private CornerAttachment attachment = new CornerAttachment();

        private Builder() {}

        public Builder setEdgeId(String edgeId) {
            this.attachment.setEdgeId(edgeId);
            return this;
        }

        public CornerAttachment build() {
            return attachment;
        }
    }

    public static Builder newBuilder() {
        return new Builder();
    }
}
