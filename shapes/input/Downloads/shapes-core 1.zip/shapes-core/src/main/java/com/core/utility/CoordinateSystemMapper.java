package com.core.utility;

import com.core.edge.ArcEdge;
import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.math.Line;
import com.core.math.Point2D;
import com.core.shape.TrimLine;

import java.util.List;
import java.util.Map;

public class CoordinateSystemMapper {

    public List<Edge> mapToSVG(List<Edge> edges, Map<Long, List<Edge>> interiorCutoutEdges, List<TrimLine> trimLines, List<Line> dimLines, double height) {
        for (TrimLine trimLine: trimLines) {
            Point2D sp = trimLine.getStartPoint();
            Point2D ep = trimLine.getEndPoint();

            trimLine.setStartPoint(new Point2D(sp.x, Math.abs(sp.y - height)));
            trimLine.setEndPoint(new Point2D(ep.x, Math.abs(ep.y - height)));
        }
        for (Line dimLine: dimLines) {
            Point2D sp = dimLine.getFrom();
            Point2D ep = dimLine.getTo();

            dimLine.setFrom(new Point2D(sp.x, Math.abs(sp.y - height)));
            dimLine.setTo(new Point2D(ep.x, Math.abs(ep.y - height)));
        }

        for (Map.Entry<Long, List<Edge>> entry : interiorCutoutEdges.entrySet()) {
            List<Edge> cutoutLines = entry.getValue();
            for (Edge edge : cutoutLines) {
                if (edge.getEdgeType() == Edge.Type.Straight) {
                    StraightEdge straightEdge = (StraightEdge) edge;

                    Point2D sp = straightEdge.getStartPoint();
                    Point2D ep = straightEdge.getEndPoint();

                    straightEdge.setStartPoint(new Point2D(sp.x, Math.abs(sp.y - height)));
                    straightEdge.setEndPoint(new Point2D(ep.x, Math.abs(ep.y - height)));

                    for (Edge child : edge.getChildren()) {
                        if (child.getEdgeType() == Edge.Type.Straight) {
                            StraightEdge childEdge = (StraightEdge) child;

                            sp = childEdge.getStartPoint();
                            ep = childEdge.getEndPoint();

                            childEdge.setStartPoint(new Point2D(sp.x, Math.abs(sp.y - height)));
                            childEdge.setEndPoint(new Point2D(ep.x, Math.abs(ep.y - height)));
                        } else if (child.getEdgeType() == Edge.Type.Arc) {
                            ArcEdge childEdge = (ArcEdge) child;
                            sp = childEdge.getStartPoint();
                            ep = childEdge.getEndPoint();

                            childEdge.setStartPoint(new Point2D(sp.x, Math.abs(sp.y - height)));
                            childEdge.setEndPoint(new Point2D(ep.x, Math.abs(ep.y - height)));
                        }
                    }
                } else if (edge.getEdgeType() == Edge.Type.Arc) {
                    ArcEdge arcEdge = (ArcEdge) edge;
                    Point2D sp = arcEdge.getStartPoint();
                    Point2D ep = arcEdge.getEndPoint();

                    arcEdge.setStartPoint(new Point2D(sp.x, Math.abs(sp.y - height)));
                    arcEdge.setEndPoint(new Point2D(ep.x, Math.abs(ep.y - height)));
                } else if (edge.getEdgeType() == Edge.Type.CubicCurve) {
                    throw new RuntimeException("CUBIC_CURVE not supported yet");
                }
            }
        }

        for (Edge edge : edges) {
            if (edge.getEdgeType() == Edge.Type.Straight) {
                StraightEdge straightEdge = (StraightEdge) edge;

                Point2D sp = straightEdge.getStartPoint();
                Point2D ep = straightEdge.getEndPoint();

                straightEdge.setStartPoint(new Point2D(sp.x, Math.abs(sp.y - height)));
                straightEdge.setEndPoint(new Point2D(ep.x, Math.abs(ep.y - height)));

                for (Edge child : edge.getChildren()) {
                    if (child.getEdgeType() == Edge.Type.Straight) {
                        StraightEdge childEdge = (StraightEdge) child;

                        sp = childEdge.getStartPoint();
                        ep = childEdge.getEndPoint();

                        childEdge.setStartPoint(new Point2D(sp.x, Math.abs(sp.y - height)));
                        childEdge.setEndPoint(new Point2D(ep.x, Math.abs(ep.y - height)));
                    } else if (child.getEdgeType() == Edge.Type.Arc) {
                        ArcEdge childEdge = (ArcEdge) child;
                        sp = childEdge.getStartPoint();
                        ep = childEdge.getEndPoint();

                        childEdge.setStartPoint(new Point2D(sp.x, Math.abs(sp.y - height)));
                        childEdge.setEndPoint(new Point2D(ep.x, Math.abs(ep.y - height)));
                    }
                }
            } else if (edge.getEdgeType() == Edge.Type.Arc) {
                ArcEdge arcEdge = (ArcEdge) edge;
                Point2D sp = arcEdge.getStartPoint();
                Point2D ep = arcEdge.getEndPoint();

                arcEdge.setStartPoint(new Point2D(sp.x, Math.abs(sp.y - height)));
                arcEdge.setEndPoint(new Point2D(ep.x, Math.abs(ep.y - height)));
            } else if (edge.getEdgeType() == Edge.Type.CubicCurve) {
                throw new RuntimeException("CUBIC_CURVE not supported yet");
            }
        }
        return edges;
    }

    public void setOrigin(List<Edge> edges,boolean isShape31) {
        setOrigin(edges, false, null,isShape31);
    }

    public void setOrigin(List<Edge> edges, boolean useCustomOrigin, Point2D customOrigin, boolean isShape31) {
        Point2D origin;
        Point2D origin2;

        if (useCustomOrigin && customOrigin != null) {
            BoundingBox boundingBox = BoundingBox.fromEdges(edges,isShape31);
            origin2 = boundingBox.getOrigin();
            Point2D customOrigin2 = new Point2D(origin2.x-customOrigin.x,origin2.y-customOrigin.y);
            origin = customOrigin2;
        } else {
            BoundingBox boundingBox = BoundingBox.fromEdges(edges,isShape31);
            origin = boundingBox.getOrigin();

            if (origin.isSame(new Point2D(0.0D, 0.0D))) {
                System.out.println("Returning as origin is 0,0");
                return;
            }
        }

        edges.forEach(edge -> translateEdge(edge, origin));
    }

    private void translateEdge(Edge edge, Point2D origin) {
        if (edge.getEdgeType() == Edge.Type.Straight) {
            translateStraightEdge((StraightEdge) edge, origin);
        } else if (edge.getEdgeType() == Edge.Type.Arc) {
            translateArcEdge((ArcEdge) edge, origin);
        } else if (edge.getEdgeType() == Edge.Type.CubicCurve) {
            throw new RuntimeException("CUBIC_CURVE not supported yet");
        }

        // Translate children
        edge.getChildren().forEach(child -> translateEdge(child, origin));
    }

    private void translateStraightEdge(StraightEdge edge, Point2D origin) {
        edge.setStartPoint(translatePoint(edge.getStartPoint(), origin));
        edge.setEndPoint(translatePoint(edge.getEndPoint(), origin));
    }

    private void translateArcEdge(ArcEdge edge, Point2D origin) {
        edge.setStartPoint(translatePoint(edge.getStartPoint(), origin));
        edge.setEndPoint(translatePoint(edge.getEndPoint(), origin));
        // If ArcEdge has a center point, translate it too:
        // edge.setCenterPoint(translatePoint(edge.getCenterPoint(), origin));
    }

    private Point2D translatePoint(Point2D point, Point2D origin) {
        return new Point2D(point.x - origin.x, point.y - origin.y);
    }
    public void setOrigin(List<Edge> edges, Map<Long, List<Edge>> interiorCutoutEdges, List<TrimLine> trimLines, List<Line> dimLines) {
        BoundingBox bbCutSize = BoundingBox.fromPoints(trimLines.stream().map(TrimLine::getStartPoint).toList());
        Point2D origin = bbCutSize.getOrigin();

        if (origin.isSame(new Point2D(0.0, 0.0))) {
            System.out.println("Returning as origin is 0,0");
            return;
        }

        for (TrimLine trimLine: trimLines) {
            Point2D sp = trimLine.getStartPoint();
            Point2D ep = trimLine.getEndPoint();

            trimLine.setStartPoint(new Point2D(sp.x - origin.x, sp.y - origin.y));
            trimLine.setEndPoint(new Point2D(ep.x - origin.x, ep.y - origin.y));
        }

        for (Line line : dimLines) {
            Point2D sp = line.getFrom();
            Point2D ep = line.getTo();

            line.setFrom(new Point2D(sp.x - origin.x, sp.y - origin.y));
            line.setTo(new Point2D(ep.x - origin.x, ep.y - origin.y));
        }

        for (Map.Entry<Long, List<Edge>> entry : interiorCutoutEdges.entrySet()) {
            List<Edge> cutoutLines = entry.getValue();
            for (Edge edge : cutoutLines) {
                if (edge.getEdgeType() == Edge.Type.Straight) {
                    StraightEdge straightEdge = (StraightEdge) edge;
                    Point2D sp = straightEdge.getStartPoint();
                    Point2D ep = straightEdge.getEndPoint();

                    straightEdge.setStartPoint(new Point2D(sp.x - origin.x, sp.y - origin.y));
                    straightEdge.setEndPoint(new Point2D(ep.x - origin.x, ep.y - origin.y));

                    for (Edge child : edge.getChildren()) {
                        if (child.getEdgeType() == Edge.Type.Straight) {
                            StraightEdge childEdge = (StraightEdge) child;
                            sp = childEdge.getStartPoint();
                            ep = childEdge.getEndPoint();

                            childEdge.setStartPoint(new Point2D(sp.x - origin.x, sp.y - origin.y));
                            childEdge.setEndPoint(new Point2D(ep.x - origin.x, ep.y - origin.y));
                        } else if (child.getEdgeType() == Edge.Type.Arc) {
                            ArcEdge childEdge = (ArcEdge) child;
                            sp = childEdge.getStartPoint();
                            ep = childEdge.getEndPoint();

                            childEdge.setStartPoint(new Point2D(sp.x - origin.x, sp.y - origin.y));
                            childEdge.setEndPoint(new Point2D(ep.x - origin.x, ep.y - origin.y));
                        }
                    }
                } else if (edge.getEdgeType() == Edge.Type.Arc) {
                    ArcEdge arcEdge = (ArcEdge) edge;
                    Point2D sp = arcEdge.getStartPoint();
                    Point2D ep = arcEdge.getEndPoint();

                    arcEdge.setStartPoint(new Point2D(sp.x - origin.x, sp.y - origin.y));
                    arcEdge.setEndPoint(new Point2D(ep.x - origin.x, ep.y - origin.y));
                } else if (edge.getEdgeType() == Edge.Type.CubicCurve) {
                    throw new RuntimeException("CUBIC_CURVE not supported yet");
                }
            }
        }

        for (Edge edge : edges) {
            if (edge.getEdgeType() == Edge.Type.Straight) {
                StraightEdge straightEdge = (StraightEdge) edge;
                Point2D sp = straightEdge.getStartPoint();
                Point2D ep = straightEdge.getEndPoint();

                straightEdge.setStartPoint(new Point2D(sp.x - origin.x, sp.y - origin.y));
                straightEdge.setEndPoint(new Point2D(ep.x - origin.x, ep.y - origin.y));

                for (Edge child : edge.getChildren()) {
                    if (child.getEdgeType() == Edge.Type.Straight) {
                        StraightEdge childEdge = (StraightEdge) child;
                        sp = childEdge.getStartPoint();
                        ep = childEdge.getEndPoint();

                        childEdge.setStartPoint(new Point2D(sp.x - origin.x, sp.y - origin.y));
                        childEdge.setEndPoint(new Point2D(ep.x - origin.x, ep.y - origin.y));
                    } else if (child.getEdgeType() == Edge.Type.Arc) {
                        ArcEdge childEdge = (ArcEdge) child;
                        sp = childEdge.getStartPoint();
                        ep = childEdge.getEndPoint();

                        childEdge.setStartPoint(new Point2D(sp.x - origin.x, sp.y - origin.y));
                        childEdge.setEndPoint(new Point2D(ep.x - origin.x, ep.y - origin.y));
                    }
                }
            } else if (edge.getEdgeType() == Edge.Type.Arc) {
                ArcEdge arcEdge = (ArcEdge) edge;
                Point2D sp = arcEdge.getStartPoint();
                Point2D ep = arcEdge.getEndPoint();

                arcEdge.setStartPoint(new Point2D(sp.x - origin.x, sp.y - origin.y));
                arcEdge.setEndPoint(new Point2D(ep.x - origin.x, ep.y - origin.y));
            } else if (edge.getEdgeType() == Edge.Type.CubicCurve) {
                throw new RuntimeException("CUBIC_CURVE not supported yet");
            }
        }
    }

}
