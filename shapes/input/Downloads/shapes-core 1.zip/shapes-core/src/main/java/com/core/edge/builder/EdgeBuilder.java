package com.core.edge.builder;

import com.core.edge.ArcEdge;
import com.core.edge.CubicCurveEdge;
import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.math.Point2D;

import java.util.ArrayList;
import java.util.List;

public class EdgeBuilder {
    private final List<Edge> edges = new ArrayList<>();
    private Point2D currentPoint;
    private int edgeIdx;

    public EdgeBuilder startPoint(Point2D startPoint) {
        this.currentPoint = startPoint;
        this.edgeIdx = 1;
        return this;
    }

    public EdgeBuilder straightEdge(Point2D to) {
        StraightEdge straightEdge = new StraightEdge();
        straightEdge.setStartPoint(currentPoint);
        straightEdge.setEndPoint(to);
        straightEdge.setEdgeId("E" + edgeIdx++);
        straightEdge.setOriginalEdgeId(straightEdge.getEdgeId());

        currentPoint = to;
        edges.add(straightEdge);
        return this;
    }

    public EdgeBuilder arcEdge(double radius, boolean largeArc, boolean sweep, Point2D to) {
        ArcEdge arcEdge = new ArcEdge();
        arcEdge.setRadius(radius);
        arcEdge.setLargeArc(largeArc);
        arcEdge.setSweep(sweep);
        arcEdge.setStartPoint(currentPoint);
        arcEdge.setEndPoint(to);
        arcEdge.setEdgeId("E" + edgeIdx++);
        arcEdge.setOriginalEdgeId(arcEdge.getEdgeId());

        currentPoint = to;
        edges.add(arcEdge);
        return this;
    }

    public EdgeBuilder cubicCurveEdge(Point2D controlStart, Point2D controlEnd, Point2D to) {
        CubicCurveEdge cubicCurveEdge = new CubicCurveEdge();
        cubicCurveEdge.setControlSP(controlStart);
        cubicCurveEdge.setControlEP(controlEnd);
        cubicCurveEdge.setStartPoint(currentPoint);
        cubicCurveEdge.setEndPoint(to);
        cubicCurveEdge.setEdgeId("E" + edgeIdx++);
        cubicCurveEdge.setOriginalEdgeId(cubicCurveEdge.getEdgeId());

        currentPoint = to;
        edges.add(cubicCurveEdge);
        return this;
    }

    public List<Edge> build() {
        return edges;
    }

}
