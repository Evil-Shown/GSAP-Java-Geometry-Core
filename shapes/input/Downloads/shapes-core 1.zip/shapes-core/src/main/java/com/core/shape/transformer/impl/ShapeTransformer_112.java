package com.core.shape.transformer.impl;

import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.edge.builder.EdgeBuilder;
import com.core.math.Point2D;
import com.core.shape.Param;
import com.core.shape.ParamList;
import com.core.shape.ShapeConstants;
import com.core.shape.transformer.ShapeTransformer;
import com.core.utility.EdgeDimCutTuple;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ShapeTransformer_112 extends ShapeTransformer {
    @Override
    public List<Edge> resize(List<Param> params, Map<String, Double> services) {
        ParamList p = new ParamList(params);
        double W = p.getParam("W").getValue();
        double W1 = p.getParam("W1").getValue();
        double H = p.getParam("H").getValue();
        double H1 = p.getParam("H1").getValue();

        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E4")) {
            trimLeft += services.get("E4");
        }

        Point2D p0 = new Point2D(trimLeft + W - W1, trimBottom);
        Point2D p1 = new Point2D(trimLeft + W, trimBottom);
        Point2D p2 = new Point2D(p1.x, p1.y + H1);
        Point2D p3 = new Point2D(trimLeft, trimBottom + H);

        List<Edge> edges = new EdgeBuilder()
            .startPoint(p0)
            .straightEdge(p1)
            .straightEdge(p2)
            .straightEdge(p3)
            .straightEdge(p0)
            .build();

        calculateCircumference(edges);
        calculateArea(params);

        return edges;
    }

    @Override
    public EdgeDimCutTuple resize2(List<Param> params, Map<String, Double> services, Map<String, Double> coatingRemovals) {
        ParamList p = new ParamList(params);
        double W = p.getParam("W").getValue();
        double W1 = p.getParam("W1").getValue();
        double H = p.getParam("H").getValue();
        double H1 = p.getParam("H1").getValue();

        double trimBottom = p.getParam(ShapeConstants.TRIM_BOTTOM).getValue();
        double trimLeft = p.getParam(ShapeConstants.TRIM_LEFT).getValue();

        if (services.containsKey("E1")) {
            trimBottom += services.get("E1");
        }
        if (services.containsKey("E4")) {
            trimLeft += services.get("E4");
        }

        Point2D p0 = new Point2D(trimLeft + W - W1, trimBottom);
        Point2D p1 = new Point2D(trimLeft + W, trimBottom);
        Point2D p2 = new Point2D(p1.x, p1.y + H1);
        Point2D p3 = new Point2D(trimLeft, trimBottom + H);

        List<Edge> edges = new EdgeBuilder()
            .startPoint(p0)
            .straightEdge(p1)
            .straightEdge(p2)
            .straightEdge(p3)
            .straightEdge(p0)
            .build();

        List<Edge> dimLines = new ArrayList<>();
        dimLines.add(new StraightEdge(p0, p1, ShapeConstants.W1));
        dimLines.add(new StraightEdge(p1, p2, ShapeConstants.H1));
        dimLines.add(new StraightEdge(new Point2D(p1.x, p3.y), p3, ShapeConstants.W));
        dimLines.add(new StraightEdge(p3, new Point2D(p3.x, p1.y), ShapeConstants.H));

        calculateCircumference(edges);
        calculateArea(params);
        double sT = services.getOrDefault("E3", 0.0);
        double sR = services.getOrDefault("E2", 0.0);
        double sB = services.getOrDefault("E1", 0.0);
        double sL = services.getOrDefault("E4", 0.0);

        Point2D cP00 = new Point2D(trimLeft-sL, trimBottom-sB);
        Point2D cP0 = new Point2D(cP00.x + sL + W - W1, cP00.y);
        Point2D cP1 = new Point2D(cP0.x + W1 + sR, cP0.y);
        Point2D cP2 = new Point2D(cP1.x,cP1.y + H1 + sB);
        Point2D cP3 = new Point2D(cP00.x, cP0.y + H + sB + sT );

        List<Edge> cEdges = new EdgeBuilder()
                .startPoint(cP0)
                .straightEdge(cP1)
                .straightEdge(cP2)
                .straightEdge(cP3)
                .straightEdge(cP0)
                .build();

        double t = coatingRemovals.getOrDefault("E3", 0.0);
        double r = coatingRemovals.getOrDefault("E2", 0.0);
        double b = coatingRemovals.getOrDefault("E1", 0.0);
        double l = coatingRemovals.getOrDefault("E4", 0.0);

        double m = (H-H1)/W;
        double thita = Math.atan(m);
        double c = H - t/Math.cos(thita);
        double y = -m*(W-r)+c;

        double m1 = H/(W-W1);
        double thita1 = Math.atan(m1);
        double c1 = H+l/Math.cos(thita1);
        double x1 = -(b-c1)/m1;
        double xc = (c-c1)/(-m1+m);
        double yc = -m1*xc+c1;

        Point2D crP00 = new Point2D(trimLeft, trimBottom);
        Point2D crP0 = new Point2D(crP00.x + x1, crP00.y+b);
        Point2D crP1 = new Point2D(crP00.x + W - r,crP0.y);
        Point2D crP2 = new Point2D(crP1.x, crP00.y+y);
        Point2D crP3 = new Point2D(crP00.x+xc, crP00.y+yc);
        List<Edge> crEdges = new EdgeBuilder()
                .startPoint(crP0)
                .straightEdge(crP1)
                .straightEdge(crP2)
                .straightEdge(crP3)
                .straightEdge(crP0)
                .build();

        return new EdgeDimCutTuple(edges, dimLines, cEdges, crEdges);
    }

    //L*H - (H-H1)*L/2 - (L-L1)*H/2
    private void calculateArea(List<Param> params) {
        ParamList p = new ParamList(params);
        double W = p.getParam(ShapeConstants.W).getValue();
        double W1 = p.getParam(ShapeConstants.W1).getValue();
        double H = p.getParam(ShapeConstants.H).getValue();
        double H1 = p.getParam(ShapeConstants.H1).getValue();
        this.area = (W * H) - (W * (H - H1) / 2.0) - (H * (W - W1) / 2.0);
    }

}
