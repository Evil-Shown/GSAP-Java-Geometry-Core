package com.core.cutout.impl;

import com.core.cutout.CornerCutout;
import com.core.cutout.CutoutViewCreator;
import com.core.cutout.EdgeCutout;
import com.core.cutout.attachment.Attachment;
import com.core.cutout.attachment.CornerAttachment;
import com.core.cutout.attachment.EdgeAttachment;
import com.core.edge.ArcEdge;
import com.core.edge.Edge;
import com.core.edge.StraightEdge;
import com.core.math.Point2D;
import com.core.math.Vector2D;
import com.core.shape.ParamList;
import com.core.svg.SVGBuilder;
import com.core.svg.SVGBuilder2;
import com.core.utility.GeometryHelper;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.core.math.Line;

public class Cutout_105 extends CornerCutout {

    public Cutout_105(String cutoutNo, Attachment attachment) {
        super(105, cutoutNo, (CornerAttachment) attachment);
    }

    //@Override
    public Point2D attach(int idx, List<Edge> edges, List<Edge> baseEdges, Point2D previousPoint) {
        return null;
    }

    @Override
public CutoutAttachInfo attach(int idx, Edge currEdge, Edge nextEdge, List<Edge> edges,List<Edge> DxFedges, List<Line> DimLines, CutoutAttachInfo previousInfo, boolean dxf) {
        ParamList p = new ParamList(params);
        double R = p.getParam("R").getValue();

        Vector2D currVec = Vector2D.create(currEdge.getEndPoint(), currEdge.getStartPoint());
        Vector2D nextVec = Vector2D.create(nextEdge.getStartPoint(), nextEdge.getEndPoint());
        double dist = 0.0;

        Point2D cornerPoint = currEdge.getEndPoint();
        if (nextVec.length() < currVec.length()) {
            Vector2D currentVecPoint = currVec.normalized().multiplied(nextVec.length());
            currentVecPoint.add(new Vector2D(currEdge.getEndPoint()));
            dist = GeometryHelper.findCornerToArcDistance(cornerPoint, nextEdge.getEndPoint(), new Point2D(currentVecPoint), R);
        } else {
            Vector2D nextVecPoint = nextVec.normalized().multiplied(currVec.length());
            nextVecPoint.add(new Vector2D(nextEdge.getStartPoint()));
            dist = GeometryHelper.findCornerToArcDistance(cornerPoint, new Point2D(nextVecPoint), currEdge.getStartPoint(), R);
        }

        Vector2D currDir = Vector2D.create(currEdge.getEndPoint(), currEdge.getStartPoint());
        currDir.normalize();
        currDir.multiply(dist);
        Point2D p1 = new Point2D(currEdge.getEndPoint().x + currDir.x, currEdge.getEndPoint().y + currDir.y);

        Vector2D nextDir = Vector2D.create(nextEdge.getStartPoint(), nextEdge.getEndPoint());
        nextDir.normalize();
        nextDir.multiply(dist);
        Point2D p2 = new Point2D(nextEdge.getStartPoint().x + nextDir.x, nextEdge.getStartPoint().y + nextDir.y);

        Point2D startPoint = currEdge.getStartPoint();
        if (previousInfo != null) {
            edges.remove(edges.size() - 1);
            startPoint = previousInfo.lastPoint;
        }

        StraightEdge se1 = new StraightEdge();
        se1.setEdgeId(currEdge.getEdgeId());
        se1.setStartPoint(startPoint);
        se1.setEndPoint(p1);
        edges.add(se1);
        DxFedges.add(se1);

        if(dxf) {
            ArcEdge ae = new ArcEdge();
            ae.setEdgeId("ARC-" + idx);
            ae.setRadius(R);
            ae.setStartPoint(p1);
            ae.setEndPoint(p2);
            ae.setLargeArc(false);
            ae.setSweep(true);
            edges.add(ae);
        }
        ArcEdge ae2 = new ArcEdge();
        ae2.setEdgeId("ARC-" + idx);
        ae2.setRadius(R);
        ae2.setStartPoint(p2);
        ae2.setEndPoint(p1);
        ae2.setLargeArc(false);
        ae2.setSweep(true);
        DxFedges.add(ae2);

        StraightEdge se2 = new StraightEdge();
        se1.setEdgeId(nextEdge.getEdgeId());
        se2.setStartPoint(p2);
        se2.setEndPoint(nextEdge.getEndPoint());
        edges.add(se2);
        DxFedges.add(se2);

        CutoutAttachInfo info = new CutoutAttachInfo();
        info.isOnNextEdge = true;
        info.lastPoint = se2.getStartPoint();

        calculateWaste();

        return info;
    }

    public static CutoutViewCreator createCutoutViewCreator() {
        return new CutoutViewCreator() {

            @Override
            public SVGBuilder2 getThumbnailBuilder() {
                return new SVGBuilder2(180, 180)
                    .pathBuilder()
                    .strokeOpacity("0.25")
                    .startPath(0, 0)
                    .lineTo(0, 50)
                    .endPath(false)
                    .pathBuilder()
                    //.startPath(0, 0)
                    .startPath(0, 50)
                    .arcTo(110, 110, 110, 160, false, true)
                    //.lineTo(160, 160)
                    .endPath(false)
                    .pathBuilder()
                    .strokeOpacity("0.25")
                    .startPath(110, 160)
                    .lineTo(160, 160)
                    .endPath(false);
            }

            @Override
            public SVGBuilder2 getPreviewBuilder() {
                return new SVGBuilder2(200, 200)
                        .pathBuilder()
                        .strokeOpacity("0.25")
                        .startPath(10, 0)
                        .lineTo(10, 50)
                        .endPath(false)
                        .pathBuilder()
                        //.startPath(0, 0)
                        .startPath(10, 50)
                        .arcTo(110, 110, 120, 160, false, true)
                        //.lineTo(160, 160)
                        .endPath(false)
                        .pathBuilder()
                        .strokeOpacity("0.25")
                        .startPath(120, 160)
                        .lineTo(170, 160)
                        .endPath(false)
                        .pathBuilder()
                        .stroke("blue")
                        .startPath(0, 160)
                        .lineToWithText(0, 50, "R")
                        .endPath(false);
            }

            @Override
            public Type getCutoutType() {
                return Type.Corner;
            }

            @Override
            public List<String> getParamNames() {
                return Arrays.asList("R");
            }

            @Override
            public List<String> getCutoutMappingParamNames() {
                return Arrays.asList("R");
            }

        };
    }

    private void calculateWaste() {
        ParamList p = new ParamList(params);
        double R = p.getParam("R").getValue();
        waste = R * R - ((Math.PI * R * R) / 4.0);
    }
}
