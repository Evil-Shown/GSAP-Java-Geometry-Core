package com.core.shape;

import com.core.math.Point2D;

public class TrimLine {
  private String id;
  private Point2D startPoint;
  private Point2D endPoint;
  private double trim;

  public TrimLine(String id) {
    this.id = id;
  }

  public TrimLine copy() {
    TrimLine tl = new TrimLine(this.id);
    tl.setStartPoint(this.startPoint);
    tl.setEndPoint(this.endPoint);
    tl.setTrim(this.trim);
    return tl;
  }

  public String getId() {
    return id;
  }

  public Point2D getStartPoint() {
    return startPoint;
  }

  public void setStartPoint(Point2D startPoint) {
    this.startPoint = startPoint;
  }

  public Point2D getEndPoint() {
    return endPoint;
  }

  public void setEndPoint(Point2D endPoint) {
    this.endPoint = endPoint;
  }

  public double getTrim() {
    return trim;
  }

  public void setTrim(double trim) {
    this.trim = trim;
  }
}
