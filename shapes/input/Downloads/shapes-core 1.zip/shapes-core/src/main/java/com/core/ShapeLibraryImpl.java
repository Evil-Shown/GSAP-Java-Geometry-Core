package com.core;

import com.core.cutout.Cutout;
import com.core.cutout.CutoutView;
import com.core.factory.ShapeFactory;
import com.core.shape.CustomShape;
import com.core.shape.Shape;
import com.core.shape.ShapeView;

import java.util.List;

public class ShapeLibraryImpl extends ShapeLibrary {

    private final ShapeFactory shapeFactory;

    public ShapeLibraryImpl(String filePath) {
        shapeFactory = new ShapeFactory(filePath);
    }

    @Override
    public Shape createShape(int internalShapeId, String shapeNoText) {
        return shapeFactory.createShape(internalShapeId, shapeNoText);
    }

    @Override
    public ShapeView createShapeView(int internalShapeId, String shapeNoText) {
        return shapeFactory.createShapeView(internalShapeId, shapeNoText);
    }

    @Override
    public CutoutView createCutoutView(int internalCutoutId, String cutoutNoText) {
        return shapeFactory.createCutoutView(internalCutoutId, cutoutNoText);
    }

    @Override
    public List<Integer> getAllInternalShapeIds() {
        return shapeFactory.getAllInternalShapeIds();
    }

    @Override
    public List<Integer> getAllInternalCutoutIds() {
        return shapeFactory.getAllInternalCutoutIds();
    }

    @Override
    public List<String> getCutoutParams(int internalCutoutId) {
        return shapeFactory.getCutoutParams(internalCutoutId);
    }

    @Override
    public List<String> getCutoutMappingParamNames(int internalCutoutId) {
        return shapeFactory.getCutoutMappingParamNames(internalCutoutId);
    }

    @Override
    public boolean addCustomShape(CustomShape customShape) {
        throw new RuntimeException("Not implemented yet");
    }

    @Override
    public Shape createCustomShape(int shapeId) {
        throw new RuntimeException("Not implemented yet");
    }

}
