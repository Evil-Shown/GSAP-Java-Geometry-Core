package com.core.shape;

import java.util.ArrayList;
import java.util.List;

public class ShapeParamBuilder {
    private List<Param> params = new ArrayList<>();

    public ShapeParamBuilder() {
    }

    public ShapeParamBuilder(List<Param> params) {
        this.params = params;
    }

    public ShapeParamBuilder setParam(String name, double value) {
        for (Param param : params) {
            if (param.getName().equalsIgnoreCase(name)) {
                param.setValue(value);
                return this;
            }
        }
        params.add(new Param(name, value));
        return this;
    }

    public List<Param> build() {
        return params;
    }
}
