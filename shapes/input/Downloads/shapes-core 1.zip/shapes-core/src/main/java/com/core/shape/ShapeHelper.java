package com.core.shape;

import com.core.utility.GeometryHelper;
import com.core.cutout.Cutout;
import com.core.edge.Edge;
import com.core.math.Point2D;
import com.core.math.Vector2D;
import com.core.utility.BoundingBox;
import com.core.edge.StraightEdge;
import com.core.edge.ArcEdge;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ShapeHelper {

    public static double getEdgeLength(Edge edge) {
        return Vector2D.create(edge.getStartPoint(), edge.getEndPoint()).length();
    }

    public static double getCutoutCircumference(List<Cutout> cutouts) {
        double circumference = 0.0;
        for (Cutout cutout : cutouts) {
            circumference += cutout.getCircumference();
        }
        return circumference;
    }

    public static double getCutoutArea(List<Cutout> cutouts) {
        double area = 0.0;
        for (Cutout cutout : cutouts) {
            area += cutout.getWaste();
        }
        return area;
    }

    public static List<Edge> serviceAdjustedEdges(List<Edge> edges, Map<String, Double> services) {
        List<Edge> adjustedEdges = new ArrayList<>();

        for (int i = 0; i < edges.size(); i++) {
            Edge currentEdge = edges.get(i).copy();
            String edgeId = currentEdge.getEdgeId();

            // Skip edges without service or with zero service
            if (!services.containsKey(edgeId) || services.get(edgeId) == 0) {
                adjustedEdges.add(currentEdge);
                continue;
            }

            double serviceAmount = services.get(edgeId);

            if (currentEdge.getEdgeType() == Edge.Type.Arc) {
                // Handle arc edge adjustment for various shapes
                ArcEdge arcEdge = (ArcEdge) currentEdge;
                Point2D start = arcEdge.getStartPoint();
                Point2D end = arcEdge.getEndPoint();

                // Calculate chord length (distance between start and end)
                double dx = end.x - start.x;
                double dy = end.y - start.y;
                double chordLength = Math.sqrt(dx * dx + dy * dy);

                // Calculate new radius (current radius + service amount)
                double newRadius = arcEdge.getRadius() + serviceAmount;

                // Ensure minimum radius (at least half the chord length)
                newRadius = Math.max(newRadius, chordLength / 2);

                // Find center point using geometry helper
                Point2D center = GeometryHelper.findCircleCenterOfArc(
                        start, end,
                        arcEdge.getRadius(),
                        arcEdge.isLargeArc(),
                        arcEdge.isSweep());

                // Calculate scaling factor for points
                double scaleFactor = newRadius / arcEdge.getRadius();

                // Calculate new start point
                Point2D newStart = new Point2D(
                        center.x + (start.x - center.x) * scaleFactor,
                        center.y + (start.y - center.y) * scaleFactor);

                // Calculate new end point
                Point2D newEnd = new Point2D(
                        center.x + (end.x - center.x) * scaleFactor,
                        center.y + (end.y - center.y) * scaleFactor);

                // Create adjusted arc
                ArcEdge adjustedArc = new ArcEdge(
                        newRadius,
                        arcEdge.isLargeArc(),
                        arcEdge.isSweep(),
                        newStart,
                        newEnd);
                adjustedArc.setEdgeId(edgeId);
                adjustedEdges.add(adjustedArc);
            } else {
                // Handle straight edge adjustment
                StraightEdge straightEdge = (StraightEdge) currentEdge;
                Edge prevEdge = getPrev(edges, i).copy();
                Edge nextEdge = getNext(edges, i).copy();

                // Extend previous edge forward
                double prevDx = prevEdge.getEndPoint().x - prevEdge.getStartPoint().x;
                double prevDy = prevEdge.getEndPoint().y - prevEdge.getStartPoint().y;
                double prevLength = Math.sqrt(prevDx * prevDx + prevDy * prevDy);
                double prevScale = (prevLength + serviceAmount) / prevLength;
                prevEdge.getEndPoint().x = prevEdge.getStartPoint().x + prevDx * prevScale;
                prevEdge.getEndPoint().y = prevEdge.getStartPoint().y + prevDy * prevScale;

                // Extend next edge backward
                double nextDx = nextEdge.getStartPoint().x - nextEdge.getEndPoint().x;
                double nextDy = nextEdge.getStartPoint().y - nextEdge.getEndPoint().y;
                double nextLength = Math.sqrt(nextDx * nextDx + nextDy * nextDy);
                double nextScale = (nextLength + serviceAmount) / nextLength;
                nextEdge.getStartPoint().x = nextEdge.getEndPoint().x + nextDx * nextScale;
                nextEdge.getStartPoint().y = nextEdge.getEndPoint().y + nextDy * nextScale;

                // Adjust current edge to connect neighbors
                straightEdge.getStartPoint().x = prevEdge.getEndPoint().x;
                straightEdge.getStartPoint().y = prevEdge.getEndPoint().y;
                straightEdge.getEndPoint().x = nextEdge.getStartPoint().x;
                straightEdge.getEndPoint().y = nextEdge.getStartPoint().y;

                adjustedEdges.add(straightEdge);
            }
        }

        return adjustedEdges;
    }

    private static Edge getNext(List<Edge> edges, int idx) {
        int size = edges.size();
        if (idx < size - 1) {
            return edges.get(idx + 1);
        } else {
            return edges.get(0);
        }
    }

    private static Edge getPrev(List<Edge> edges, int idx) {
        int size = edges.size();
        if (idx > 0) {
            return edges.get(idx - 1);
        } else {
            return edges.get(size - 1);
        }
    }

}
