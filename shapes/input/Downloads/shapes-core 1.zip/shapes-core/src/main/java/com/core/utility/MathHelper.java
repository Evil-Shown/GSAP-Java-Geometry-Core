package com.core.utility;

public class MathHelper {

    public static double round2(double value) {
        double d = value * 100;
        d = Math.round(d);
        return d / 100.0;
    }

    public static double round4(double value) {
        double d = value * 10000;
        d = Math.round(d);
        return d / 10000.0;
    }

    private MathHelper() {}
}
